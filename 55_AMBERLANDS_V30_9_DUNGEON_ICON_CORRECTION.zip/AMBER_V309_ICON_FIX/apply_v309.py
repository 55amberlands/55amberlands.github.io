#!/usr/bin/env python3
"""55 AMBERLANDS V30.9 - correct World Boss vs Dungeon Boss icon classification."""
from pathlib import Path
import sys

root=Path.cwd()
jsfile=root/'v28_ult_weapons.js'
indexfile=root/'index.html'
if not (jsfile.is_file() and indexfile.is_file() and (root/'.git').exists()):
    sys.exit('STOP: Run at the GitHub repository root (index.html, v28_ult_weapons.js, .git required)')

old="const isUlt = g => !!g && (g.ult === true || RE.test(String(g.name || g.w || '')));"
new="""// V30.9: world-boss legendary weapons only. V30.8 dungeon test drops were
// mistakenly given ult:true; that flag alone is NOT proof of world-boss type.
// Armor and admin-test drops must use regular slot-specific PX gear icons.
const isUlt = g => !!g &&
  (g.slot == null || g.slot === 'W') &&
  g.admin_test !== true &&
  (/^ult_(?:sword|fist|bow|staff)_[a-z0-9]+$/i.test(String(g.id || '')) ||
   (g.ult === true && RE.test(String(g.name || g.w || ''))));"""
oldtag='<script src="./v28_ult_weapons.js?v=302_plus10_only"></script>'
newtag='<script src="./v28_ult_weapons.js?v=309_worldboss_only"></script>'
js=jsfile.read_text(encoding='utf-8')
idx=indexfile.read_text(encoding='utf-8')
if new in js and newtag in idx:
    print('PASS: V30.9 already installed; no duplicate changes')
    sys.exit(0)
checks=[(js,old,'legacy icon classification'),(idx,oldtag,'V28 script reference')]
for src,needle,label in checks:
    if src.count(needle)!=1:
        sys.exit('STOP: expected one '+label+'. Your repository differs; no files changed.')

# Make backups inside .git, which is never deployed by GitHub Pages.
backup=root/'.git'/'amber_v309_backup'
backup.mkdir(parents=True,exist_ok=True)
for original in (jsfile,indexfile):
    dst=backup/original.name
    if not dst.exists(): dst.write_bytes(original.read_bytes())
jsfile.write_text(js.replace(old,new),encoding='utf-8')
indexfile.write_text(idx.replace(oldtag,newtag),encoding='utf-8')
print('PASS: V30.9 icon type filter installed (dungeon gear uses its own slot/icon)')
print('No Supabase, inventory, stats, drop formulas, or character data changed')
