55 AMBERLANDS V30.9 — แก้ไอคอนอุปกรณ์ทดลองบอสดันเจียน

ต้นเหตุ: SQL ทดสอบ V30.8 ใส่ ult:true ให้ไอเทมดันเจียน 5 ชิ้น
v28_ult_weapons.js เดิมตีความ ult:true เป็นอาวุธตำนานบอสโลกทุกช่อง S/G/B/R/W
ทำให้แสดงรูปดาบ/อาวุธสายฟ้าซ้ำแทนเสื้อ หมัด ถุงมือ รองเท้า แหวน

แพตช์ V30.9 แก้ที่ระบบเลือกไอคอน ให้ใช้รูปตำนานบอสโลกเฉพาะอาวุธจริง
id = ult_sword_*, ult_fist_*, ult_bow_*, ult_staff_*
หรืออาวุธช่อง W ที่มี ult:true และชื่อ [ตำนานบอสโลก] เท่านั้น
admin_test=true และช่อง S/G/B/R จะใช้ไอคอนอุปกรณ์ปกติตามชนิด/อาชีพ/ระดับ

วิธีติดตั้ง:
1. GitHub Add file > Upload files > อัปโหลด ZIP โดยไม่แตก แล้ว Commit
2. ใน Codespaces เปิด Terminal และวางครั้งเดียว:
cd "$(git rev-parse --show-toplevel)" && git switch main && git pull --ff-only origin main && unzip -oq 55_AMBERLANDS_V30_9_DUNGEON_ICON_CORRECTION.zip -d .git/amber_v309 && bash .git/amber_v309/AMBER_V309_ICON_FIX/deploy_v309.sh
3. ตรวจ GitHub Pages Actions และรีเฟรช Chrome

ไม่ต้องรัน SQL เพราะเป็นการแก้ไอคอนเท่านั้น ข้อมูลจริงใน Supabase ยังมี ult:true
บนของทดลองทั้ง 5 ชิ้น ต้องตรวจทำความสะอาด metadata ภายหลังอย่างปลอดภัย
(ไม่ควรลบรายการอุปกรณ์หรือปิด trigger ผูกบัญชีเพื่อแก้ไอคอน)

แพตช์ไม่แก้ค่าพลัง, อัตราดรอป, ดาเมจ หรืออุปกรณ์ที่สวมอยู่
