#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
[ "$(git branch --show-current)" = main ] || { echo 'STOP: switch to main first'; exit 1; }
# Unlike older installers, don't block on unrelated untracked upload ZIP files.
if ! git diff --quiet -- index.html v28_ult_weapons.js || ! git diff --cached --quiet; then
 echo 'STOP: target files have uncommitted changes; preserve them and inspect git status'; exit 1
fi
python3 .git/amber_v309/AMBER_V309_ICON_FIX/apply_v309.py
node --check v28_ult_weapons.js
git diff --check -- index.html v28_ult_weapons.js
if git diff --quiet -- index.html v28_ult_weapons.js; then echo 'PASS: Already installed; nothing to push'; exit 0; fi
git add -- index.html v28_ult_weapons.js
git commit -m 'V30.9 correct boss-world icon vs dungeon gear icons'
git push origin main
echo 'PASS: V30.9 pushed; check GitHub Pages Actions status'
