#!/usr/bin/env bash
# 55 AMBERLANDS V30.1 one-click installer; run from a trusted repo checkout.
set -Eeuo pipefail
ROOT="$(git rev-parse --show-toplevel)"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
if [ "$(git branch --show-current)" != "main" ]; then
  echo '❌ กรุณาเปิด branch main เท่านั้น'; exit 1
fi
# Do not overwrite uncommitted/staged user changes to the two target files.
if ! git diff --quiet -- index.html online_bridge.js || ! git diff --cached --quiet -- index.html online_bridge.js; then
  echo '❌ index.html หรือ online_bridge.js มีการแก้ไขค้างอยู่ ยังไม่เขียนทับ'; exit 1
fi
python3 "$HERE/apply_v301.py"
if command -v node >/dev/null 2>&1; then node --check online_bridge.js; fi
if [ -f tools/check_static_site.py ]; then python3 tools/check_static_site.py; fi
git diff --check -- index.html online_bridge.js
git add -- index.html online_bridge.js
if git diff --cached --quiet; then
  echo '✅ ติดตั้งไว้แล้ว ไม่มีการเปลี่ยนแปลงใหม่'
else
  git commit -m 'V30.1 prevent old game screen flash during startup'
  git push origin main
  echo '✅ Commit + Push เสร็จแล้ว GitHub Actions จะ Deploy ตาม workflow ของ repo'
fi
