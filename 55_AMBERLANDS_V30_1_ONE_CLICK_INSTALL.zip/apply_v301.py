#!/usr/bin/env python3
"""55 AMBERLANDS V30.1: stop old UI flashing before newer game scripts load.
Runs only against the known, supported GitHub release layout. No SQL / Supabase writes.
"""
from pathlib import Path
import subprocess
import sys

root = Path.cwd()
index = root / 'index.html'
bridge = root / 'online_bridge.js'
if not index.is_file() or not bridge.is_file():
    sys.exit('❌ ต้องรันที่โฟลเดอร์หลักที่มี index.html และ online_bridge.js')

old_hide = "  function hideOverlay(){document.documentElement.classList.add('amber-ready');ui.overlay?.remove();ui.overlay=null;ui.label=null;ui.controls=null}"
new_hide = """  // V30.1 NO-LEGACY-FLASH: never uncover the old game during client boot.
  // The original HTML engine starts first; Pixel V24 and server V30 load later.
  async function hideOverlay(){
    if(document.readyState!=='complete'){
      showMessage('กำลังเตรียมเกม 55 AMBERLANDS เวอร์ชันล่าสุด...');
      await new Promise(resolve=>window.addEventListener('load',resolve,{once:true}));
    }
    const missing=[];
    if(typeof render!=='function')missing.push('GAME_RENDER');
    if(!window.PX?.anim?._t)missing.push('PIXEL_V24');
    if(typeof window.AMBER_V277?.invoke!=='function')missing.push('SERVER_ACTIONS');
    if(typeof window.AMBER_V300_VITALS?.get!=='function')missing.push('V30_VITALS');
    if(missing.length)throw new Error('ไฟล์เกมโหลดไม่ครบ ('+missing.join(', ')+') กรุณารีเฟรช');
    // Re-render the Supabase-backed character after all modern layers exist.
    // Does not write character saves or change any game mechanics.
    render();
    await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
    document.documentElement.classList.add('amber-ready');
    ui.overlay?.remove();ui.overlay=null;ui.label=null;ui.controls=null;
  }"""
old_css = '<style id="amber-login-screen-shield">html:not(.amber-ready) body{background:#070d17!important}html:not(.amber-ready) body>:not(#amberOnlineGate){visibility:hidden!important}html:not(.amber-ready) #amberOnlineGate{visibility:visible!important}</style>'
new_css = '<style id="amber-login-screen-shield">html:not(.amber-ready) body{background:#070d17!important}html:not(.amber-ready) body>:not(#amberOnlineGate){visibility:hidden!important}html:not(.amber-ready) #amberOnlineGate{visibility:visible!important}html:not(.amber-ready) body::before{content:"⚔ 55 AMBERLANDS — กำลังโหลดเกมเวอร์ชันล่าสุด";position:fixed;inset:0;display:flex;align-items:center;justify-content:center;padding:24px;background:#070d17;color:#fbd08a;text-align:center;font:700 17px system-ui,sans-serif;z-index:999998}</style>'
old_tag = './online_bridge.js?v=299_vitals_starter'
new_tag = './online_bridge.js?v=301_no_legacy_flash'
old_call = '    hideOverlay();'
new_call = '    await hideOverlay();'

original_index = index.read_text(encoding='utf-8')
original_bridge = bridge.read_text(encoding='utf-8')
if new_tag in original_index and new_call in original_bridge and 'PIXEL_V24' in original_bridge:
    print('✅ แพตช์ V30.1 ติดตั้งแล้ว ไม่ต้องแก้ซ้ำ')
    sys.exit(0)

checks = [
    (original_index, old_css, 'login shield'),
    (original_index, old_tag, 'online bridge version'),
    (original_bridge, old_hide, 'original hideOverlay'),
    (original_bridge, old_call, 'original hideOverlay call')
]
for contents, required, label in checks:
    if contents.count(required) != 1:
        sys.exit(f'❌ โค้ด {label} เปลี่ยนไปจาก V30.0 (พบ {contents.count(required)} จุด) หยุดเพื่อป้องกันแก้ผิดไฟล์')
if 'v300_authoritative_vitals_ui.js' not in original_index or 'v24_px_integration.js' not in original_index:
    sys.exit('❌ ไม่พบระบบ V24 และ V30 ใน index.html หยุดเพื่อความปลอดภัย')

updated_index = original_index.replace(old_css, new_css).replace(old_tag, new_tag)
updated_bridge = original_bridge.replace(old_hide, new_hide).replace(old_call, new_call)
assert 'await hideOverlay();' in updated_bridge and new_tag in updated_index

# Backups are kept in .git (not uploaded as part of GitHub Pages).
git_dir = subprocess.check_output(['git', 'rev-parse', '--absolute-git-dir'], text=True).strip()
backup_dir = Path(git_dir) / 'amber_v301_backup'
backup_dir.mkdir(parents=True, exist_ok=True)
for name, data in [('index.html', original_index), ('online_bridge.js', original_bridge)]:
    target = backup_dir / name
    if not target.exists():
        target.write_text(data, encoding='utf-8')
index.write_text(updated_index, encoding='utf-8')
bridge.write_text(updated_bridge, encoding='utf-8')
print('✅ V30.1 แก้ index.html + online_bridge.js เรียบร้อย')
print('🔒 เปิดหน้าเกมเฉพาะหลัง Supabase, Pixel V24, ระบบ Server Actions และ V30 พร้อม')
print('🗃️ เก็บสำรองไว้ที่:', backup_dir)
print('✅ ไม่มีการแก้ SQL / Supabase / เซฟตัวละคร / ไอเทม / เงิน')
