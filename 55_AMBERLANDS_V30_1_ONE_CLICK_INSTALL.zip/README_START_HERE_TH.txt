55 AMBERLANDS V30.1 — ติดตั้งครั้งเดียวสำหรับ GitHub Pages

เป้าหมาย: หลังรีเฟรช Chrome จะไม่เห็นเกมรุ่นแรกโผล่มาก่อนเกม Pixel ใหม่
การเปลี่ยนแปลง: แก้เฉพาะ index.html และ online_bridge.js
ไม่แก้ SQL, Supabase, เซฟ, ไอเทม, เงิน, ดาเมจ หรือระบบเกมหลัก

ขั้นตอน:
1) GitHub > repo 55amberlands/55amberlands.github.io > Add file > Upload files
   อัปโหลด ZIP ชื่อนี้ลง ROOT (ระดับเดียวกับ index.html) แล้วกด Commit changes
2) GitHub > ปุ่ม Code สีเขียว > Codespaces > เปิด Codespace > Terminal
3) วางคำสั่งบรรทัดเดียวที่ ChatGPT ให้ในแชท แล้วกด Enter

สคริปต์จะ git pull -> แตก ZIP -> ตรวจไฟล์ -> ติดตั้ง -> ตรวจความถูกต้อง -> git commit -> git push
หลัง Push ให้ดู GitHub > Actions ว่าขึ้น success จากนั้นรีเฟรชหน้าเกม

ไม่ต้องรัน SQL เพราะแก้เฉพาะลำดับโหลดหน้าเว็บ

หาก GitHub แสดง Error 403 ตอน push ให้ตรวจสิทธิ์ Token/Codespaces
หากไฟล์เปลี่ยนจาก V30.0 สคริปต์จะหยุด ไม่ฝืนเขียนทับ
ไฟล์ก่อนแก้ถูกสำรองใน .git/amber_v301_backup
