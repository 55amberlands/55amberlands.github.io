-- 55 AMBERLANDS V27.3: SERVER-VERIFIED WORLD BOSS, 3-HOURLY, THAILAND TIME.
-- APPLY ONCE in Supabase SQL Editor. Safe to rerun: creates if missing / replaces only V27.3 functions.
-- DOES NOT enable strict save, alter existing V27.1.1 RPCs, or grant premium coils.
-- Real events: 00:00,03:00,06:00,09:00,12:00,15:00,18:00,21:00 Bangkok; 30 minutes.
-- Combat HP, damage, cooldowns, rankings and reward receipts are authoritative in PostgreSQL.
-- IMPORTANT: Old normal-monster rewards/saves are still client-side and need separate hardening.

create table if not exists public.amber_v273_events (
  event_key text primary key,
  starts_at timestamptz not null,
  closes_at timestamptz not null,
  max_hp bigint not null check(max_hp > 0),
  hp bigint not null check(hp >= 0),
  defeated_at timestamptz,
  created_at timestamptz not null default now()
);
create table if not exists public.amber_v273_fighters (
  event_key text not null references public.amber_v273_events(event_key),
  user_id uuid not null,
  nickname text not null default '',
  level_snapshot int not null default 1,
  damage bigint not null default 0 check(damage >= 0),
  attacks int not null default 0 check(attacks >= 0),
  max_hp int not null,
  hp int not null,
  max_mp int not null,
  mp int not null,
  hp_pots int not null default 0,
  mp_pots int not null default 0,
  last_attack timestamptz,
  last_skill timestamptz,
  joined_at timestamptz not null default now(),
  primary key(event_key,user_id)
);
create index if not exists amber_v273_fighters_damage_idx on public.amber_v273_fighters(event_key, damage desc);
alter table public.amber_v273_events enable row level security;
alter table public.amber_v273_fighters enable row level security;
revoke all on public.amber_v273_events, public.amber_v273_fighters from anon, authenticated;

-- This function is internal to SECURITY DEFINER RPCs; never grant direct access to clients.
create or replace function private.amber_v273_slot()
returns jsonb language sql stable set search_path='' as $$
  with clock as (
    select (now() at time zone 'Asia/Bangkok') as local_now
  ), slot as (
    select date_trunc('day',local_now) +
      (floor(extract(hour from local_now)/3)::int * interval '3 hours') as local_start
    from clock
  )
  select jsonb_build_object(
    'key',to_char(local_start,'YYYY-MM-DD"T"HH24'),
    'starts_at',(local_start at time zone 'Asia/Bangkok'),
    'closes_at',((local_start + interval '30 minutes') at time zone 'Asia/Bangkok'),
    'open',now() >= (local_start at time zone 'Asia/Bangkok') and
      now() < ((local_start + interval '30 minutes') at time zone 'Asia/Bangkok'))
  from slot
$$;
revoke all on function private.amber_v273_slot() from public,anon,authenticated;

-- Read-only status for the signed-in player's latest fight or current 3-hour round.
create or replace function public.amber_v273_status(p_event_key text default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare
  u uuid := auth.uid(); s jsonb; k text; e public.amber_v273_events%rowtype;
  f public.amber_v273_fighters%rowtype; top_rows jsonb;
begin
  if u is null then return jsonb_build_object('ok',false,'reason','login_required'); end if;
  s := private.amber_v273_slot(); k := coalesce(p_event_key,s->>'key');
  if k !~ '^20[0-9]{2}-[0-9]{2}-[0-9]{2}T(00|03|06|09|12|15|18|21)$' then
    return jsonb_build_object('ok',false,'reason','invalid_event');
  end if;
  select * into e from public.amber_v273_events where event_key=k;
  select * into f from public.amber_v273_fighters where event_key=k and user_id=u;
  select coalesce(jsonb_agg(jsonb_build_object('name',r.nickname,'damage',r.damage,'rank',r.rn)), '[]'::jsonb)
  into top_rows from (
    select nickname,damage,row_number() over(order by damage desc, joined_at, user_id) as rn
    from public.amber_v273_fighters where event_key=k and damage>0
    order by damage desc,joined_at,user_id limit 10
  ) r;
  return jsonb_build_object('ok',true,'event_key',k,'open',(s->>'key')=k and (s->>'open')::boolean,
    'next_slot_hour_bkk',(floor(extract(hour from (now() at time zone 'Asia/Bangkok'))/3)::int*3 + 3)%24,
    'boss_max_hp',coalesce(e.max_hp,14000),'boss_hp',coalesce(e.hp,14000),
    'defeated',e.defeated_at is not null,
    'joined',f.user_id is not null,'my_damage',coalesce(f.damage,0),
    'my_attacks',coalesce(f.attacks,0),'my_hp',f.hp,'my_max_hp',f.max_hp,
    'my_mp',f.mp,'my_max_mp',f.max_mp,'hp_pots',f.hp_pots,'mp_pots',f.mp_pots,
    'ranking',top_rows,
    'claimed',exists(select 1 from public.amber_ac_claims q where q.user_id=u and q.kind='worldboss_v273' and q.period=k),
    'server_time',now());
end $$;

-- Join actual event, client cannot choose or forge an event key, time, stats or attack damage.
create or replace function public.amber_v273_join()
returns jsonb language plpgsql security definer set search_path='' as $$
declare
  u uuid := auth.uid(); s jsonb; k text; e public.amber_v273_events%rowtype;
  c jsonb; lvl int; mn text; pot_hp int; pot_mp int; hpmax int; mpmax int;
begin
  if u is null then return jsonb_build_object('ok',false,'reason','login_required'); end if;
  s := private.amber_v273_slot();
  if not (s->>'open')::boolean then return jsonb_build_object('ok',false,'reason','event_closed'); end if;
  k := s->>'key';
  -- Account-owned save is only used for identity, displayed level and starting potion stock.
  -- Damage is based on a server-fixed formula, NOT on untrusted level/stats/gear.
  select save_data into c from public.amber_characters where user_id=u;
  if c is null then return jsonb_build_object('ok',false,'reason','character_missing'); end if;
  lvl := greatest(1,least(100,case when (c->>'lv') ~ '^[0-9]{1,3}$' then (c->>'lv')::int else 1 end));
  mn := left(coalesce(nullif(c->>'name',''),'ผู้เล่น'),24);
  pot_hp := greatest(0,least(9999,case when (c->>'potHP') ~ '^[0-9]{1,6}$' then (c->>'potHP')::int else 0 end));
  pot_mp := greatest(0,least(9999,case when (c->>'potMP') ~ '^[0-9]{1,6}$' then (c->>'potMP')::int else 0 end));
  hpmax := 500 + lvl*10; mpmax := 120 + lvl*3;
  insert into public.amber_v273_events(event_key,starts_at,closes_at,max_hp,hp)
  values(k,(s->>'starts_at')::timestamptz,(s->>'closes_at')::timestamptz,14000,14000)
  on conflict(event_key) do nothing;
  select * into e from public.amber_v273_events where event_key=k for update;
  if e.defeated_at is not null then return jsonb_build_object('ok',false,'reason','boss_already_defeated'); end if;
  insert into public.amber_v273_fighters(event_key,user_id,nickname,level_snapshot,max_hp,hp,max_mp,mp,hp_pots,mp_pots)
  values(k,u,mn,lvl,hpmax,hpmax,mpmax,mpmax,pot_hp,pot_mp)
  on conflict(event_key,user_id) do nothing;
  return public.amber_v273_status(k);
end $$;

-- One server-resolved combat step. Request contains ONLY booleans.
-- Server-owned global HP, health, cooldown, potions, and user damage.
create or replace function public.amber_v273_attack(p_skill boolean default false, p_auto_potion boolean default true)
returns jsonb language plpgsql security definer set search_path='' as $$
declare
  u uuid := auth.uid(); s jsonb; k text; e public.amber_v273_events%rowtype;
  f public.amber_v273_fighters%rowtype; c jsonb; attack_damage int := 0;
  incoming int := 0; now_time timestamptz := clock_timestamp();
  allow_skill boolean := false; hp_used boolean := false; mp_used boolean := false;
  old_stock int;
begin
  if u is null then return jsonb_build_object('ok',false,'reason','login_required'); end if;
  s := private.amber_v273_slot(); k := s->>'key';
  -- Serialize global boss updates. Cooldown enforced on the server for all devices.
  select * into e from public.amber_v273_events where event_key=k for update;
  if e.event_key is null then return jsonb_build_object('ok',false,'reason','event_not_joined'); end if;
  select * into f from public.amber_v273_fighters where event_key=k and user_id=u for update;
  if f.user_id is null then return jsonb_build_object('ok',false,'reason','player_not_joined'); end if;
  if e.defeated_at is not null or not (s->>'open')::boolean then
    return jsonb_build_object('ok',true,'event_key',k,'defeated',e.defeated_at is not null,
      'boss_hp',e.hp,'boss_max_hp',e.max_hp,'my_hp',f.hp,'my_max_hp',f.max_hp,
      'my_mp',f.mp,'my_max_mp',f.max_mp,'my_damage',f.damage,'my_attacks',f.attacks,
      'hp_pots',f.hp_pots,'mp_pots',f.mp_pots,'hit_damage',0,'incoming_damage',0,'ended',true);
  end if;
  if f.last_attack is not null and now_time-f.last_attack < interval '850 milliseconds' then
    return jsonb_build_object('ok',false,'reason','cooldown');
  end if;
  if f.hp <= 0 then return jsonb_build_object('ok',false,'reason','player_defeated','my_hp',0); end if;
  -- Use server fighter attack count as pseudorandom rotation; no client-sent damage.
  allow_skill := coalesce(p_skill,false) and f.mp >= 12 and
    (f.last_skill is null or now_time-f.last_skill >= interval '4 seconds');
  attack_damage := (CASE WHEN allow_skill THEN 330 ELSE 155 END) + (f.attacks % 9)*7;
  attack_damage := least(attack_damage,e.hp::int);
  incoming := 8 + (f.attacks % 7);
  f.mp := f.mp - CASE WHEN allow_skill THEN 12 ELSE 0 END;
  f.hp := greatest(0, f.hp - incoming);
  if allow_skill then f.last_skill := now_time; end if;
  if coalesce(p_auto_potion,false) and (f.hp <= f.max_hp*45/100 or f.mp <= f.max_mp/100*20) then
    -- Row lock and DB decrement ensure only genuinely stocked potions work.
    select save_data into c from public.amber_characters where user_id=u for update;
    if f.hp <= f.max_hp*45/100 and f.hp_pots>0 and (c->>'potHP') ~ '^[0-9]{1,6}$' then
      old_stock := (c->>'potHP')::int;
      if old_stock>0 then
        c := jsonb_set(c,'{potHP}',to_jsonb(old_stock-1),true);
        f.hp_pots := f.hp_pots-1;
        f.hp := least(f.max_hp,f.hp+ceil(f.max_hp*.45)::int);
        hp_used := true;
      end if;
    end if;
    if f.mp <= f.max_mp*20/100 and f.mp_pots>0 and (c->>'potMP') ~ '^[0-9]{1,6}$' then
      old_stock := (c->>'potMP')::int;
      if old_stock>0 then
        c := jsonb_set(c,'{potMP}',to_jsonb(old_stock-1),true);
        f.mp_pots := f.mp_pots-1;
        f.mp := least(f.max_mp,f.mp+ceil(f.max_mp*.5)::int);
        mp_used := true;
      end if;
    end if;
    if hp_used or mp_used then
      update public.amber_characters set save_data=c,updated_at=now_time where user_id=u;
    end if;
  end if;
  -- Attacks exchange damage even if this server hit also knocks the player out.
  update public.amber_v273_events set hp=greatest(0,e.hp-attack_damage),
      defeated_at=case when e.hp<=attack_damage then now_time else defeated_at end
    where event_key=k;
  update public.amber_v273_fighters set
    damage=f.damage+attack_damage, attacks=f.attacks+1,
    hp=f.hp,mp=f.mp,last_attack=now_time,last_skill=f.last_skill,
    hp_pots=f.hp_pots,mp_pots=f.mp_pots
    where event_key=k and user_id=u;
  return jsonb_build_object('ok',true,'event_key',k,'boss_max_hp',e.max_hp,
    'boss_hp',greatest(0,e.hp-attack_damage),'defeated',e.hp<=attack_damage,
    'my_hp',f.hp,'my_max_hp',f.max_hp,'my_mp',f.mp,'my_max_mp',f.max_mp,
    'my_damage',f.damage+attack_damage,'my_attacks',f.attacks+1,
    'hit_damage',attack_damage,'incoming_damage',incoming,
    'used_skill',allow_skill,'used_hp_pot',hp_used,'used_mp_pot',mp_used,
    'hp_pots',f.hp_pots,'mp_pots',f.mp_pots);
end $$;

-- Server-only ranking & atomic reward. One receipt per real event (every 3 hours).
-- No client-supplied rank/damage, no premium gems/coils awarded.
create or replace function public.amber_v273_claim(p_event_key text default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare
  u uuid := auth.uid(); e public.amber_v273_events%rowtype;
  f public.amber_v273_fighters%rowtype; k text; rank_n int;
  r jsonb; saved jsonb; lvl int; verified_lvl int;
begin
  if u is null then return jsonb_build_object('ok',false,'reason','login_required'); end if;
  if p_event_key is not null and p_event_key !~ '^20[0-9]{2}-[0-9]{2}-[0-9]{2}T(00|03|06|09|12|15|18|21)$' then
    return jsonb_build_object('ok',false,'reason','invalid_event');
  end if;
  if p_event_key is null then
    select e1.event_key into k from public.amber_v273_events e1
      join public.amber_v273_fighters f1 on f1.event_key=e1.event_key
      where f1.user_id=u and e1.defeated_at is not null and f1.damage>0
      order by e1.defeated_at desc limit 1;
  else k := p_event_key; end if;
  if k is null then return jsonb_build_object('ok',false,'reason','no_verified_victory'); end if;
  select * into e from public.amber_v273_events where event_key=k for update;
  select * into f from public.amber_v273_fighters where event_key=k and user_id=u for update;
  if e.defeated_at is null or f.user_id is null or f.damage<=0 or f.attacks<=0 then
    return jsonb_build_object('ok',false,'reason','no_verified_victory');
  end if;
  select 1+count(*)::int into rank_n from public.amber_v273_fighters b
    where b.event_key=k and (b.damage>f.damage or
      (b.damage=f.damage and (b.joined_at<f.joined_at or
      (b.joined_at=f.joined_at and b.user_id<f.user_id))));
  -- Never trust level from browser-save for a server-paid reward.
  -- Until server-verification has been populated, default to level 1 bonus.
  select verified_lv into verified_lvl from public.amber_ac_verified_levels where user_id=u;
  lvl := greatest(1,least(100,coalesce(verified_lvl,1)));
  r := jsonb_build_object('gold',(case rank_n when 1 then 100000 when 2 then 75000 when 3 then 55000 else 35000 end)+lvl*150,
    'ore_prism',(case rank_n when 1 then 5 when 2 then 4 when 3 then 3 else 2 end),
    'ga',1,'gw',1);
  -- Per-event unique primary key (user_id,kind,period) prevents duplicate payout.
  insert into public.amber_ac_claims(user_id,kind,period,reward)
    values(u,'worldboss_v273',k,r) on conflict (user_id,kind,period) do nothing;
  if not found then return jsonb_build_object('ok',false,'reason','already_claimed','event_key',k); end if;
  saved := private.amber_ac_grant(u,r);
  return jsonb_build_object('ok',true,'event_key',k,'rank',rank_n,'reward',r,
    'wallet',jsonb_build_object('gold',saved->'gold','gems',saved->'gems','mats',saved->'mats'));
end $$;


-- Signed-in user can inspect only their own server receipts; useful for safety dashboard.
create or replace function public.amber_v273_receipts()
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid := auth.uid(); r jsonb;
begin
  if u is null then return '[]'::jsonb; end if;
  select coalesce(jsonb_agg(x.receipt),'[]'::jsonb) into r
  from (select jsonb_build_object('event_key',period,'reward',reward,'claimed_at',claimed_at) receipt
        from public.amber_ac_claims where user_id=u and kind='worldboss_v273'
        order by claimed_at desc limit 10) x;
  return r;
end $$;

revoke all on function public.amber_v273_status(text),public.amber_v273_join(),
  public.amber_v273_attack(boolean,boolean),public.amber_v273_claim(text),
  public.amber_v273_receipts() from public,anon,authenticated;
grant execute on function public.amber_v273_status(text),public.amber_v273_join(),
  public.amber_v273_attack(boolean,boolean),public.amber_v273_claim(text),
  public.amber_v273_receipts() to authenticated;

-- READ-ONLY VERIFICATION AFTER INSTALL:
-- select proname from pg_proc p join pg_namespace n on n.oid=p.pronamespace
--   where n.nspname='public' and p.proname like 'amber_v273_%';
-- select event_key,hp,max_hp,defeated_at from public.amber_v273_events order by starts_at desc limit 5;
-- select kind,period,reward,claimed_at from public.amber_ac_claims
--   where kind='worldboss_v273' order by claimed_at desc limit 10;
