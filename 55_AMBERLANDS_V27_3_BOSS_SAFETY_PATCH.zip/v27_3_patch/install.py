#!/usr/bin/env python3
"""Install only V27.3 touched files, with SHA256 guard and out-of-tree rollback."""
from pathlib import Path
import json,hashlib,shutil,tempfile,subprocess,sys,os
here=Path(__file__).resolve().parent
root=here.parent
manifest=json.loads((here/'manifest.json').read_text())
items=manifest['files']

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None

if not (root/'index.html').is_file():
    raise SystemExit('ERROR: ต้องแตก ZIP ที่โฟลเดอร์เดียวกับ index.html ก่อน')
for name, spec in items.items():
    src=here/'files'/name; dst=root/name
    if digest(src)!=spec['after_sha256']:
        raise SystemExit('ERROR: ไฟล์แพตช์ถูกเปลี่ยนระหว่างอัปโหลด: '+name)
    cur=digest(dst)
    if cur not in (spec['before_sha256'],spec['after_sha256']):
        raise SystemExit('STOP: '+name+' ไม่ตรงกับ V27.2 ที่ทดสอบแล้ว ไม่เขียนทับไฟล์นี้')
    if spec['before_sha256'] is None and cur is not None and cur!=spec['after_sha256']:
        raise SystemExit('STOP: ไฟล์ใหม่ชนกับงานเดิม: '+name)

for name in ['v25_systems.js','v26_realtime.js','v27_3_boss_client.js']:
    try:
        subprocess.run(['node','--check',str(here/'files'/name)],check=True,capture_output=True,text=True)
    except FileNotFoundError:
        raise SystemExit('ERROR: Codespaces ต้องมี Node.js เพื่อเช็ก JavaScript ก่อนติดตั้ง')
    except subprocess.CalledProcessError as e:
        raise SystemExit('ERROR: JavaScript ไม่ผ่านการตรวจ: '+name+'\n'+e.stderr)

todo={name:spec for name,spec in items.items() if digest(root/name)!=spec['after_sha256']}
if not todo:
    print('V27.3 installed already: all '+str(len(items))+' files match. No changes.')
    sys.exit(0)
backup=Path(tempfile.mkdtemp(prefix='amber_before_v273_',dir=str(root.parent)))
for name in todo:
    dst=root/name
    if dst.exists(): shutil.copy2(dst,backup/name)
written=[]
try:
    for name in todo:
        dst=root/name;temp=dst.with_name(dst.name+'.v273_tmp')
        shutil.copy2(here/'files'/name,temp)
        os.replace(temp,dst)
        written.append(name)
    for name,spec in items.items():
        if digest(root/name)!=spec['after_sha256']:
            raise RuntimeError('Hash mismatch: '+name)
except Exception as ex:
    for name in written:
        dst=root/name;old=backup/name
        if old.exists(): shutil.copy2(old,dst)
        elif dst.exists(): dst.unlink()
    raise SystemExit('ERROR: ย้อนกลับไฟล์ต้นฉบับแล้ว: '+str(ex))
print('SUCCESS: V27.3 installed '+str(len(todo))+' files: '+', '.join(todo))
print('Backup: '+str(backup))
print('NEXT: Paste V27.3 SQL into Supabase SQL Editor. Do NOT enable strict flags or push to main yet.')
