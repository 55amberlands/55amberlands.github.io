#!/usr/bin/env python3
"""55 AMBERLANDS 30.1.6 — preserve V28 lightning title visuals and boss-set aura.
Only v25_systems.js and the corresponding cache-busting script tag are changed.
The authorized, server-side V310 title selection remains untouched.
"""
from pathlib import Path
import sys, shutil

root = Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd().resolve()
f = root / 'v25_systems.js'
h = root / 'index.html'
ult = root / 'v28_ult_weapons.js'
for file in [f,h,ult]:
    if not file.is_file(): raise SystemExit('STOP: missing required game file '+file.name)

s=f.read_text(encoding='utf-8')
html=h.read_text(encoding='utf-8')
marker='AMBER_V3016_V28_TITLE_ASSET_RESTORED'
if marker in s:
    if 'v25_systems.js?v=3016_v28_title_assets' not in html:
        raise SystemExit('STOP: V3016 source present but HTML cache tag not patched')
    print('PASS: V30.1.6 already installed — nothing changed')
    sys.exit(0)

u=ult.read_text(encoding='utf-8')
for text in ('.px25-title.t-bolt', 'window.AMBER_V28_ULT', "'หมัด':", 'px28-ult-frame'):
    if text not in u: raise SystemExit('STOP: incompatible V28 weapon asset module: '+text)

old_names="""const ULT_NAMES = {ult_fist:'จ้าวกรงเล็บอสุนีบาต +10',ult_sword:'จักรพรรดิดาบสายฟ้า +10',
  ult_bow:'ราชันธนูวชิระ +10',ult_staff:'จอมเวทอัสนีพิภพ +10'};
for (const [id, name] of Object.entries(ULT_NAMES)) {
  if (!TITLES[id]) TITLES[id] = {name, cls:'rain', live:true,
    how:'สวมอาวุธตำนานบอสโลก +10 ของอาชีพตนเอง (ยืนยันโดย Supabase)'};
}"""
new_names="""/* AMBER_V3016_V28_TITLE_ASSET_RESTORED:
 * Keep the ORIGINAL titles and lightning frame class from the Codex V28 patch.
 * In V3015 a client-side placeholder with cls:'rain' prevented V28.addTitles()
 * from registering its own lightning title graphics. No client-side unlocks here.
 */
const ULT_NAMES = {
  ult_fist:'⚡ ราชันกรงเล็บอัสนี',
  ult_sword:'⚡ จักรพรรดิดาบสายฟ้า',
  ult_bow:'⚡ เทพพรานวชิระ',
  ult_staff:'⚡ จอมเวทอัสนีนิรันดร์'
};
const V3016_ULT_JOB = {
  ult_fist:'หมัด', ult_sword:'ดาบ', ult_bow:'ธนู', ult_staff:'จอมเวท'
};
const v3016TitleIcons = Object.create(null);
for (const [id, name] of Object.entries(ULT_NAMES)) {
  // Reuse original V28 class t-bolt rather than creating an unrelated rain badge.
  TITLES[id] = {name, cls:'bolt', live:true,
    how:'สวมอาวุธตำนานบอสโลก +10 ตรงอาชีพ (Supabase ยืนยัน)'};
}"""

old_htmlfn="""function titleHTML(id, small) {
  const t = TITLES[id]; if (!t) return '';
  return `<span class="px25-title t-${t.cls}${small ? ' sm' : ''}"><img class="px25-sp l" src="${PX.ui.sparkURL()}" alt=""><b>${esc(t.name)}</b><img class="px25-sp r" src="${PX.ui.sparkURL()}" alt=""></span>`;
}"""
new_htmlfn="""function titleHTML(id, small) {
  const t = TITLES[id]; if (!t) return '';
  const v28cls = V3016_ULT_JOB[id];
  if (v28cls) {
    // Actual V28 weapon art + the ORIGINAL V28 electric title/frame, not a new
    // V25 rainbow-label substitute. The cache ensures no 500ms animation reset.
    let icon = v3016TitleIcons[id] || '';
    if (!icon) {
      try { icon = window.AMBER_V28_ULT?.icon?.(v28cls) || ''; } catch(e) { icon=''; }
      if (icon) v3016TitleIcons[id] = icon;
    }
    const name = window.AMBER_V28_ULT?.DEFS?.[v28cls]?.title;
    const display = name ? '⚡ '+name : t.name;
    const img = icon ? `<img class="px3016-v28-icon" src="${esc(icon)}" alt="">` : '';
    return `<span class="px25-title t-bolt px28-ult-frame px3016-v28-badge${small ? ' sm' : ''}">${img}<b>${esc(display)}</b></span>`;
  }
  return `<span class="px25-title t-${t.cls}${small ? ' sm' : ''}"><img class="px25-sp l" src="${PX.ui.sparkURL()}" alt=""><b>${esc(t.name)}</b><img class="px25-sp r" src="${PX.ui.sparkURL()}" alt=""></span>`;
}"""

old_aura="const auraKindNeeded = valid ? auraKind(tid) : '';"
new_aura="""// Visual boss-set aura belongs to equipped armor, not the chosen title.
    // Switching to a V28 legendary +10 title must NOT erase the 10-frame aura.
    const si3016 = i===0 ? setInfo() : null;
    const auraKindNeeded = valid ? (si3016?.full && si3016.kind ? si3016.kind : auraKind(tid)) : '';"""
old_plate="""    if (!plate) {
      plate = el('div', 'px25-plate', titleHTML(tid, true));
      spr.insertBefore(plate, spr.querySelector(':scope > small') || null);
    }"""
new_plate="""    // V28 module loads after V25; update icon in place when its art becomes ready.
    // Do not remove/recreate the sprite or the plaque every frame.
    const desiredPlate = titleHTML(tid, true);
    if (!plate) {
      plate = el('div', 'px25-plate', desiredPlate);
      spr.insertBefore(plate, spr.querySelector(':scope > small') || null);
      plate.dataset.v3016Markup = desiredPlate;
    } else if (plate.dataset.v3016Markup !== desiredPlate) {
      plate.innerHTML = desiredPlate;
      plate.dataset.v3016Markup = desiredPlate;
    }"""
old_cache='<script src="./v25_systems.js?v=3015_server_cards_title_missions"></script>'
new_cache='<script src="./v25_systems.js?v=3016_v28_title_assets"></script>'

patches=[(old_names,new_names,'V3015 replacement titles'),(old_htmlfn,new_htmlfn,'title artwork'),(old_aura,new_aura,'set aura independence'),(old_plate,new_plate,'stable title icon hydration')]
for before,after,label in patches:
    count=s.count(before)
    if count != 1: raise SystemExit(f'STOP: expected exactly one {label} anchor, got {count}. No changes made.')
    s=s.replace(before,after,1)
if html.count(old_cache)!=1: raise SystemExit('STOP: current index.html not V30.1.5; no changes made')
html=html.replace(old_cache,new_cache,1)

style_marker='document.head.appendChild(css);'
if s.count(style_marker)!=1: raise SystemExit('STOP: V25 CSS anchor mismatch')
style="""// V30.1.6: use genuine V28 weapon art inside the lightning title badge.
// Kept inside the existing title markup: NOT a new player Sprite layer.
css.textContent += `
.px25-title.px3016-v28-badge{display:inline-flex!important;align-items:center!important;gap:7px!important;max-width:min(100%,350px)!important;white-space:normal!important;line-height:1.28!important;overflow:visible!important;padding:4px 9px!important;isolation:isolate}
.px25-title.px3016-v28-badge.sm{font-size:10.5px!important;gap:4px!important;padding:2px 6px!important}
.px25-title.px3016-v28-badge>.px3016-v28-icon{width:29px!important;height:29px!important;min-width:29px!important;max-width:none!important;aspect-ratio:auto!important;object-fit:contain!important;image-rendering:pixelated!important;box-shadow:0 0 8px #4ae8ff88!important;border:0!important;position:relative!important;z-index:1!important}
.px25-title.px3016-v28-badge.sm>.px3016-v28-icon{width:19px!important;height:19px!important;min-width:19px!important}
.px25-title.px3016-v28-badge>b{position:relative;z-index:2;overflow-wrap:anywhere;white-space:normal}
.px25-plate .px3016-v28-badge{max-width:230px!important}
`;
"""
s=s.replace(style_marker,style+style_marker,1)

# Ensure important core systems are left intact.
for preserve in ('amber_v310_title','amber_v291_verified_cards','AMBER_V3012_SOURCE_FIXED_AURA','AMBER_V3013_AURA_BACK_WINGS_HERO_TITLE_WEAPON_GLOW'):
    if preserve not in s: raise SystemExit('STOP: expected existing feature missing '+preserve)

backup = root/'.git/amber_v3016_source_backup'
backup.mkdir(parents=True, exist_ok=True)
for p in (f,h):
    dst=backup/p.name
    if not dst.exists(): shutil.copy2(p,dst)
f.write_text(s,encoding='utf-8')
h.write_text(html,encoding='utf-8')
print('PASS: V30.1.6 repaired original V28 t-bolt + weapon art + preserved title aura; no other game file changed')
