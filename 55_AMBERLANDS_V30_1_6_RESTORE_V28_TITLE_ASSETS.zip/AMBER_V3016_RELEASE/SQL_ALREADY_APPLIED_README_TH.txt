Supabase migration v3016_restore_v28_plus10_titles_constraint ติดตั้งสำเร็จแล้ว
ตรวจ amber_v304_title_pref_title_check ปัจจุบันมี ult_fist,ult_sword,ult_bow,ult_staff แล้ว
ไม่ต้องรัน SQL หรือแก้ Supabase อีกรอบสำหรับแพตช์นี้
อย่าปิด CHECK/RLS หรือเปลี่ยนการตรวจสิทธิ์ของ amber_v310_title
