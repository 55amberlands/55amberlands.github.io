#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
BASE='b4ebb3bbdc927570a9ede9070708799b009540e6'
ZIP='55_AMBERLANDS_V30_1_6_RESTORE_V28_TITLE_ASSETS.zip'
SRC='.git/amber_v3016/AMBER_V3016_RELEASE'

# Codespaces can be on the earlier test branch; do not overwrite uncommitted changes.
if [[ -n "$(git status --porcelain --untracked-files=no)" ]]; then
 echo 'STOP: tracked working files not clean. No files have been changed.'; exit 1
fi
git switch main
git pull --ff-only origin main
# Safe no-op on repeated installs: ensure BOTH source marker and cache-busted HTML exist.
if grep -q 'AMBER_V3016_V28_TITLE_ASSET_RESTORED' v25_systems.js && \
   grep -q 'v25_systems.js?v=3016_v28_title_assets' index.html; then
  node --check v25_systems.js
  echo 'PASS: V30.1.6 already installed; main unchanged'
  exit 0
fi
HEAD="$(git rev-parse HEAD)"

# Only ZIP uploads after V30.1.5 are allowed, no silent code overwrite.
if ! git merge-base --is-ancestor "$BASE" "$HEAD"; then
 echo 'STOP: main is not descendant of approved V30.1.5'; exit 1
fi
if [[ "$HEAD" != "$BASE" ]]; then
  changes="$(git diff --name-only "$BASE" "$HEAD")"
  if [[ -n "$changes" ]] && echo "$changes" | grep -Ev '^55_AMBERLANDS_V30_1_[0-9]+_.*\.zip$' >/dev/null; then
    echo 'STOP: main has other code changes:'; printf '%s\n' "$changes"; exit 1
  fi
fi

python3 "$SRC/patch_v3016.py" .
node --check v25_systems.js
git diff --check -- v25_systems.js index.html
git add -- v25_systems.js index.html
if git diff --cached --quiet; then echo 'PASS: V30.1.6 already installed'; exit 0; fi

# Never force-push. Unique backup per base HEAD; if it exists, ensure identical.
BACKUP="backup-before-v3016-$(git rev-parse --short=12 HEAD)"
if git ls-remote --exit-code --heads origin "$BACKUP" >/dev/null 2>&1; then
  remote_sha="$(git ls-remote origin "refs/heads/$BACKUP" | awk '{print $1}')"
  [[ "$remote_sha" == "$HEAD" ]] || { echo 'STOP: backup branch name collision'; exit 1; }
else
  git push origin "${HEAD}:refs/heads/${BACKUP}"
fi

git commit -m 'V30.1.6 restore Codex V28 lightning title assets and equipment aura'
git push origin main
printf 'PASS: V30.1.6 pushed to MAIN; backup: %s\n' "$BACKUP"
