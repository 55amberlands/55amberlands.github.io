-- V29.9 READ-ONLY VERIFICATION — does not give or remove any items.
SELECT (SELECT count(*) FROM private.amber_v299_function_backup) AS preserved_functions,
       (SELECT count(*) FROM private.amber_v299_starter_receipts) AS gift_receipts,
       (SELECT count(*) FROM private.amber_v299_starter_receipts WHERE grant_kind='retro_new_signup') AS retroactive_gifts,
       (SELECT count(*) FROM public.amber_characters) AS characters;
SELECT character_name,(private.amber_v299_max_vitals(save_data)->>'max_hp')::int AS max_hp,
 (private.amber_v299_max_vitals(save_data)->>'max_mp')::int AS max_mp,
 save_data->>'hp' AS hp_current,save_data->>'mp' AS mp_current
 FROM public.amber_characters WHERE lower(character_name) IN ('nahee','hareko','das123','jjouj','โงา');
SELECT c.character_name,r.grant_kind,r.gems_added,r.pot_hp_added,r.pot_mp_added,
 c.save_data->>'gems' AS gems_now,c.save_data->>'potHP' AS hp_potions_now,c.save_data->>'potMP' AS mp_potions_now
 FROM private.amber_v299_starter_receipts r
 JOIN public.amber_characters c USING(user_id)
 ORDER BY r.granted_at DESC;
