#!/usr/bin/env python3
"""55 AMBERLANDS V29.9: canonical HP/MP potions, starter-gift client sync,
   dungeon bag-potion route. Designed to run AFTER cumulative V29.8 installer.
   Refuses unrecognized Git blobs, backs up touched files, writes atomically.
   NO database changes: V29.9 SQL has already been applied to Supabase.
"""
from __future__ import annotations
import argparse, datetime, hashlib, pathlib, re, sys

ROOT = pathlib.Path.cwd()
EXPECTED = {
 'online_bridge.js': {
   '357c6432a3c5d9025eeb68caf74cef53a815cf26',  # live GitHub 2026-10-26
   'ee3866d9a2263ee29adb0f65eac263259c48fe1f',  # known V29.8 simulation base
 },
 'v277_authority_client.js': {
   '949d92956864f32489e1d85b6540fdb7b7ccd2f2',
   'b8baef1512415d7e729f1a281cdbfe7aa47ca66c',
 },
 'v23_dungeon.js': {'5cb73fce033e02b238a5c497041cf3d3986ccefc'},
 'v12_patch.js': {
   '534a3b0668c65b653b6c431b66ceda3ba204ec4c',
   '9cc3c5df0a1f8607da05bdd0b8d6e648a0fade28',
 },
 'index.html': {
   'd53ec7bc4b4b9659ca417fbe9224f1e1a76e0b32',
   '6ea150e05936ae546e95c145086cdfc5fe268d67',
 },
}
MARKERS = {
 'online_bridge.js': 'V299_NEW_CHAR_CANONICAL_GIFT',
 'v277_authority_client.js': 'V299_RECOVERY_POTION_ROUTE',
 'v23_dungeon.js': 'V299_DUNGEON_HP_POTION_EXPORT',
 'v12_patch.js': 'V299_UI_REBIRTH_VITALS',
 'index.html': '?v=299_vitals_starter',
}

def git_sha(data:bytes)->str:
 return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def replace_one(source,old,new,name):
 n=source.count(old)
 if n!=1:raise ValueError(f'STOP: {name}: required exact patch anchor expected once, found {n}: {old[:92]}')
 return source.replace(old,new,1)

def bump_index(source, filename):
 pattern=r'(<script\s+src="\./'+re.escape(filename)+r'\?v=)[^"]+("\s*><\/script>)'
 upgraded,n=re.subn(pattern,lambda match:match.group(1)+'299_vitals_starter'+match.group(2),source)
 if n!=1:raise ValueError(f'STOP: index.html: expected one {filename} script tag, got {n}')
 return upgraded

def patch(name,source):
 if name=='online_bridge.js':
  return replace_one(source,
   '        resolve(initial);',
   '''        // V299_NEW_CHAR_CANONICAL_GIFT: read the newly-created character back
        // from Supabase so 100,000 coins + 1,000 HP/MP bottles appear instantly.
        // Never treat the browser starter as the authoritative wallet.
        let canonicalNew = null;
        try {
          const {data:created,error:readError}=await sb.from(SAVE_TABLE)
            .select('save_data').eq('user_id',currentUser.id).single();
          if(readError)throw readError;
          canonicalNew=created?.save_data||null;
        } catch(readError) {
          console.warn('[V29.9] Starter gift is saved; re-login to refresh display',readError);
        }
        resolve(canonicalNew || initial);''',name)
 if name=='v277_authority_client.js':
  return replace_one(source,
   """window.usePotion=async function v277UsePotion(type,auto=false){
 if(!['hp','mp'].includes(type))return false;
 try{await recovery(type);return true;}catch{return false}
};""",
   """// V299_RECOVERY_POTION_ROUTE — server-owned HP/MP, and separate dungeon HP.
window.usePotion=async function v299UsePotion(type,auto=false){
 if(type!=='hp'&&type!=='mp')return false;
 // The dungeon has its own server-owned HP pool. Never waste a normal-map
 // HP potion while the player is inside a live dungeon room.
 if(type==='hp'&&window.AMBER_DUNGEON?.isInside?.()){
   const dungeonHeal=window.AMBER_DUNGEON?.useHpPotion;
   if(typeof dungeonHeal==='function')return await dungeonHeal(!!auto);
   if(!auto)tell('กำลังโหลดระบบยาในดันเจียน กรุณาลองใหม่');
   return false;
 }
 try{
   const result=await invoke('amber_v277_recovery',{p_action:type,p_id:null},{silent:true});
   if(result.already_full===true){
     if(!auto)tell(type==='hp'?'🩸 HP เต็มแล้ว ไม่เสียยา':'💧 MP เต็มแล้ว ไม่เสียยา');
     return false;
   }
   return true;
 }catch(e){
   if(!auto){
     const reason=String(e?.message||e);
     if(/V277_NO_POTION_OR_DEAD/.test(reason))tell('🧪 ไม่มียา หรือ HP เหลือ 0 ต้องฟื้นก่อน');
     else if(/V277_ALREADY_FULL/.test(reason))tell('🩸 HP/MP เต็มแล้ว ไม่เสียยา');
     else tell('⚠️ ใช้ยาไม่สำเร็จ: '+reason.slice(0,95));
   }
   return false;
 }
};""",name)
 if name=='v23_dungeon.js':
  return replace_one(source,
   'window.AMBER_DUNGEON={open,roomId:()=>inside()&&view?id:\'\',presenceInfo,checkInvites,room:()=>room,isInside:inside,isViewing:inView,startAuto:toggleAuto};',
   "window.AMBER_DUNGEON={open,roomId:()=>inside()&&view?id:'',presenceInfo,checkInvites,room:()=>room,isInside:inside,isViewing:inView,startAuto:toggleAuto,useHpPotion:useDungeonPotion}; // V299_DUNGEON_HP_POTION_EXPORT",name)
 if name=='v12_patch.js':
  source=replace_one(source,
   'maxHp=function(){return Math.max(1,Math.round(mhBefore()+Math.max(0,((state.stats||{}).VIT||0)-10)*8))};',
   'maxHp=function(){const rb=Math.max(0,Math.min(10,Number(state.v25?.rebirth)||0));return Math.max(1,Math.round(mhBefore()+Math.max(0,((state.stats||{}).VIT||0)-10)*8+rb*1500))}; // V299_UI_REBIRTH_VITALS',name)
  return replace_one(source,
   'maxMp=function(){return Math.max(1,Math.round(mmBefore()+Math.max(0,((state.stats||{}).INT||0)-5)*3))};',
   'maxMp=function(){const rb=Math.max(0,Math.min(10,Number(state.v25?.rebirth)||0));return Math.max(1,Math.round(mmBefore()+Math.max(0,((state.stats||{}).INT||0)-5)*3+rb*400))};',name)
 if name=='index.html':
  for f in ('online_bridge.js','v23_dungeon.js','v277_authority_client.js','v12_patch.js'):
   source=bump_index(source,f)
  return source
 raise ValueError('Unexpected target '+name)

def run(check_only=False):
 original={};new={};found={}
 for name,allowed in EXPECTED.items():
  path=ROOT/name
  if not path.is_file():raise ValueError(f'STOP: missing {name} in game root')
  dat=path.read_bytes();s=dat.decode('utf-8')
  if MARKERS[name] in s:
   found[name]='ALREADY PATCHED';continue
  sha=git_sha(dat)
  if sha not in allowed:
   raise ValueError(f'STOP: {name} unknown Git blob SHA {sha}; no modifications. Do not force.')
  if name in ('v277_authority_client.js','v23_dungeon.js'):
   expected='AMBER298_BOSS_LOCK' if name=='v277_authority_client.js' else 'AMBER297_DUNGEON_CRIT'
   if expected not in s:raise ValueError(f'STOP: {name} needs cumulative V29.8 applied first')
  if name=='index.html' and 'v298_boss_respawn_ui.js' not in s:
   raise ValueError('STOP: V29.8 boss cooldown module missing; apply cumulative patch first')
  patched=patch(name,s)
  if patched==s:raise ValueError('STOP: no change produced for '+name)
  original[name]=dat;new[name]=patched.encode('utf-8');found[name]='READY'
 print('55 AMBERLANDS V29.9 — HP/MP + welcome gift client synchronization')
 for k,v in found.items():print(f'{v:16} {k}')
 if check_only:
  print('PASS: --check verified all target file versions and exact anchors; no files changed')
  return 0
 if not new:
  print('PASS: already installed (no files touched)')
  return 0
 stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
 folder=ROOT/'.amber_v299_backups'/stamp
 folder.mkdir(parents=True,exist_ok=False)
 for name,data in original.items():
  dest=folder/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 applied=[]
 try:
  for name,data in new.items():
   dst=ROOT/name;tmp=ROOT/(name+'.v299.tmp');tmp.write_bytes(data);tmp.replace(dst);applied.append(name)
 except Exception:
  for name in applied:(ROOT/name).write_bytes(original[name])
  raise
 print('Backups:',folder)
 print('PASS: V29.9 installed; only browser code changed; no SQL executed by installer')
 return 0

def main():
 ap=argparse.ArgumentParser()
 group=ap.add_mutually_exclusive_group(required=True)
 group.add_argument('--check',action='store_true');group.add_argument('--apply',action='store_true')
 args=ap.parse_args()
 try:return run(args.check)
 except Exception as e:print(str(e),file=sys.stderr);return 2
if __name__=='__main__':sys.exit(main())
