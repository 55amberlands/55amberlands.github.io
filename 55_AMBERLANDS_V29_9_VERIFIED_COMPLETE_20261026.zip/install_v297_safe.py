#!/usr/bin/env python3
"""55 AMBERLANDS V29.7: server-truth CRIT gold frame and daily rewards UI.
No network; no database writes. Refuses unknown base versions. Backs up all files.
"""
from __future__ import annotations
import argparse, datetime, hashlib, pathlib, re, shutil, sys

ROOT = pathlib.Path.cwd()
EXPECTED = {
    'index.html': 'ba304412a799701559f2a15d2ce3af40fae72b18',
    'v26_realtime.js': 'bd375c385aa2eed2086dac2adf3f8ee9fc86cc2e',
    'v23_dungeon.js': '08ed3077115409e4848f6329bd7adc6df2449ccd',
    'v277_authority_client.js': '03ee51fbcfbc7f4aafe8a6d9a100d0569ab62395',
    'v27_ac_client.js': '7c5254a675c057f87d1c86ca9d96475a6797d617',
    'v25_systems.js': 'f8271a24b7ea84383cb21d8841e743c96ce426da',
}
MARKERS = {
    'index.html': 'v=297_crit_daily',
    'v26_realtime.js': 'AMBER297_WORLDBOSS_CRIT',
    'v23_dungeon.js': 'AMBER297_DUNGEON_CRIT',
    'v277_authority_client.js': 'AMBER297_MAP_CRIT',
    'v27_ac_client.js': 'AMBER297_DAILY_CLAIM',
    'v25_systems.js': 'AMBER297_CHECKIN_WAIT',
}

def git_sha(content: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(content)).encode('ascii') + b'\0' + content).hexdigest()

def once(src: str, old: str, new: str, name: str) -> str:
    n = src.count(old)
    if n != 1:
        raise ValueError(f'STOP: {name}: expected one exact patch anchor; found {n}: {old[:85]!r}')
    return src.replace(old, new, 1)

def change(name: str, src: str) -> str:
    if name == 'v26_realtime.js':
        src = once(src, 'popDmg(ARENA.me.id,s.hit_damage,!!s.used_skill);',
                   'popDmg(ARENA.me.id,s.hit_damage,s.crit === true); // AMBER297_WORLDBOSS_CRIT: server flag only', name)
        src = once(src, "s.textContent = fmt(val); s.style.left = (15 + Math.random() * 70) + '%';",
                   "s.textContent = crit ? '✦ CRITICAL! ✦ ' + fmt(val) : fmt(val); s.style.left = (15 + Math.random() * 70) + '%';", name)
        src = once(src, '.px26-bd.crit{font-size:30px;color:#ff7a2a}',
                   '.px26-bd.crit{font-size:25px;font-weight:1000;color:#fff3b2;background:linear-gradient(130deg,#54330d,#a86d17 55%,#43260b);border:2px solid #ffe18a;border-radius:8px;padding:5px 9px;box-shadow:0 0 15px #ffd54daa,inset 0 0 8px #ffe18150;white-space:nowrap;z-index:50;text-shadow:1px 2px 2px #1d1003}',name)
    elif name == 'v23_dungeon.js':
        src = once(src, "popDamage(out.hit===false?'MISS':out.damage); // server-confirmed miss, no fake damage",
                   "popDamage(out.hit===false?'MISS':out.damage,out.hit!==false&&out.crit===true); // AMBER297_DUNGEON_CRIT: server-confirmed flags only",name)
        src = once(src,
            "function popDamage(n){const sc=$('scene');if(!sc||!inView())return;const d=document.createElement('span');d.className='amber24-damage';d.textContent=n==='MISS'?'MISS':'-'+fmt(n);sc.appendChild(d);setTimeout(()=>d.remove(),900)}",
            "function popDamage(n,isCrit=false){const sc=$('scene');if(!sc||!inView())return;const d=document.createElement('span');d.className='amber24-damage'+(isCrit?' amber297-crit':'');d.textContent=n==='MISS'?'MISS':isCrit?'✦ CRITICAL! ✦ '+fmt(n):'-'+fmt(n);sc.appendChild(d);setTimeout(()=>d.remove(),1100)}",name)
        src = once(src,'.amber24-damage{position:absolute;',
                   '.amber24-damage.amber297-crit{font-size:25px;color:#fff2af;background:linear-gradient(130deg,#4d2b0d,#a97114 60%,#492506);border:2px solid #ffe088;border-radius:9px;padding:5px 8px;box-shadow:0 0 17px #ffcc63c7;white-space:nowrap;z-index:55;text-shadow:1px 2px 2px #1c0e06}\n.amber24-damage{position:absolute;', name)
    elif name == 'v277_authority_client.js':
        src = once(src, 'showDamage(Number(r.damage));', '''showDamage(Number(r.damage));
     // AMBER297_MAP_CRIT: only style damage after the authoritative server reports crit=true.
     if(r.crit===true){
       const sc=document.getElementById('scene');
       const pops=sc?.querySelectorAll('.damage');
       const last=pops?.[pops.length-1];
       if(last){
         last.textContent='✦ CRITICAL! ✦ '+Math.round(Number(r.damage)).toLocaleString('th-TH');
         last.style.cssText+=';font-size:24px;font-weight:1000;color:#fff1a8;background:linear-gradient(130deg,#58340d,#9c6516,#482609);border:2px solid #ffda79;border-radius:8px;padding:4px 8px;box-shadow:0 0 14px #ffcc66;white-space:nowrap;text-shadow:1px 2px 2px #1a0b04;z-index:55;';
       }
     }''',name)
    elif name == 'v27_ac_client.js':
        a=src.index('  async function claimRpc(')
        b=src.index('  async function checkin()',a)
        body='''  // AMBER297_DAILY_CLAIM: atomic reward RPCs do not depend on UI-only visual saves.
  // The backend already locks the character and grants rewards idempotently.
  async function claimRpc(name, params, success) {
    if (!ready()) { warn('ต้องล็อกอินและโหลดตัวละครจาก Supabase ให้เสร็จก่อน'); return {ok:false,reason:'login_required'}; }
    if (busy) { warn('กำลังตรวจรายการก่อนหน้า'); return {ok:false,reason:'busy'}; }
    busy = true;
    try {
      const {data,error} = await cloud().getClient().rpc(name, params || {});
      if(error) throw error;
      if(data?.ok !== true){
        try { await syncState(true); } catch (e) { console.warn('[V29.7 claim status]',e); }
        warn(reason(data?.reason));
        return {ok:false,reason:data?.reason || 'rejected'};
      }
      // RPC succeeded: do NOT report failure just because visual refresh fails afterwards.
      try { await cloud().refreshMarketEconomy(); }
      catch(e) { console.warn('[V29.7 wallet refresh]',e); warn('รับรางวัลสำเร็จแล้ว แต่กระเป๋ายังไม่รีเฟรช ลองเปิดเกมใหม่'); }
      try { await syncState(true); }
      catch(e) { console.warn('[V29.7 event refresh]',e); }
      try { if(success) await success(data); }
      catch(e) { console.warn('[V29.7 event UI refresh]',e); }
      try { v25()?.refresh(); } catch(e) { console.warn('[V29.7 refresh]',e); }
      warn('รับรางวัลสำเร็จแล้วจากเซิร์ฟเวอร์' + (data.reward ? ' · ' + formatReward(data.reward) : ''));
      return {ok:true,data};
    } catch(e) {
      console.error('[V29.7 claim]',name,e);
      warn('รับรางวัลไม่สำเร็จ: '+(e?.message||String(e)));
      return {ok:false,reason:'rpc_error'};
    } finally { busy=false; }
  }

'''
        src=src[:a]+body+src[b:]
        src=once(src,"    await claimRpc('amber_ac_checkin', {}, async () => {",
                 "    return await claimRpc('amber_ac_checkin', {}, async () => {",name)
    elif name == 'v25_systems.js':
        src=once(src,'  void window.AMBER_V27.checkin();','  return window.AMBER_V27.checkin();',name)
        src=once(src,
            "function tabCheckin() {\n  const { c, can, broken } = ckState(), day = broken || c.day >= 7 ? 0 : c.day;",
            "function tabCheckin() {\n  // AMBER297_CHECKIN_WAIT: never present an RPC-loading failure as already claimed.\n  if(online() && !window.AMBER_V27?.getState()?.today_th) return '<p class=\"px25-warn\">⚠️ ยังโหลดสถานะเช็กอินจาก Supabase ไม่สำเร็จ ไม่มีการหักสิทธิ์รับรางวัล</p><button data-v25=\"checkinretry\">🔄 ตรวจสถานะอีกครั้ง</button>';\n  const { c, can, broken } = ckState(), day = broken || c.day >= 7 ? 0 : c.day;", name)
        src=once(src,
            "return '<p class=\"px25-warn\">❌ โหลดหลักฐานเควสต์จากเซิร์ฟเวอร์ไม่สำเร็จ กรุณาลองใหม่</p>';",
            "return '<p class=\"px25-warn\">❌ โหลดหลักฐานเควสต์จากเซิร์ฟเวอร์ไม่สำเร็จ ยังไม่สามารถยืนยันสิทธิ์รับรางวัล</p><button data-v25=\"dailyretry\">🔄 โหลดสถานะเควสต์อีกครั้ง</button>';", name)
        src=once(src, "if (a === 'checkin') { doCheckin(); openHub('checkin'); }",
            "if (a === 'checkinretry') { void openHub('checkin'); } else if (a === 'dailyretry') { void openHub('daily'); } else if (a === 'checkin') { b.disabled=true; void (async()=>{try{await doCheckin();}catch(err){console.error('[V297 checkin]',err);}finally{if($('px25Body')){try{await openHub('checkin');}catch(err){console.error('[V29.7 checkin view]',err);}}}})(); }",name)
    elif name == 'index.html':
        for f in ('v26_realtime.js','v23_dungeon.js','v277_authority_client.js','v27_ac_client.js','v25_systems.js'):
            pat=re.compile(r'(<script\s+src="\./'+re.escape(f)+r'\?v=)[^"<>]+("\s*></script>)')
            src,n=pat.subn(r'\g<1>297_crit_daily\g<2>',src)
            if n != 1:raise ValueError(f'STOP: index: cache version for {f}: expected one; got {n}')
    else: raise ValueError('unexpected path '+name)
    return src

def build(check_only: bool) -> int:
    originals={};results={}; status={}
    for name, expected_sha in EXPECTED.items():
        p=ROOT/name
        if not p.is_file(): raise ValueError(f'STOP: missing {name}; open Codespaces in repository root')
        data=p.read_bytes(); original_sha=git_sha(data)
        content=data.decode('utf-8')
        # This also supports running --check on a previously applied patch.
        if MARKERS[name] in content:
            status[name]='ALREADY PATCHED';continue
        if original_sha!=expected_sha:
            raise ValueError(f'STOP: {name} SHA differs: expected {expected_sha}, found {original_sha}. Do not force; send this error to ChatGPT.')
        patched=change(name,content)
        if patched==content or MARKERS[name] not in patched:
            raise ValueError(f'STOP: {name} patch did not apply the expected version marker')
        originals[name]=data;results[name]=patched.encode('utf-8')
        status[name]='READY'
    for name,label in status.items(): print(f'  {label:15} {name}')
    if check_only:
        print(f'PASS: V29.7 check; {len(results)} files ready. Database migration is installed separately.')
        return 0
    if not results:
        print('PASS: V29.7 already installed; nothing to modify.')
        return 0
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    backup=ROOT/'.amber_v297_backups'/stamp
    backup.mkdir(parents=True,exist_ok=False)
    for name,content in originals.items():
        (backup/name).parent.mkdir(parents=True,exist_ok=True)
        (backup/name).write_bytes(content)
    print('Backups saved:',backup)
    completed=[]
    try:
        for name,payload in results.items():
            tmp=ROOT/(name+'.v297.tmp')
            tmp.write_bytes(payload)
            tmp.replace(ROOT/name)
            completed.append(name)
    except Exception:
        for name in completed: (ROOT/name).write_bytes(originals[name])
        raise
    print('PASS: installed V29.7 successfully; original character saves, UI assets and maps untouched.')
    print('NEXT: run tools/check_static_site.py and node --check on modified JS, then git commit/push.')
    return 0

def main():
    arg=argparse.ArgumentParser()
    flags=arg.add_mutually_exclusive_group(required=True)
    flags.add_argument('--check',action='store_true')
    flags.add_argument('--apply',action='store_true')
    a=arg.parse_args()
    try: return build(a.check)
    except Exception as exc:
        print(str(exc),file=sys.stderr)
        return 2
if __name__=='__main__':sys.exit(main())
