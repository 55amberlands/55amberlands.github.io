#!/usr/bin/env python3
"""55 AMBERLANDS V29.8 cumulative patch: V29.7 Critical/Daily + map-boss respawn.

Verifies the known GitHub source Git-blob IDs, backs up, and updates frontend only.
All authoritative server changes are in SQL_V298_MAP_BOSS_RESPAWN.sql and must be
installed on Supabase (or confirmed installed) before deploying this JS patch.
"""
from __future__ import annotations
import argparse
import datetime
import hashlib
import pathlib
import sys

import install_v297_safe as v297

ROOT=pathlib.Path.cwd()
ADDED='v298_boss_respawn_ui.js'
INPUTS=tuple(v297.EXPECTED)
MARKER='AMBER298_BOSS_LOCK'

def sha256(data:bytes)->str:
    return hashlib.sha256(data).hexdigest()

# Check the bundled script itself against this release's expected content.
EXPECTED_UI_SHA256='9c1cf30d867a7c518472ddfdea7afabba7bb36818b25e1a1d9eea562a6d778bc'

def boss_upgrade(name:str,code:str)->str:
    if name=='v277_authority_client.js':
        if MARKER in code:
            return code
        old="   const r=await invoke(lastAuto?'amber_v283_auto_attack':'amber_v277_attack',params,{silent:true});"
        new="""   const r=await invoke(lastAuto?'amber_v283_auto_attack':'amber_v277_attack',params,{silent:true});
    // AMBER298_BOSS_LOCK — server-confirmed response; never mint boss XP/Gold in the client.
    if(r.monster_id && String(r.monster_id)!==String(m.id)){
      if(state.auto && typeof stop==='function')stop();
      tell('⚠️ เป้าหมายฝั่งเซิร์ฟเวอร์ไม่ตรง กรุณาเลือกบอสใหม่');return;
    }
    if(m.boss && r.boss_respawning===true){
      currentHp=0;
      window.AMBER_V298?.markDead?.(m.id,r.respawn_at);
      if(state.auto && typeof stop==='function')stop();
      tell('🔒 '+m.name+' ถูกกำจัดแล้ว ต้องรอเกิดใหม่จึงจะโจมตีและรับรางวัลได้');
      renderScene();return;
    }"""
        code=v297.once(code,old,new,name)
        old="   if(r.killed){"
        new="""   if(r.killed){
      if(m.boss){
        window.AMBER_V298?.markDead?.(m.id,r.respawn_at);
        currentHp=0;
        if(state.auto && typeof stop==='function')stop();
      }"""
        code=v297.once(code,old,new,name)
    elif name=='index.html':
        if 'v298_boss_respawn_ui.js?v=298_boss_cooldown' in code:
            return code
        base='<script src="./v294_world_map_boss_bridge.js?v=294_server_combat"></script>'
        code=v297.once(code,base,base+'\n<script src="./v298_boss_respawn_ui.js?v=298_boss_cooldown"></script>',name)
    return code

def run(check_only:bool)->int:
    source_path=ROOT/ADDED
    if not source_path.is_file():
        raise ValueError(f'STOP: missing {ADDED}; unzip the whole combined ZIP into repo root')
    source_bytes=source_path.read_bytes()
    if sha256(source_bytes)!=EXPECTED_UI_SHA256:
        raise ValueError('STOP: bundled V29.8 boss UI hash differs; do not force')
    originals={}
    changes={}
    status={}
    for fn,expected in v297.EXPECTED.items():
        dest=ROOT/fn
        if not dest.is_file():
            raise ValueError(f'STOP: {fn} missing from repository root')
        data=dest.read_bytes()
        src=data.decode('utf-8')
        if v297.MARKERS[fn] in src:
            upgraded=src
        else:
            actual=v297.git_sha(data)
            if actual!=expected:
                raise ValueError(f'STOP: {fn} is a different game version (git SHA {actual}, expected {expected}). No files changed.')
            upgraded=v297.change(fn,src)
        upgraded=boss_upgrade(fn,upgraded)
        if upgraded!=src:
            originals[fn]=data
            changes[fn]=upgraded.encode('utf-8')
            status[fn]='READY'
        else:
            status[fn]='ALREADY PATCHED'
    # Ensure no conflicting preexisting boss UI has been overwritten by ZIP unexpectedly.
    print('55 AMBERLANDS V29.8 — V29.7 + boss respawn')
    for name,label in status.items():print(f'  {label:17} {name}')
    print(f'  VERIFIED          {ADDED} ({len(source_bytes)} bytes)')
    if check_only:
        print('PASS: combined patch source verified; ready to apply. No character data changed.')
        return 0
    if not changes:
        print('PASS: combined patch already installed; nothing to modify.')
        return 0
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    folder=ROOT/'.amber_v298_backups'/stamp
    folder.mkdir(parents=True,exist_ok=False)
    for fn,content in originals.items():
        f=folder/fn;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(content)
    applied=[]
    try:
        for fn,content in changes.items():
            temp=ROOT/(fn+'.v298.tmp')
            temp.write_bytes(content)
            temp.replace(ROOT/fn)
            applied.append(fn)
    except Exception:
        for fn in applied:(ROOT/fn).write_bytes(originals[fn])
        raise
    print('Backups:',folder)
    print('PASS: V29.7 and V29.8 installed together. No UI art, characters, EXP or items reset.')
    print('NEXT: validate scripts, commit modified files and push to GitHub.')
    return 0

def main()->int:
    ap=argparse.ArgumentParser()
    mx=ap.add_mutually_exclusive_group(required=True)
    mx.add_argument('--check',action='store_true')
    mx.add_argument('--apply',action='store_true')
    a=ap.parse_args()
    try:return run(a.check)
    except Exception as e:
        print(str(e),file=sys.stderr)
        return 2
if __name__=='__main__':sys.exit(main())
