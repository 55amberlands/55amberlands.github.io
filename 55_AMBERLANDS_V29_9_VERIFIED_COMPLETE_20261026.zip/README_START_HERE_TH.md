# 55 AMBERLANDS V29.9 — รวม V29.7 + V29.8 + V29.9 (แก้แพ็กเกจครบ)

ZIP นี้สร้างใหม่เพื่อแก้แพ็กเกจเดิมที่มี `install_v299_safe.py` รุ่นเก่า **และไม่มีการแก้ `v12_patch.js` ในตัวติดตั้ง** แม้ไฟล์ ZIP รุ่นก่อนแตกได้ก็ตาม

## สิ่งที่รวม

- V29.7: แสดง CRITICAL กรอบทองจากผล Supabase จริง และปรับกิจกรรม/รางวัลรายวัน
- V29.8: ล็อกบอสประจำแมปที่ตายแล้ว รอเกิดใหม่ตาม Supabase 5 นาที
- V29.9: แก้การใช้ยา HP/MP แบบกดเองและ AUTO ให้ใช้สูตรจาก Supabase, ยาในดันเจียน, โหลดของขวัญตอนสร้างตัวละครใหม่
- **แก้ครบเพิ่ม**: ไฟล์ `v12_patch.js` เพื่อให้ตัวเลข HP/MP สูงสุดบนหน้าจอรวมค่ารีเบิร์นและตรงกับเซิร์ฟเวอร์

**SQL ของ V29.7/V29.8/V29.9 ได้ลง Supabase ไปก่อนหน้านี้แล้ว ไม่ต้องรัน SQL ซ้ำ**

## การติดตั้งใน Codespaces

1. อัปโหลด `55_AMBERLANDS_V29_9_VERIFIED_COMPLETE_20261026.zip` ไปยัง root ของ GitHub repository แล้ว Commit changes
2. เปิด Codespaces > Terminal > root ของ repository
3. วางคำสั่ง:

```bash
git pull --ff-only origin main && \
unzip -o 55_AMBERLANDS_V29_9_VERIFIED_COMPLETE_20261026.zip -d . && \
bash INSTALL_V299_CODESPACES.sh && \
git add index.html online_bridge.js v277_authority_client.js v23_dungeon.js v26_realtime.js v27_ac_client.js v25_systems.js v298_boss_respawn_ui.js v12_patch.js && \
git commit -m "V29.9 verified combined complete patch" && \
git push origin main
```

เมื่อคำสั่ง `--check` แจ้ง STOP ให้หยุด! อย่าใช้คำสั่งบังคับฝืน patch เพราะ SHA ของไฟล์เกมอาจเปลี่ยนแล้ว

## กรณีดาวน์โหลด ZIP ไม่ได้

ถ้าแอป ChatGPT แจ้ง File not found อาจเป็นปัญหาลิงก์ดาวน์โหลดของแอป ไม่ได้แปลว่าไฟล์ ZIP แตกไม่ได้โดยอัตโนมัติ
ลองเปิดบทสนทนานี้ผ่าน ChatGPT บนเบราว์เซอร์ หรือแจ้งข้อความ error ที่ปรากฏ เพื่อให้ตรวจจุดล้มเหลวได้

## การตรวจ ZIP

แพ็กเกจนี้มี `SHA256SUMS.txt` สำหรับตรวจ hash ของไฟล์ข้างใน
ได้ทดสอบตัวติดตั้ง V29.8 > V29.9 กับสำเนาเกม และทดสอบติดตั้งซ้ำ
