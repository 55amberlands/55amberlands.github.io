#!/usr/bin/env bash
# 55 AMBERLANDS V29.9 complete patch - intended for GitHub Codespaces repo root.
set -euo pipefail
if [ ! -f index.html ] || [ ! -f tools/check_static_site.py ]; then
  echo 'STOP: Open Terminal in the 55 AMBERLANDS repository root.' >&2
  exit 2
fi
python3 install_v298_combined.py --check
python3 install_v298_combined.py --apply
python3 install_v299_safe.py --check
python3 install_v299_safe.py --apply
python3 tools/check_static_site.py
for src in online_bridge.js v277_authority_client.js v23_dungeon.js v26_realtime.js v27_ac_client.js v25_systems.js v298_boss_respawn_ui.js v12_patch.js; do
  node --check "$src"
done
git diff --check
echo 'PASS: V29.9 complete installed and scripts validated.'
echo 'Next: git add index.html online_bridge.js v277_authority_client.js v23_dungeon.js v26_realtime.js v27_ac_client.js v25_systems.js v298_boss_respawn_ui.js v12_patch.js'
echo 'Then: git commit -m "V29.9 combined complete health and rewards patch" && git push origin main'
