-- 55 AMBERLANDS V29.2R -- READ-ONLY CHECK. Never updates records.
SELECT c.character_name,c.save_data->>'lv' level,c.save_data#>>'{v25,rebirth}' rebirth,
 c.save_data->'stats' stats,c.save_data->>'points' unspent_points,
 private.amber_v285_combat_stats(c.user_id,c.save_data) with_gear,
 private.amber_v285_combat_stats(c.user_id,c.save_data-'eq') without_gear
FROM public.amber_characters c WHERE lower(c.character_name)='nahee';
SELECT COUNT(*) AS successful_single_use_restore FROM private.amber_v292r_character_repair;
