55 AMBERLANDS V29.1 — ORIGINAL PIXEL ART RESTORE + MARKET ALL PHYSICAL ITEMS
2026-10-26

เป้าหมาย:
- คืนหน้ากระเป๋าเดิมให้แสดง Pixel Art/Asset ทั้งหมด ไม่ซ่อนด้วย overlay แบบ V29.0
- รวมการแสดงไอเทม 6 หมวดในกระเป๋าเดิม โดยไม่คัดลอกไอเทมข้ามช่องเก็บ
- เปิดการตั้งขายในตลาดแบบใช้ Supabase บนทุกหมวด: bag, potion, material (รวมแร่รุ้งดารา/เหมันต์/อัคคี), gear (รวมของบอส), pet, shop (รวมปีก/น้ำยารีเซ็ต)
- ป้องกันการแก้ Gold ฝั่ง JavaScript ในการขาย NPC และหักแร่เสริมแบบ local
- แนบ Asset เดิม 125 ไฟล์: ตัวติดตั้งจะเติมเฉพาะไฟล์ที่หายไป ห้ามเขียนทับ Asset ที่มีอยู่

สถานะ Supabase: ผมลง migration ผ่านการเชื่อมต่อเรียบร้อยแล้ว
  amber_v291_restore_market_all_items_and_server_verified_cards
  amber_v291_market_transfer_missing_parent_safe
  ไม่ต้องรัน SQL ซ้ำ

ติดตั้งผ่าน GitHub:
1. ไปที่ Repository 55amberlands.github.io -> Add file -> Upload files
2. อัป ZIP นี้ และกด Commit changes
3. เข้า Code -> Codespaces -> Terminal แล้ววางคำสั่งชุดเดียวด้านล่าง:

set -e
git pull --ff-only origin main
unzip -o 55_AMBERLANDS_V29_1_ASSET_RESTORE_MARKET_SECURITY.zip -d .
python3 install_v291_safe.py --check
python3 install_v291_safe.py --apply
python3 tools/check_static_site.py
git diff --check
git add index.html v290_inventory_unified.js v16_inventory_market.js v23_2_boss_loot.js assets/
git commit -m "V29.1 restore all original assets and server market categories"
git push origin main

หากขึ้น STOP SAFELY หยุดทันที อย่าบังคับติดตั้ง อย่าลบไฟล์หรือฐานข้อมูล

การทดสอบหลังติดตั้ง (ห้ามทดสอบกับของสำคัญก่อน):
- เปิดกระเป๋า ตรวจภาพเดิมของอาวุธ/บอส ปีก สัตว์เลี้ยง แร่รุ้งดารา แร่เหมันต์
- ลองตั้งขายแร่หรืออาหาร 1 ชิ้น แล้วใช้ผู้เล่นอีกคนซื้อ ตรวจว่าเงินและของถูกหัก/เพิ่มตรงบัญชี
- ทดลองยกเลิกประกาศสินค้า ตรวจว่าของกลับเข้าบัญชีเดิมครั้งเดียว
- ทดลองกดขาย NPC ว่า Gold เปลี่ยนหลัง Supabase ยืนยันเท่านั้น

การป้องกันโกงยังต้องตรวจต่อ:
- สะสมการ์ด V25 มีเลขแสดงผล client legacy อยู่ แต่เซิร์ฟเวอร์มี verified_card RPC จากหลักฐานจริงแล้ว
- ต้องวางเกณฑ์การย้ายหลักฐานการ์ดบอสและความคืบหน้าเก่าก่อนเปิดโบนัสถาวรโดยไม่ทำการ์ดเดิมหาย
- เช็กอิน/เควสต์/โบนัสรายวัน/รีเบิร์น/ตลาด/มอนสเตอร์/บอสมี RPC แล้ว แต่ต้องเจาะทดสอบเส้นทางเก่าทีละรายการเพื่อรับรองการป้องกันโกงทั้งหมด

สำรองต้นฉบับ: .amber_patch_backups/v291_<UTC timestamp>/
ไฟล์ที่ตัวติดตั้งแก้ไขเฉพาะ 4 ไฟล์ข้อความ: index.html, v290_inventory_unified.js, v16_inventory_market.js, v23_2_boss_loot.js
ไม่มีสั่งแก้ไข Asset เดิมหรือข้อมูลผู้เล่น
