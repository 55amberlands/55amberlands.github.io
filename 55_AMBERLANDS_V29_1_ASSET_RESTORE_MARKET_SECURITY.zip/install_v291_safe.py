#!/usr/bin/env python3
"""55 AMBERLANDS V29.1 - restore native assets, server-only NPC, server market.
No database writes, no generated assets or player-save changes. Aborts on drift.
"""
import argparse, pathlib, hashlib, subprocess, datetime, shutil, os, sys
p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');p.add_argument('--apply',action='store_true');p.add_argument('--root',default='.')
a=p.parse_args();root=pathlib.Path(a.root).resolve()
files=['index.html','v290_inventory_unified.js','v16_inventory_market.js','v23_2_boss_loot.js']
expected={'v290_inventory_unified.js':'2c009987e3d442b8d9a768f314d8fb1c781afab1',
          'v23_2_boss_loot.js':'94d7c379f7fbce4f1502b80adcc2a32a03455926'}
old_tag='v290_inventory_unified.js?v=2900';new_tag='v290_inventory_unified.js?v=2911'
package=root/'v291_patch'/'v290_inventory_unified.js'
def die(msg):raise SystemExit('STOP SAFELY: '+msg)
def blob(path):
 data=path.read_bytes();return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
for filename in files:
 if not (root/filename).is_file():die(filename+' missing, patch requires deployed V29.0')
asset_bundle=root/'v291_asset_restore'
if not asset_bundle.is_dir():die('v291_asset_restore folder missing; unzip the full ZIP first')
all_assets=[f for f in asset_bundle.rglob('*') if f.is_file()]
if len(all_assets)<120:die('Asset recovery bundle incomplete: '+str(len(all_assets)))
missing_assets=[(p,root/'assets'/p.relative_to(asset_bundle)) for p in all_assets if not (root/'assets'/p.relative_to(asset_bundle)).exists()]
print('PASS: Asset bundle',len(all_assets),'original files; missing files to recover:',len(missing_assets))
index=(root/'index.html').read_text('utf-8')
already=new_tag in index and 'v291OpenInventory' in (root/'v290_inventory_unified.js').read_text('utf-8')
if already:
 if not missing_assets:
  print('PASS: V29.1 already installed (idempotent)');raise SystemExit(0)
 if not a.apply:
  print('PASS: V29.1 code installed; '+str(len(missing_assets))+' missing assets recoverable using --apply');raise SystemExit(0)
 for source,target in missing_assets:
  target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
 print('PASS: Restored '+str(len(missing_assets))+' missing original assets without overwriting existing files')
 raise SystemExit(0)
if index.count(old_tag)!=1 or new_tag in index:die('Unexpected index script version, not safe to replace')
for filename,sha in expected.items():
 got=blob(root/filename)
 if got!=sha:die(filename+' changed from verified V29.0; expected '+sha+' got '+got)
if not package.is_file():die('v291_patch/v290_inventory_unified.js missing, unzip ZIP first')
js=package.read_text('utf-8')
if not all(x in js for x in ['v291OpenInventory','amber_v290_inventory_manifest','amber_market_post','originalEnhance','v290Enhance']):die('Malformed market/restore payload')
# Replace ONLY the unsafe local NPC handler. The other marketplace actions were already RPC based.
v16=(root/'v16_inventory_market.js').read_text('utf-8')
from_a='api.npcSell=(kind,key)=>{';to_a='const cloud=()=>window.AMBER_CLOUD;'
server_npc="""api.npcSell=async(kind,key)=>{
 try{
  const it=own(kind,key);if(!it||it.equipped)throw new Error('ถอดอุปกรณ์ก่อนขาย');
  const q=getQty(it.n);
  if(!window.AMBER_V277?.ready?.())throw new Error('ต้องเชื่อม Supabase ก่อนขาย');
  if(!confirm('ยืนยันขาย '+it.name+' ×'+q+' ให้ NPC ผ่าน Supabase?'))return;
  await window.AMBER_V277.invoke('amber_v278_npc_sell',{p_kind:kind,p_key:key,p_qty:q});
  notify('✅ Supabase ยืนยันการขายและรับ Gold');
  if(own(kind,key)?.n>0)show(kind,key);else openInventory();
 }catch(e){notify('ขายไม่สำเร็จ: '+String(e.message||e).slice(0,120));}
};
"""
if v16.count(from_a)==1 and v16.count(to_a)==1 and v16.index(to_a)>v16.index(from_a):
 v16new=v16[:v16.index(from_a)]+server_npc+v16[v16.index(to_a):]
elif 'api.npcSell=async (kind,key)=>{' in v16 and "amber_v278_npc_sell" in v16:
 print('PASS: NPC sales already server-authoritative; preserving existing implementation')
 v16new=v16
else:die('v16 NPC block changed/unverified')
oldkind="const TYPES={potion:'ยา',material:'หินตีบวก',bag:'ไอเทม',gear:'อุปกรณ์'};"
newkind="const TYPES={potion:'ยา',material:'หินตีบวก',bag:'ไอเทม',gear:'อุปกรณ์',pet:'สัตว์เลี้ยง/อาหาร',shop:'ปีก/Item Shop'};"
if v16new.count(oldkind)!=1:die('v16 TYPES dictionary changed')
v16new=v16new.replace(oldkind,newkind,1)
# Disable stale client-side ore subtraction: Supabase enhancement now validates/consumes it atomically.
ore=(root/'v23_2_boss_loot.js').read_text('utf-8')
start='function adjustEnhanceChance(base,g){';end='window.AMBER_BOSS_ORES={adjustEnhanceChance'
if ore.count(start)!=1 or ore.count(end)!=1:die('Ore function changed')
newore="""function adjustEnhanceChance(base,g){
 // V29.1: presentation only. Server RPC handles stock, bonus, random roll and results.
 return Number(base)||0;
}
"""
orenew=ore[:ore.index(start)]+newore+ore[ore.index(end):]
newindex=index.replace(old_tag,new_tag,1)
outputs={'index.html':newindex,'v290_inventory_unified.js':js,'v16_inventory_market.js':v16new,'v23_2_boss_loot.js':orenew}
for filename,src in outputs.items():
 if filename.endswith('.js'):
  chk=subprocess.run(['node','--check'],input=src,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
  if chk.returncode:die('JS syntax '+filename+': '+chk.stderr[:400])
print('PASS: V29.0 exact base, original assets present, new scripts syntax verified, only 4 text files planned')
if not a.apply:raise SystemExit(0)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
backup=root/'.amber_patch_backups'/('v291_'+stamp)
if backup.exists():die('Backup collision')
backup.mkdir(parents=True)
for filename in files:shutil.copy2(root/filename,backup/filename)
for filename,src in outputs.items():
 tmp=root/(filename+'.v291tmp')
 tmp.write_text(src,'utf-8');os.replace(tmp,root/filename)
for source,target in missing_assets:
 target.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2(source,target)
print('PASS: Restored '+str(len(missing_assets))+' missing original assets (zero overwrites)')
print('PASS: V29.1 installed; backed up 4 originals to '+str(backup))
print('NOTE: Supabase V29.1 migration is already installed. No SQL or asset replacement required.')
