55 AMBERLANDS V30.5 — HUD + LOGO VISUAL FIX

ต่อจาก V30.4 (ลงตัว FIXED แล้ว) เท่านั้น
- เปลี่ยนรูปโลโก้จากชุด V1 เป็นภาพแบรนด์ที่ดึงอาร์ตจริงจาก V28 ที่เจ้าของส่งมา
- ตัดคำสั่งเปลี่ยนฉากภาพเก่าใน renderScene แต่รักษาแคนวาส Pixel V24
- ย้าย HUD ยา HP/MP/AUTO ไปอยู่ในส่วนบนตรงสเตตัสตัวละคร ไม่สร้างทับท้ายฉาก
- ไม่สร้างป้าย Lv/Rebirth ซ้ำอีกชุด เพราะแสดงในตัวละครอยู่แล้ว
- ลด Glow ที่ซ้อนกันและลดความสว่างหน้า Real Time
- ห้ามแก้ข้อมูล/SQL/คำนวณดาเมจ

ติดตั้ง: อัปโหลด ZIP ไปที่ GitHub root ผ่าน Add file > Upload files > Commit changes
จากนั้น Codespaces Terminal รัน ONE-LINER ที่ผู้ช่วยส่งให้

หาก Error ให้ส่งข้อความ Terminal และอย่า Deploy ซ้ำโดยไม่ดูสาเหตุ
ตัวติดตั้งตรวจ JavaScript syntax และโครงไฟล์จริง โดยไม่ต้องใช้ Pillow ใน Codespaces
ผลการแสดงจริงต้องทดลองบนมือถือ
