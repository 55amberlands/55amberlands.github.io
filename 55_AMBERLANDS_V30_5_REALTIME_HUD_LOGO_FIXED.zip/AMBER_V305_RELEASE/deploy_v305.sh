#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
if [[ "$(git branch --show-current)" != main ]]; then echo 'STOP: Switch to main first.'; exit 1; fi
if [[ -n "$(git status --porcelain --untracked-files=no)" ]]; then echo 'STOP: Uncommitted tracked changes: protect your work.'; exit 1; fi
git pull --ff-only origin main
python3 "$(dirname "$0")/install_v305.py"
node --check v28_battle_hud.js
node --check v305_visual_fix.js
python3 - <<'PY'
from pathlib import Path
import struct
s=Path('index.html').read_text(encoding='utf-8')
assert s.count('v305_visual_fix.js?v=305_layout_fixed_1')==1
assert s.count('AMBERLANDS_V28_BANNER.png')==1
assert 'scene.insertAdjacentElement(\'afterend\', h)' not in Path('v28_battle_hud.js').read_text()
p=Path('icons/AMBERLANDS_V28_BANNER.png')
assert p.exists() and p.stat().st_size > 10000
assert p.read_bytes()[:8]==b'\x89PNG\r\n\x1a\n'
assert struct.unpack('>II',p.read_bytes()[16:24])==(1200,296)
print('PASS: V30.5 DOM source + logo asset + scripts checked')
PY

git diff --check
git add index.html v28_battle_hud.js v305_visual_fix.js icons/AMBERLANDS_V28_BANNER.png
if git diff --cached --quiet; then echo 'V30.5 already applied'; exit 0; fi
git commit -m 'V30.5 restore V28 branding and remove duplicate realtime HUD'
git push origin main
echo 'PASS: V30.5 committed and pushed. Verify GitHub Actions + live browser.'
