#!/usr/bin/env python3
"""55 AMBERLANDS V30.5 - source-level UI fix based on deployed V30.4.
Only writes index.html, v28_battle_hud.js and two new presentation assets.
No player data, Supabase SQL, gameplay formulas or currency are touched.
"""
from pathlib import Path
import os,sys,subprocess,shutil
root=Path.cwd(); src=Path(__file__).resolve().parent
idxfile=root/'index.html'; hudfile=root/'v28_battle_hud.js'
if not idxfile.exists() or not hudfile.exists() or not (root/'v304_stability_title.js').exists():
    sys.exit('STOP: Requires deployed V30.4 (index.html, v28_battle_hud.js, v304_stability_title.js). No changes.')
index=idxfile.read_text(encoding='utf-8'); hud=hudfile.read_text(encoding='utf-8')
if './v305_visual_fix.js?v=305_layout_fixed_1' in index:
    print('V30.5 already installed; nothing changed.');sys.exit(0)
if 'v304_stability_title.js' not in index:
    sys.exit('STOP: V30.4 script not present. No files changed.')
def one(s,old,new,reason):
    count=s.count(old)
    if count!=1:
        sys.exit(f'STOP: {reason}: expected 1 match, saw {count}; no files changed.')
    return s.replace(old,new,1)
# Make the new official V28 brand the ONLY first-paint logo source;
# V30.4 incorrectly pinned the original 2023 procedural logo forever.
index=one(index,"$('logo').src=image('logo');","$('logo').src='./icons/AMBERLANDS_V28_BANNER.png';",'restore V28 game logo')
# Stop old map artwork being assigned every render; V24 pixel canvas owns backdrop.
index=one(index,"$('scene').style.backgroundImage=`linear-gradient(180deg,#0001,#0002),url(\"${image(map()[4])}\")`;", "$('scene').style.backgroundImage='none';",'disable legacy scene background')
index=one(index,'<script src="./v304_stability_title.js?v=304_title_v1"></script>', '<script src="./v304_stability_title.js?v=304_title_v1"></script>\n<script src="./v305_visual_fix.js?v=305_layout_fixed_1"></script>', 'load V30.5 last')
# Old V28 inserted HUD after the live game scene, colliding with the nav. Relocate
# its working potion controls to the profile itself. Lv/Rebirth already appear above.
old="""  const st = ST(), scene = $('scene'); if (!st || !scene) return;
  let h = $('px28Hud'); if (!h) { h = document.createElement('div'); h.id = 'px28Hud'; scene.insertAdjacentElement('afterend', h); }
  const html = `<div class="px28-hl">${chipHTML()}</div><div class="px28-hq">${quickHTML()}</div>`; if (h.dataset.s !== html) { h.dataset.s = html; h.innerHTML = html; }"""
new="""  const st = ST(), info = document.querySelector('.top .statsline'); if (!st || !info) return;
  let h = $('px28Hud'); if (!h) { h = document.createElement('div'); h.id = 'px28Hud'; }
  if (h.parentNode !== info) info.appendChild(h);
  // The original Lv/Rebirth and potion bar below the scene were redundant.
  // Keep real potion/AUTO buttons, but render ONE compact bar inside the profile.
  const html = `<div class="px28-hq">${quickHTML()}</div>`; if (h.dataset.s !== html) { h.dataset.s = html; h.innerHTML = html; }"""
hud=one(hud,old,new,'relocate floating V28 HUD into character profile')
# Asset files are copied only after *every* check above succeeds.
git_dir=subprocess.check_output(['git','rev-parse','--git-dir'],text=True).strip()
backup=(root/git_dir/'amber_v305_backup') if not os.path.isabs(git_dir) else Path(git_dir)/'amber_v305_backup'
backup.mkdir(parents=True,exist_ok=True)
for path,orig in ((idxfile,idxfile.read_text(encoding='utf-8')),(hudfile,hudfile.read_text(encoding='utf-8'))):
    b=backup/path.name
    if not b.exists():b.write_text(orig,encoding='utf-8')
(root/'icons').mkdir(exist_ok=True)
idxfile.write_text(index,encoding='utf-8')
hudfile.write_text(hud,encoding='utf-8')
shutil.copy2(src/'payload/v305_visual_fix.js',root/'v305_visual_fix.js')
shutil.copy2(src/'payload/AMBERLANDS_V28_BANNER.png',root/'icons/AMBERLANDS_V28_BANNER.png')
print('PASS: V30.5 source updated; HUD moved into profile, old map art removed, V28 logo restored.')
print('Backups:',backup)
