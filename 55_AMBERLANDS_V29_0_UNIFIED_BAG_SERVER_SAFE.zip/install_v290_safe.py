#!/usr/bin/env python3
"""Install V29.0 client only. Server SQL is intentionally a separate tracked migration.

Guards: never edit player data/SQL/assets; backup index.html; atomic replace and idempotence.
"""
import argparse, pathlib, shutil, subprocess, sys, datetime
p=argparse.ArgumentParser()
p.add_argument('--check',action='store_true')
p.add_argument('--apply',action='store_true')
p.add_argument('--root',default='.')
a=p.parse_args()
root=pathlib.Path(a.root).resolve()
index=root/'index.html'
new_js=root/'v290_inventory_unified.js'
source=root/'v290_patch'/'v290_inventory_unified.js'
marker='<script src="./v290_inventory_unified.js?v=2900"></script>'
required=['v277_authority_client.js','v278_pet_authority.js','v23_pet_shop.js','v23_2_boss_loot.js','v16_inventory_market.js','tools/check_static_site.py']
def die(t):raise SystemExit('STOP SAFELY: '+t)
if not index.is_file():die('index.html not found: '+str(root))
if not source.is_file() and not new_js.is_file():die('v290_patch/v290_inventory_unified.js not found; unzip first')
for x in required:
 if not (root/x).is_file():die('required baseline missing: '+x)
s=index.read_text('utf-8')
if '</body>' not in s or 'v278_pet_authority.js' not in s or 'v277_authority_client.js' not in s:die('unexpected index.html base')
if s.count('</body>')!=1:die('unexpected index.html end tag count')
if marker in s and new_js.is_file():
 if a.apply:print('PASS: Already installed; no modifications')
 else:print('PASS: Already installed')
 raise SystemExit(0)
if 'v290_inventory_unified.js' in s or new_js.exists():die('V29.0 partially installed; inspect before retry')
if marker not in s and s.find('</body>')<s.find('v278_pet_authority.js'):die('script load order changed')
src=source.read_text('utf-8')
if 'Server-projected unified inventory' not in src or 'amber_v290_inventory_manifest' not in src or 'v290Enhance' not in src:die('unexpected JS payload')
try:
 checked=subprocess.run(['node','--check',str(source)],capture_output=True,text=True)
 if checked.returncode:die('JavaScript syntax invalid: '+checked.stderr[:220])
except FileNotFoundError:print('WARN: node not installed, JavaScript syntax check skipped')
print('PASS: Baseline and payload checked (no character data modified)')
if a.apply:
 backup=root/'.amber_patch_backups'/('v290_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
 backup.mkdir(parents=True,exist_ok=False)
 shutil.copy2(index,backup/'index.html')
 tmp=root/'index.html.v290tmp'
 tmp.write_text(s.replace('</body>',marker+'</body>',1),'utf-8')
 shutil.copy2(source,new_js)
 tmp.replace(index)
 print('PASS: V29.0 client installed, index.html backup: '+str(backup/'index.html'))
 print('NOTE: SQL migration must be present in Supabase for inventory and ore RPC to work.')
if not a.apply and not a.check:print('No action taken. Use --check or --apply')
