55 AMBERLANDS V29.0 — กระเป๋าหลักทุกชนิด + แร่ตีบวก Supabase (2026-10-26)
==================================================================
สถานะที่ตรวจสอบแล้ว:
- Supabase โครงการเดิมติดตั้ง migration amber_v290_unified_inventory_server_ore_fixed สำเร็จแล้ว
- ไม่ต้องรัน SQL อีก หากใช้ Supabase โครงการเดิม
- 22 ตัวละคร / 22 โปรไฟล์เดิมยังอยู่
- GitHub ไม่เปิดสิทธิ์เขียนให้ผู้ช่วย (403) จึงต้องใช้ Codespaces คำสั่งชุดเดียว

ทำอะไรบ้าง
1. กระเป๋าหลัก (เมนูเปิดกระเป๋า) แสดงยาฟื้นฟู, ไอเทมทั่วไป, อุปกรณ์,
   แร่ทุกชนิด, Item Shop/ปีก, ของสัตว์เลี้ยง ในพื้นที่เดียว
2. ทุกตัวเลขแสดงจาก RPC ที่ตรวจตัวตน: public.amber_v290_inventory_manifest()
3. ไม่มีการคัดลอก/ย้าย/เขียนแถวไอเทมจริง จึงไม่สร้างไอเทมซ้ำ
4. เวลาเลือกแร่เสริมตีบวก ส่งชนิดแร่ให้ Supabase ตรวจและหักครั้งเดียว
   เพิ่มโอกาสสำเร็จตามแร่เดิม (+5% หรือ +10% สูงสุด 95%)
5. ไม่เปลี่ยน asset / ภาพตัวละคร / map / สูตรตีแบบไม่ใช้แร่ / ข้อมูลตัวละคร

วิธีทำ
(1) ดาวน์โหลด ZIP นี้ แล้วเข้า GitHub repo 55amberlands.github.io
    เลือก Add file > Upload files > เลือก ZIP > Commit changes
(2) เปิด Codespaces > Terminal คัดลอกทุกบรรทัดนี้ไปวางทีเดียว

set -e
git pull --ff-only origin main
unzip -o 55_AMBERLANDS_V29_0_UNIFIED_BAG_SERVER_SAFE.zip -d .
python3 install_v290_safe.py --check
python3 install_v290_safe.py --apply
python3 tools/check_static_site.py
git diff --check
git add index.html v290_inventory_unified.js
git commit -m "V29.0 unified server inventory and ore enhancement"
git push origin main

สิ่งที่ต้องทดสอบหลัง Deploy (Google login):
- เปิดกระเป๋าหลัก ต้องแสดงของครบ ไม่ซ้ำจำนวน: bag, gear, mats, potions, shop20, pet23
- ลองใช้ยา 1 ขวด, สวม/ถอดอุปกรณ์, ใช้อาหารสัตว์เลี้ยง
- ลองแร่รุ้งตีบวกเฉพาะไอเทมทดสอบ แล้วตรวจแร่หาย 1 และระบบตอบรับครั้งเดียว
- ทดลองเปิดจากมือถือและอีกอุปกรณ์หลัง login account เดียวกัน
- รีโหลด/ออกเข้าใหม่ไม่ควรเพิ่ม Gold/Gems/ไอเทม

ข้อจำกัด:
- การย้ายเกมทั้งหมดไป Supabase ไม่สามารถทำได้เป็นแพตช์ครั้งเดียว
  ยังต้องตรวจเพิ่มเติม: card album / daily reward / offline fallbacks / world/boss legacy
- ระบบภาพ/ปุ่ม/ภาพเคลื่อนไหวต้องอยู่ใน JavaScript
- เกมยังไม่ได้ถูกทดสอบออนไลน์ด้วยบัญชีผู้เล่นจริงจากฝั่งผู้ช่วย
- หากพบ STOP ให้หยุด ไม่ใช้ git push --force และไม่ลบฐานข้อมูล
