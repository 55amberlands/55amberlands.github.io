# 55 AMBERLANDS V29.0 — ตรวจระบบไอเทมและจุดเสี่ยงการโกง
วันที่ 26 ต.ค. 2026

## ข้อมูลอ้างอิงก่อนติดตั้ง
- GitHub: `55amberlands/55amberlands.github.io` (`main`)
- Supabase: `55-amberlands`, project id `rfijdwnzuhvlkfptyoiy`
- ตัวละคร 22 โปรไฟล์ 22; แถวทะเบียนอุปกรณ์ `private.amber_v285_gear_registry` 189
- รายการก่อนแก้รวม (จำนวนระเบียน ไม่ใช่ชิ้น): `bag` 93, `gear` 163, `shop20.owned` 24, `pet23.items` 9
- แร่พบคีย์ `gw`, `ga`, `ore_prism`; โค้ดรองรับ `ore_fire`, `ore_ice` ด้วย

## แหล่งเก็บปัจจุบัน
| กลุ่ม | ที่อยู่ในเซฟ | ระบบตรวจการเปลี่ยนกรรมสิทธิ์ |
|---|---|---|
| ไอเทมทั่วไป/ของดรอป | `bag[]` | server combat, inventory, NPC/market RPC |
| อาวุธและอุปกรณ์ | `gear[]`, `eq` | server RPC และ gear registry |
| ยา HP/MP | `potHP`, `potMP` | server recovery/economy RPC |
| แร่ทุกชนิด | `mats` | server dungeon drops / enhancement |
| ปีก/ร้านคอยล์ | `shop20.owned[]` | `amber_v277_economy` และ recovery RPC |
| ไอเทมสัตว์เลี้ยง | `pet23.items[]` | `amber_v278_pet`, `amber_v289_buy_pet_food` |

## การแก้ไขใน V29.0
1. ติดตั้ง `public.amber_v290_inventory_manifest()` ซึ่งอ่านเซฟเฉพาะ `auth.uid()` เพื่อส่งรายการ **สำหรับแสดงผล** แยก `kind` พร้อม `id`, `name`, `qty`; ไม่มี DML ของตัวละคร
2. แสดงทั้ง 6 แหล่งใน *กระเป๋าหลักเดียว* โดยไม่สร้างสำเนาสินทรัพย์หรือเพิ่มจำนวนช่องจริงของฐานข้อมูล
3. `amber_v277_economy` ส่วน `enhance` รับ `ore` เพิ่มแบบเลือกได้; ตรวจแร่/ช่องอุปกรณ์/คงเหลือด้วย server, หัก 1 แร่ใน transaction เดียวกับการสุ่ม (แร่ไฟและน้ำแข็ง +5%; แร่รุ้ง +10%; เพดาน 95%)
4. ฝั่ง JS ใช้ Supabase เป็นแหล่งข้อมูลการแสดงและส่งคำสั่งตีบวก ไม่หักแร่เอง; ปุ่มอื่น ๆ ใช้ระบบ RPC เดิม
5. ถ้า RPC โหลดไม่สำเร็จ แสดงข้อมูลหน้ากระเป๋าเดิมชั่วคราว ไม่บันทึก/สร้างไอเทมขึ้นใหม่

## ตรวจสิทธิ์ Supabase
- `public.amber_characters` RLS enabled, `anon`/`authenticated` ไม่ได้สิทธิ์ UPDATE ตรง
- `public.amber_v290_inventory_manifest`: ให้ EXECUTE เฉพาะ `authenticated`, ไม่ให้ `anon`
- ทดสอบ RPC โดยไม่มี session ถูกปฏิเสธด้วย `V290_LOGIN_REQUIRED`
- ฟังก์ชันเพิ่มแร่สำเร็จในการติดตั้งเป็น schema migration และตรวจว่ามี marker V290 จริง
- ระเบียนตัวละครก่อน/หลัง migration ยังคง 22, ไม่ได้เปลี่ยนผู้เล่นรายใด

## สิ่งที่ยังไม่ย้ายและความเสี่ยงคงเหลือ
- `v25_systems.js` ยังมีส่วน award/check-in/cards ที่คำนวณบนเบราว์เซอร์; ส่วนที่มีผลต่อ economy/progression ต้องทบทวนและแปลงเป็นเซิร์ฟเวอร์ทีละธุรกรรม พร้อมพิสูจน์การได้รับรางวัลจากกิจกรรมจริง
- HTML `index.html` ยังคงโค้ดเกมออฟไลน์เดิม (เช่น `addItem`, `tick`, `upStat`, `buy`), แม้เวอร์ชันออนไลน์ override บางคำสั่งผ่าน `v277_authority_client.js`; ต้องทำ integration test ยืนยันทุกเส้นทางไม่มี fallback ที่เขียนของจริงได้
- ภาพบัฟ/บางสูตรการ์ดที่ JS แสดงอาจต่างจาก server-authoritative combat; ต้องตรวจสมดุลก่อนนำไปเพิ่มใน server
- ตลาด, ดันเจียน, ปาร์ตี้, เควสต์ และ login ควรทำ penetration test กับบัญชี **สำหรับทดสอบที่ได้รับอนุญาต** ไม่ใช้บัญชีจริงของผู้เล่น
- การป้องกันโกงสมบูรณ์ต้องตรวจทุก RPC, policy, idempotency, concurrency, reward receipt และ rate limits ไม่ใช่เพียงย้ายโค้ด JS ไป SQL

## การทดสอบที่ทำแล้ว
- `node --check v290_inventory_unified.js`: PASS
- `python install_v290_safe.py --check`: PASS (กับสำเนาเว็บที่มีโครงสร้างเดิม)
- `python install_v290_safe.py --apply`: PASS และสร้างสำรอง index.html
- `python tools/check_static_site.py`: PASS (7 HTML pages; all static links found)
- Supabase migration: SUCCESS
- Supabase no-session RPC: `V290_LOGIN_REQUIRED` (expected)
- Supabase authenticated EXECUTE=true; anon EXECUTE=false

## ยังไม่ได้ตรวจ
- ยังไม่ได้ให้บัญชีผู้เล่นจริงออนไลน์ลองเปิดและใช้ทุกไอเทม
- ยังไม่ได้ push เข้า GitHub production เพราะ GitHub connector คืน 403 เมื่อขอสิทธิ์เขียน
