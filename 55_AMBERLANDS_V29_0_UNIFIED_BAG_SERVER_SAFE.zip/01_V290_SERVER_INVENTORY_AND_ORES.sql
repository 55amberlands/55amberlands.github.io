-- 55 AMBERLANDS V29.0: authenticated inventory projection and atomic server ore enhancement.
-- No tables / players are changed. Inventory projection never transfers or duplicates items.
BEGIN;
CREATE OR REPLACE FUNCTION public.amber_v290_inventory_manifest()
RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path TO ''
AS $body$
DECLARE
  u uuid := (SELECT auth.uid()); s jsonb; items jsonb := '[]'::jsonb;
  x jsonb; k text; v jsonb; ident text; nm text; q integer; slot text;
  eq jsonb; n integer:=0;
BEGIN
  IF u IS NULL THEN RAISE EXCEPTION 'V290_LOGIN_REQUIRED'; END IF;
  SELECT save_data INTO s FROM public.amber_characters WHERE user_id=u;
  IF s IS NULL OR pg_catalog.jsonb_typeof(s)<>'object' THEN RAISE EXCEPTION 'V290_CHARACTER_REQUIRED'; END IF;
  eq:=CASE WHEN pg_catalog.jsonb_typeof(s->'eq')='object' THEN s->'eq' ELSE '{}'::jsonb END;
  -- The 2 potion stacks always belong to the main inventory.
  FOR k IN SELECT pg_catalog.unnest(ARRAY['potHP','potMP']) LOOP
    IF coalesce(s->>k,'') ~ '^[0-9]{1,7}$' THEN
      q:=least(999999,(s->>k)::int);
      IF q>0 THEN
        items:=items||pg_catalog.jsonb_build_array(pg_catalog.jsonb_build_object(
          'kind','potion','id',CASE WHEN k='potHP' THEN 'hp' ELSE 'mp' END,
          'name',CASE WHEN k='potHP' THEN 'ยาฟื้น HP' ELSE 'ยาฟื้น MP' END,'qty',q,
          'icon',CASE WHEN k='potHP' THEN '🧪' ELSE '💧' END));
      END IF;
    END IF;
  END LOOP;
  IF pg_catalog.jsonb_typeof(s->'bag')='array' THEN
    FOR x IN SELECT value FROM pg_catalog.jsonb_array_elements(s->'bag') v(value) LIMIT 200 LOOP
      IF pg_catalog.jsonb_typeof(x)<>'object' THEN CONTINUE; END IF;
      ident:=x->>'id';nm:=x->>'name';
      IF coalesce(x->>'qty','') !~ '^[0-9]{1,7}$' THEN CONTINUE; END IF;
      q:=least(999999,(x->>'qty')::int);
      IF q>0 AND pg_catalog.length(coalesce(ident,'')) BETWEEN 1 AND 128 THEN
        items:=items||pg_catalog.jsonb_build_array(pg_catalog.jsonb_build_object('kind','bag','id',ident,'name',pg_catalog.left(coalesce(nm,'ไอเทม'),100),'qty',q,'icon',pg_catalog.left(coalesce(x->>'icon','📦'),16)));
      END IF;
    END LOOP;
  END IF;
  IF pg_catalog.jsonb_typeof(s->'gear')='array' THEN
    FOR x IN SELECT value FROM pg_catalog.jsonb_array_elements(s->'gear') v(value) LIMIT 100 LOOP
      IF pg_catalog.jsonb_typeof(x)<>'object' THEN CONTINUE; END IF;
      ident:=x->>'id';slot:=x->>'slot';
      IF pg_catalog.length(coalesce(ident,'')) NOT BETWEEN 1 AND 128 THEN CONTINUE; END IF;
      items:=items||pg_catalog.jsonb_build_array(pg_catalog.jsonb_build_object('kind','gear','id',ident,
        'name',pg_catalog.left(coalesce(x->>'name','อุปกรณ์'),100), 'qty',1,'slot',coalesce(slot,''),
        'enh',CASE WHEN coalesce(x->>'enh','') ~ '^[0-9]{1,2}$' THEN least(10,(x->>'enh')::int) ELSE 0 END,
        'equipped',coalesce(eq->>slot,'')=ident,'boss',coalesce(x->>'boss','false')='true' OR coalesce(x->>'bossDrop','false')='true' OR ident LIKE 'dg_%'));
    END LOOP;
  END IF;
  IF pg_catalog.jsonb_typeof(s->'mats')='object' THEN
    FOR k,v IN SELECT key,value FROM pg_catalog.jsonb_each(s->'mats') a(key,value) LOOP
      IF pg_catalog.length(k)>48 OR k !~ '^[a-zA-Z0-9_]+$' OR pg_catalog.jsonb_typeof(v)<>'number' OR v::text !~ '^[0-9]{1,7}$' THEN CONTINUE; END IF;
      q:=least(999999,(v::text)::int);
      IF q>0 THEN
        nm:=CASE k WHEN 'gw' THEN 'เพชรเพลิงมังกร' WHEN 'ga' THEN 'ไข่มุกพิทักษ์' WHEN 'ore_fire' THEN 'แร่อัคคี' WHEN 'ore_ice' THEN 'แร่เหมันต์' WHEN 'ore_prism' THEN 'แร่รุ้งดารา' ELSE 'วัสดุ '||k END;
        items:=items||pg_catalog.jsonb_build_array(pg_catalog.jsonb_build_object('kind','material','id',k,'name',nm,'qty',q,
          'icon',CASE k WHEN 'gw' THEN '🔥' WHEN 'ga' THEN '🛡️' WHEN 'ore_fire' THEN '🔥' WHEN 'ore_ice' THEN '❄️' WHEN 'ore_prism' THEN '🌈' ELSE '💎' END));
      END IF;
    END LOOP;
  END IF;
  IF pg_catalog.jsonb_typeof(s#>'{shop20,owned}')='array' THEN
    FOR x IN SELECT value FROM pg_catalog.jsonb_array_elements(s#>'{shop20,owned}') v(value) LIMIT 150 LOOP
      IF pg_catalog.jsonb_typeof(x)<>'object' THEN CONTINUE; END IF;
      ident:=x->>'id';k:=x->>'sku';
      IF pg_catalog.length(coalesce(ident,'')) NOT BETWEEN 1 AND 128 THEN CONTINUE; END IF;
      nm:=CASE WHEN k LIKE 'sun_%' THEN 'ปีกสุริยันสวรรค์' WHEN k LIKE 'moon_%' THEN 'ปีกจันทรารัตติกาล'
       WHEN k='reset_skill' THEN 'น้ำยารีเซ็ตสกิล' WHEN k='reset_stat' THEN 'น้ำยารีเซ็ตสเตตัส' ELSE 'Item Shop '||coalesce(k,'') END;
      items:=items||pg_catalog.jsonb_build_array(pg_catalog.jsonb_build_object('kind','shop','id',ident,'name',nm,'qty',1,'sku',k,
       'expiresAt',x->>'expiresAt','equipped',coalesce(s#>>'{shop20,equipped}','')=ident,'icon',CASE WHEN k LIKE '%sun%' OR k LIKE '%moon%' THEN '🪽' ELSE '🧪' END));
    END LOOP;
  END IF;
  IF pg_catalog.jsonb_typeof(s#>'{pet23,items}')='array' THEN
    FOR x IN SELECT value FROM pg_catalog.jsonb_array_elements(s#>'{pet23,items}') v(value) LIMIT 160 LOOP
      IF pg_catalog.jsonb_typeof(x)<>'object' OR coalesce(x->>'qty','') !~ '^[0-9]{1,7}$' THEN CONTINUE; END IF;
      ident:=x->>'id';k:=x->>'sku';q:=least(999999,(x->>'qty')::int);
      IF q<1 OR pg_catalog.length(coalesce(ident,'')) NOT BETWEEN 1 AND 128 THEN CONTINUE; END IF;
      nm:=CASE k WHEN 'dog' THEN 'ลูกสุนัขผู้พิทักษ์' WHEN 'food' THEN 'อาหารสุนัขวิเศษ' WHEN 'duo' THEN 'บัตร DUO Pet Skill'
        WHEN 'shield' THEN 'ตำราเกราะพิทักษ์' WHEN 'regen' THEN 'ตำราฟื้นฟู HP/MP' WHEN 'attack' THEN 'ตำราพลังนักล่า' ELSE 'ไอเทมสัตว์เลี้ยง '||coalesce(k,'') END;
      items:=items||pg_catalog.jsonb_build_array(pg_catalog.jsonb_build_object('kind','pet','id',ident,'name',nm,'qty',q,'sku',k,
        'icon',CASE WHEN k='food' THEN '🦴' WHEN k='dog' THEN '🐶' ELSE '📜' END));
    END LOOP;
  END IF;
  RETURN pg_catalog.jsonb_build_object('ok',true,'items',items,'count',pg_catalog.jsonb_array_length(items),'generated_at',clock_timestamp());
END
$body$;
REVOKE ALL ON FUNCTION public.amber_v290_inventory_manifest() FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.amber_v290_inventory_manifest() TO authenticated;
-- Make the existing server-side enhancement use and consume ores ATOMICALLY.
-- Guard against changes to the V28.9 economy function body.
DO $patch$
DECLARE f oid; body_sql text; old_text text; new_text text;
BEGIN
 SELECT p.oid INTO f FROM pg_catalog.pg_proc p JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace
  WHERE n.nspname='public' AND p.proname='amber_v277_economy' AND p.prokind='f';
 IF f IS NULL THEN RAISE EXCEPTION 'V290_ECONOMY_NOT_FOUND'; END IF;
 body_sql:=pg_catalog.pg_get_functiondef(f);
 old_text:=$old$chance:=(ARRAY[100,100,100,90,80,65,50,40,30,20])[enh+1];succeeded:=random()*100<chance;$old$;
 new_text:=$new$chance:=(ARRAY[100,100,100,90,80,65,50,40,30,20])[enh+1];
    -- V290: the server alone validates/consumes enhancement ores, then rolls.
    st:=nullif(p_args->>'ore','');
    IF st IS NOT NULL THEN
      IF st NOT IN ('ore_fire','ore_ice','ore_prism') OR
         (st='ore_fire' AND i->>'slot'<>'W') OR
         (st='ore_ice' AND i->>'slot'='W') THEN
        RAISE EXCEPTION 'V290_INVALID_ENHANCEMENT_ORE'; END IF;
      IF coalesce((mats->>st)::int,0)<1 THEN RAISE EXCEPTION 'V290_ORE_NOT_OWNED'; END IF;
      -- No need to use an ore when the unmodified roll is already 100 percent.
      IF chance<100 THEN
        mats:=pg_catalog.jsonb_set(mats,ARRAY[st],pg_catalog.to_jsonb((mats->>st)::int-1),true);
        chance:=least(95,chance+CASE WHEN st='ore_prism' THEN 10 ELSE 5 END);
      ELSE st:=NULL; END IF;
    END IF;
    succeeded:=random()*100<chance;$new$;
 IF pg_catalog.strpos(body_sql,'V290: the server alone validates/consumes enhancement ores')>0 THEN
   NULL;
 ELSIF (pg_catalog.length(body_sql)-pg_catalog.length(pg_catalog.replace(body_sql,old_text,'')))=pg_catalog.length(old_text) THEN
   body_sql:=pg_catalog.replace(body_sql,old_text,new_text);
   EXECUTE body_sql;
 ELSE
   RAISE EXCEPTION 'V290_ECONOMY_SIGNATURE_CHANGED';
 END IF;
END
$patch$;
COMMIT;
NOTIFY pgrst,'reload schema';
