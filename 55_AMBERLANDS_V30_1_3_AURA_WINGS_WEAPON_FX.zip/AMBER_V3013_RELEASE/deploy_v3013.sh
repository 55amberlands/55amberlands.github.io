#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
if [[ "$(git branch --show-current)" != main ]]; then echo 'STOP: switch to main first'; exit 1; fi
for f in index.html v25_systems.js v24_px_weapons.js v24_px_heroes.js; do
  if ! git diff --quiet -- "$f" || ! git diff --cached --quiet -- "$f"; then
    echo "STOP: locally modified target file $f. Commit it first or send the git status (do not reset)."; exit 1
  fi
done
python3 "$(dirname "${BASH_SOURCE[0]}")/install_v3013.py"
for f in v25_systems.js v24_px_weapons.js v24_px_heroes.js; do node --check "$f"; done
git diff --check -- index.html v25_systems.js v24_px_weapons.js v24_px_heroes.js
git add -- index.html v25_systems.js v24_px_weapons.js v24_px_heroes.js
if git diff --cached --quiet; then echo 'PASS: V30.1.3 already present; no change needed'; exit 0; fi
git commit -m "V30.1.3 put aura behind wings and render in-hand +7-10 glow"
git push origin main
echo 'PASS: V30.1.3 committed and pushed; check GitHub Actions before testing game'
