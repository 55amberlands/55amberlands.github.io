'use strict';
const fs=require('fs'); const vm=require('vm');const assert=require('assert');
const code=fs.readFileSync(process.argv[2]||'v24_px_weapons.js','utf8');
const hash=s=>{let h=0;for(const c of String(s))h=(h*31+c.charCodeAt(0))|0;return Math.abs(h)};
const rng=seed=>{let t=(seed|0)>>>0;return ()=>{t=(1664525*t+1013904223)>>>0;return t/4294967296}};
const PX={hash,rng,alpha:(color,a)=>`${color}@${a}`,Sp:class {},P:()=>{},mix:()=>{},ramp:()=>{}};
vm.runInNewContext(code,{window:{PX},Math,Number}, {timeout:10000});
assert(PX.weapon&&PX.weapon.fx&&PX.weaponSpec&&PX.weaponKey);
const shapes=['หมัด','ดาบ','ธนู','จอมเวท'];
for(const cls of shapes){
const results=[];
for(const enh of [6,7,8,9,10]){
 const spec=PX.weaponSpec({id:`dg_${cls}`,name:`อาวุธบอสดันเจียน-${cls}`,cls,enh,lv:60,boss:true});
 const pix=[];const dst={px:(x,y,col)=>{assert(Number.isFinite(x)&&Number.isFinite(y));pix.push(col)}};
 PX.weapon.fx(dst,spec,42,48,12,.26,1);
 results.push({enh,count:pix.length,colors:new Set(pix).size});
}
assert(results[0].count>0,"theme's pre-existing particles still work");
assert(results[1].count<results[2].count&&results[2].count<results[3].count&&results[3].count<results[4].count,'each enhancement adds visible sparkle density');
let base=PX.weaponSpec({id:'dg_test',name:'อาวุธบอสดันเจียน',cls,enh:7,boss:true});let upgraded=PX.weaponSpec({id:'dg_test',name:'อาวุธบอสดันเจียน',cls,enh:10,boss:true});
assert.notStrictEqual(PX.weaponKey(base),PX.weaponKey(upgraded),'sprite cache keys must change with +level');
console.log('PASS class',cls,JSON.stringify(results));
}
// Nonboss normal weapons must also show the correct enhanced sparks; low tiers don't.
for(const lvl of [6,7,8,9,10]) {
 const spec=PX.weaponSpec({id:'normalweapon',name:'ดาบนักรบ',cls:'ดาบ',enh:lvl,lv:20});
 const d={dots:[],px(x,y,c){this.dots.push(c)}};PX.weapon.fx(d,spec,38,38,0,.5,1);
 assert((d.dots.length>0)===(lvl>=7),'correct spark threshold for normal weapons');
 console.log('PASS normal +',lvl,'pixels',d.dots.length);
}
console.log('PASS: runtime FX pixel emission, four classes, 5 levels, cache key');
