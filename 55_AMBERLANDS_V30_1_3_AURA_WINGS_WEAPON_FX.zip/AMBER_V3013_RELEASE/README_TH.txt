55 AMBERLANDS V30.1.3 — AURA BEHIND / DUNGEON ENHANCE FX
BASE: V30.1.2 + V30.1.1 ONLY (before the new 10 world bosses)

FIXES:
1. Real-time scene title aura behind wings and player, no extra character layer.
2. Existing title / player name remain at front. Keep V30.1.2 72x110 proportions.
3. Boss ambient equipment auras stay behind hero, avoiding translucent overlay on face.
4. In-hand Pixel V24 weapons now show level-dependent sparkles: +7 blue, +8 gold,
   +9 pink-violet, +10 bright white/rainbow with small translucent vapor.
5. Sprite cache separates enhancement levels, so a gear update refreshes the visible weapon.
6. Bow path now draws weapon sparkles just as fists/swords/mage weapons do.

VISUAL ONLY. No DB / Supabase / combat formulas / damage / stats / inventory changes.
Does NOT restore V28 world-boss systems. Does not grant items.
Colors and density of enhancement sparks are a new visual fix for V30.1.3;
not a claim that Codex's original sprite sheet was preserved.

DEPLOY:
1. Upload 55_AMBERLANDS_V30_1_3_AURA_WINGS_WEAPON_FX.zip to GitHub main with
   Add file > Upload files > Commit changes.
2. Codespaces Terminal:
cd "$(git rev-parse --show-toplevel)" && git switch main && git pull --ff-only origin main && unzip -oq 55_AMBERLANDS_V30_1_3_AURA_WINGS_WEAPON_FX.zip -d .git/amber_v3013 && bash .git/amber_v3013/AMBER_V3013_RELEASE/deploy_v3013.sh
3. Confirm GitHub Actions successful; reload on Android.
4. Check title sits in front, wings in middle, original body unobstructed;
   compare an equipped weapon +7/+8/+9/+10 visually. Only worn weapons glow in live scene.

Safety: installer stops if the wrong base release is detected or target files have
uncommitted local edits. It keeps local <filename>.v3013bak backups (untracked).
