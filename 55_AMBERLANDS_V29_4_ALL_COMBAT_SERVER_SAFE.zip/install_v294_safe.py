#!/usr/bin/env python3
"""V29.4 audited, hash-pinned, rollback-safe patch for Codespaces.
Only modifies index.html and v277_authority_client.js, adds one JS bridge.
All database changes have already been applied separately via Supabase.
"""
import argparse
import hashlib
import pathlib
import shutil
import subprocess
import sys
from datetime import datetime, timezone

ROOT=pathlib.Path(__file__).resolve().parent
# Code is pinned to the exact deployed Git blobs, not filename/version alone.
EXPECTED={
    'index.html':{'9529af5130165d30484e20ae1d9346fd79d60f45','89151ec850ad4436268e18d2f2a4a1467e9c06e5'},
    'v277_authority_client.js':{'281d3a18ac467e066d0166893b7828ef6be27048'},
}
V277_OLD="if(!m||m.boss){if(state.auto)stop();tell('👑 บอสต้องเข้าเรดหรือดันเจียนที่ Supabase ตรวจสอบ');return;}"
V277_NEW="if(!m||(m.boss&&['dungeon','worldboss'].includes(m.map))){if(state.auto)stop();tell('👑 บอสโลกและดันเจียนต้องใช้โหมดเรดที่ Supabase ตรวจสอบ');return;}"
BEFORE="<script src=\"./v290_inventory_unified.js?v=2911\"></script></body></html>"
AFTER="<script src=\"./v290_inventory_unified.js?v=2911\"></script><script src=\"./v294_world_map_boss_bridge.js?v=294_server_combat\"></script></body></html>"

def githash(blob):
    return hashlib.sha1(b'blob '+str(len(blob)).encode()+b'\0'+blob).hexdigest()

def make_patches():
    patch={}
    for name, hashes in EXPECTED.items():
        path=ROOT/name
        if not path.is_file():raise ValueError('STOP: missing '+name)
        original=path.read_bytes()
        got=githash(original)
        if got not in hashes:raise ValueError('STOP: unexpected source SHA '+name+' '+got+' (game changed; do not force)')
        value=original.decode('utf-8')
        old,new=(BEFORE,AFTER) if name=='index.html' else (V277_OLD,V277_NEW)
        count=value.count(old)
        if count!=1:raise ValueError(f'STOP: {name} anchor count={count}, expected 1')
        patched=value.replace(old,new,1).encode('utf-8')
        patch[name]=(original,patched)
    bridge=ROOT/'v294_world_map_boss_bridge.js'
    if not bridge.is_file() or bridge.stat().st_size<1100:raise ValueError('STOP: missing V29.4 boss bridge')
    if b'window.chooseMob=function v294ServerBossTarget' not in bridge.read_bytes():raise ValueError('STOP: wrong bridge file')
    return patch

def check_syntax(files):
    node=shutil.which('node')
    if not node:
        print('NOTE: node unavailable, JavaScript checks skipped (install still checks anchors)')
        return
    for file in files:
        proc=subprocess.run([node,'--check',str(file)],capture_output=True,text=True)
        if proc.returncode:raise ValueError('STOP: JavaScript syntax failed: '+str(file)+'\n'+proc.stderr[:1000])

def main():
    ap=argparse.ArgumentParser()
    mode=ap.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check',action='store_true')
    mode.add_argument('--apply',action='store_true')
    arg=ap.parse_args()
    patch=make_patches()
    check_syntax([ROOT/'v277_authority_client.js',ROOT/'v294_world_map_boss_bridge.js'])
    for name,(old,new) in patch.items():
        print(f'PASS source {name} SHA={githash(old)} · anchors matched · output_bytes={len(new)}')
    if arg.check:
        print('PASS V29.4 PRECHECK. Files unchanged. Run --apply when ready.')
        return
    bk=ROOT/'.amber_backups'/('v294_'+datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S'))
    bk.mkdir(parents=True,exist_ok=False)
    try:
        for name,(old,_) in patch.items():
            (bk/name).write_bytes(old)
        # write in place only after BOTH files are verified, backup is complete
        for name,(_,out) in patch.items():
            (ROOT/name).write_bytes(out)
        check_syntax([ROOT/'v277_authority_client.js',ROOT/'v294_world_map_boss_bridge.js'])
        if AFTER not in (ROOT/'index.html').read_text('utf-8'):
            raise ValueError('STOP: target script was not injected')
    except BaseException:
        for name,(old,_) in patch.items():
            (ROOT/name).write_bytes(old)
        print('ROLLBACK: original files restored from backup')
        raise
    print('PASS V29.4 installed. Backups at '+str(bk))
    print('NEXT: python3 tools/check_static_site.py && git diff --check')

if __name__=='__main__':
    try:main()
    except Exception as exc:
        print(str(exc),file=sys.stderr)
        sys.exit(1)
