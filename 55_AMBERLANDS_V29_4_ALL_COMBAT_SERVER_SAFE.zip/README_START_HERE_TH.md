# 55 AMBERLANDS V29.4 — SERVER COMBAT UNIFIED

## แก้ไข
- สูตรศัตรูตีผู้เล่นร่วมกัน: มอนทุกแมป, บอสประจำแมป, บอสโลก, ดันเจียนมังกร/เหมันต์
- บอสดันเจียนอ่าน DEF จากอุปกรณ์และโบนัส Rebirth ผ่านฟังก์ชัน combat stats จริง
- มอนสเตอร์สวนกลับได้แม้ผู้เล่นตี MISS ถ้ามอนยังมีชีวิต
- บอสประจำแมป 8 ตัวใช้ V277 authenticated RPC สำหรับโจมตีและรางวัล แทนเรดจำลองเดิม
- บอสโลกและดันเจียนยังใช้ระบบเรด/dungeon เฉพาะที่ Supabase ตรวจสอบ
- ระบบโจมตีขาออกยังใช้ shared V287 roll ทั้งแมปปกติ/ดันเจียน/บอสโลก (ไม่เปลี่ยนค่าความแรงเดิม)
- ไม่แก้สูตร Rebirth 1,000 แต้ม, ไม่ย้าย Asset, ไม่ลบตัวละครหรือของ

## สถานะฐานข้อมูล
ติดตั้ง Migration `amber_v294_shared_incoming_combat_all_maps_dungeons_worldboss` ใน Supabase แล้ว
มีแบ็กอัปฟังก์ชันเดิม 3 รายการที่ private.amber_v294_combat_function_backups
**ไม่ต้องนำ SQL ไป Run ซ้ำ**

## ติดตั้ง GitHub
1. Upload ZIP นี้ที่ปุ่ม GitHub Add file > Upload files > Commit changes
2. เปิด GitHub Codespaces > Terminal และวาง:

```bash
git pull --ff-only origin main && \
unzip -o 55_AMBERLANDS_V29_4_ALL_COMBAT_SERVER_SAFE.zip -d . && \
python3 install_v294_safe.py --check && \
python3 install_v294_safe.py --apply && \
python3 tools/check_static_site.py && \
git diff --check && \
git add index.html v277_authority_client.js v294_world_map_boss_bridge.js && \
git commit -m "V29.4 unify incoming combat and map boss authority" && \
git push origin main
```

If STOP: stop, do not overwrite or force; send the exact Terminal error.

## สิ่งที่ยังไม่ใช่การทดสอบสด
- มอนปกติยังสวนกลับตอนผู้เล่นโจมตี ไม่ได้เดินไล่โจมตีคนที่ยืนเฉย ๆ โดยอิสระ
- ดาเมจ MISS 0 เป็นโอกาสพลาดตามสูตร (90–99% hit rate); ถือเป็นพฤติกรรมปกติ
- ห้องดันเจียนเก่าที่อันดับดาเมจ 0 ไม่ย้อนเพิ่มคะแนน เพราะไม่มีหลักฐานที่น่าเชื่อถือ
- ไม่ได้สร้างการโจมตีจริงในบัญชีผู้เล่น เพราะจะเปลี่ยน HP/รางวัลใน Production

## การทดสอบหลัง Deploy
- เลือกบอสบนแมป เริ่ม AUTO แล้วดู HP ลด/ดาเมจบันทึกผ่าน Supabase
- สลับ map ตรวจบอส 8 แมปตามเลเวลที่ปลดล็อก; worldboss/dungeon อยู่โหมดของตน
- ทดลองมอนปกติตีสวนแม้เราตี MISS และดู HP ของผู้เล่น
- ลงดันเจียนทั้ง 2 แบบ ตรวจ incoming damage และอันดับดาเมจ
