55 AMBERLANDS V28.3 — AUTO SYSTEM PATCH (2026-10-26)

Supabase migration already installed by ChatGPT:
 - public.amber_v283_auto_attack(text,text,boolean,integer,integer)
 - public.amber_v283_auto_skill_slots(jsonb)
No extra SQL needs to be run.

Upload this ZIP on GitHub to repository root, then use Codespaces Terminal:
  git pull --ff-only origin main
  unzip -o 55_AMBERLANDS_V28_3_AUTO_PATCH.zip index.html v277_authority_client.js v19_skills_market_realtime.js v15_potion_hit_fix.js
  node --check v277_authority_client.js
  node --check v19_skills_market_realtime.js
  node --check v15_potion_hit_fix.js
  git add index.html v277_authority_client.js v19_skills_market_realtime.js v15_potion_hit_fix.js
  git commit -m "V28.3 Supabase Auto Battle Skill Potion Fix"
  git push origin main

Details:
 - AUTO attack minimum 840ms; matches server cooldown 750ms.
 - Skill auto uses only player chosen slots, otherwise basic attack.
 - Auto Potion checked/consumed by Supabase atomically during auto attack.
 - 6 auto slots validated and saved with Supabase RPC.
 - Manual potion UI awaits server result.
 - Retry temporary network errors with exponential backoff; stop after 5 errors.
 - Dungeon and world boss already have separate authoritative RPCs; V28.3 does not change their balance or scheduling.
 - Manual map attack will not trigger automatic potion use by design.
 - No gold, xp, item, equipment or skill outcomes are accepted from browser.
 - Server max HP/MP for AUTO potion uses level/stats/rebirth and may not include all bonus equipment/set effects yet; inspect this when balancing.
 - Existing explicit dungeon auto-claim/auto-enter is not added in this patch.
