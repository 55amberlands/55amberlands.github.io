#!/usr/bin/env bash
set -euo pipefail
# Run from 55 AMBERLANDS GitHub repository root, after unzipping V300 archive.
python3 install_v300_safe.py --check
python3 install_v300_safe.py --apply
node --check v300_authoritative_vitals_ui.js
python3 tools/check_static_site.py
git diff --check
echo 'PASS V30.0 client. Review git diff; then commit & push using the provided commands.'
