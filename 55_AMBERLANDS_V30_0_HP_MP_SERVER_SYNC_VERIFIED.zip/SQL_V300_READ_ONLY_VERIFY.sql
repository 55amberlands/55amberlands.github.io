-- Read-only: no changes to Supabase data. V300 was installed from ChatGPT.
SELECT c.character_name,(c.save_data->>'lv')::int AS lv,
 (c.save_data->>'hp')::int AS current_hp,
 (c.save_data->>'mp')::int AS current_mp,
 (c.save_data->>'potHP')::int AS hp_bottles,
 (private.amber_v300_max_vitals(c.user_id,c.save_data)->>'max_hp')::int AS authoritative_max_hp,
 (private.amber_v300_max_vitals(c.user_id,c.save_data)->>'max_mp')::int AS authoritative_max_mp
FROM public.amber_characters c
WHERE lower(c.character_name) IN ('hareko','nahee');

SELECT n.nspname,p.proname,
 (pg_get_functiondef(p.oid) LIKE '%amber_v300_max_vitals%') AS uses_verified_vitals
FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
WHERE (n.nspname='public' AND p.proname IN ('amber_v277_recovery','amber_v283_auto_attack'))
   OR (n.nspname='private' AND p.proname='amber_dg_max_health');
