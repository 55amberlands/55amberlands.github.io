#!/usr/bin/env python3
"""V300: load server-authoritative vitals UI after V299, no DB writes.

Backs up original index.html and refuses missing/unrecognized V299 baseline.
"""
import argparse
import datetime
import pathlib
import shutil
import sys

ROOT = pathlib.Path.cwd()
BRIDGE = 'v300_authoritative_vitals_ui.js'
TAG = '<script src="./v300_authoritative_vitals_ui.js?v=300_server_vitals"></script>'
ANCHOR = '<script src="./v298_boss_respawn_ui.js?v=298_boss_cooldown"></script>'


def run(check):
    idx = ROOT/'index.html'
    bridge = ROOT/BRIDGE
    if not idx.is_file():
        raise ValueError('STOP: index.html not found. Run inside the 55 AMBERLANDS repository root.')
    if not bridge.is_file() or bridge.stat().st_size < 1500:
        raise ValueError('STOP: V300 bridge missing or incomplete. Unzip the complete archive first.')
    text = idx.read_text('utf-8')
    if TAG in text:
        if text.count(TAG) != 1:
            raise ValueError('STOP: duplicate V300 script references')
        print('PASS: V300 already installed in index.html; nothing to overwrite')
        return
    if ANCHOR not in text or text.count(ANCHOR) != 1:
        raise ValueError('STOP: V29.8/V29.9 baseline is missing or changed; no files modified')
    if ('299_vitals_starter' not in text
            or 'v296_exp_progress.js' not in text
            or 'v277_authority_client.js' not in text):
        raise ValueError('STOP: V29.9 is not installed completely; no files modified')
    if text.count('</body>') != 1:
        raise ValueError('STOP: HTML body marker changed')
    new = text.replace('</body>', TAG+'</body>', 1)
    if check:
        print('PASS: --check: latest combined baseline recognized; can install V300')
        return
    folder = ROOT/'.amber_v300_backups'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    folder.mkdir(parents=True,exist_ok=False)
    shutil.copy2(idx,folder/'index.html')
    tmp = idx.with_name('index.html.v300.tmp')
    try:
        tmp.write_text(new,'utf-8')
        tmp.replace(idx)
    finally:
        if tmp.exists(): tmp.unlink()
    print('PASS: installed V300 server-owned health UI and backed up index.html at',folder)


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    group=ap.add_mutually_exclusive_group(required=True)
    group.add_argument('--check',action='store_true')
    group.add_argument('--apply',action='store_true')
    args=ap.parse_args()
    try:
        run(args.check)
    except Exception as e:
        print(str(e),file=sys.stderr)
        sys.exit(2)
