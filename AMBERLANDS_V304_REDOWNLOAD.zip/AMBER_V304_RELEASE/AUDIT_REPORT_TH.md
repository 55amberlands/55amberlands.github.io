# 55 AMBERLANDS V30.4 — รายงานการตรวจและแก้ไข

## ยืนยันจาก Repo GitHub V30.3 และ Supabase จริง
- V30.3 มี `renderSkills()` ที่เขียน `#skills.innerHTML` ใหม่ตลอดแม้ค่าคงเดิม
- `renderScene()` เขียน `#sprites.innerHTML` และเปลี่ยน `#mobimg.src` กลับภาพเดิมทุก Render ก่อน V24 reskin → เกิด flash
- `renderMobs()`, `renderBag()` และ `renderTop()` เปลี่ยน DOM/รูปซ้ำ เพิ่มภาระ Render
- V25 เลือกฉายาใน `state.v25.titles.active`; `amber_v277_visual_save` ไม่อนุญาตให้บันทึกคีย์นี้ → ไม่มีการเลือกฉายาค้างอยู่ฝั่ง Supabase
- V25 `activeTitleId()` มี fallback กลับไปใช้ฉายาเซ็ต/ฉายาล่าสุด และ V25 decoration interval 500ms
- World Boss V27.3 มีทางเข้าในระบบกิจกรรม; V28 World Boss ใหม่มีแท็บบอสเดิม แต่ไม่ได้โชว์การ์ดบอสเดิมตั้งแต่หน้าแรก
- `amber_v291_verified_cards()` นับใบรับรางวัล `server_monster` ที่ผูก `auth.uid()` จริง; ผู้เล่นแก้ค่าในเครื่องไม่สามารถเพิ่มยอด verified นี้ใน DB ได้
- อย่างไรก็ตามโบนัสจากการ์ด V25 ยังเป็น UI calculation ไม่ใช่ `private.amber_v285_combat_stats` → ยังไม่ได้ย้ายโบนัสไปสูตรดาเมจฝั่งเซิร์ฟเวอร์

## แก้ V30.4
1. แก้ Render สกิล sprite มอนสเตอร์ กระเป๋า portrait และ logo ไม่ให้รีเซ็ต DOM/asset โดยไม่จำเป็น
2. แสดงห้องบอสเดิมชัดเจนบนหน้าแรกของ Hub บอสโลกใหม่; หน้ากิจกรรมเดิมชี้ไป Hub ใหม่นี้
3. ลดความสว่างแสงวูบและขนาด UI ในหน้าสู้บอส Realtime (ไม่ปรับสูตรดาเมจ)
4. ฉายาเลือกผ่าน `public.amber_v304_title('set',title)` บน Supabase และอ่านผ่าน `'get'`, ไม่ยอมรับสิทธิ์จาก client
5. สิทธิ์ฉายาที่ตรวจได้: ฆ่า 100/1000/10000, Rebirth ≥1, อาวุธ +10, การ์ดครบ 20 ชนิด, เช็กอิน 7 วัน, เคลียร์บอสที่มี claim จริง, สวม boss gear 3/5 ชิ้นในทะเบียนเซิร์ฟเวอร์
6. ฉายาธาตุ 3 แบบยังไม่เปิดให้เสกจนกว่า server จะมีเมทาดาทาธาตุที่เชื่อถือได้

## ผลยืนยันฐานข้อมูล
- migration `amber_v304_authoritative_title_selection`: สำเร็จ
- ตาราง `public.amber_v304_title_pref` มี RLS เปิด, anon/authenticated อ่านเขียนตรงไม่ได้
- RPC `amber_v304_title(text,text)` เรียกได้โดย authenticated เท่านั้น; anon ไม่มี EXECUTE
- RPC เมื่อไม่ login ตอบ `{ok:false,reason:'login_required'}`; ไม่มีการสร้าง preference หรือแก้เซฟเมื่อยังไม่ได้ login
- ยังไม่ได้ลองเลือกฉายาด้วย JWT ผู้เล่นจริง หรือทดสอบบน Chrome มือถือ หลังเว็บไซต์อัปเดต

## หมายเหตุความปลอดภัย
- server ownership checks ใช้ใบรับรางวัลมอนสเตอร์, claim บอส, เซฟรีเบิร์ธและทะเบียนอุปกรณ์ที่เซิร์ฟเวอร์ถือ
- หน้าเว็บอาจถูกดัดแปลงภาพได้ในเครื่องส่วนตัว แต่ RPC ไม่ให้บันทึกฉายาที่ไม่ได้ปลดล็อก
- โบนัสการ์ดยังไม่ได้ถูกตรวจใน private combat stats; การเปลี่ยนค่า client ไม่ได้บังคับให้ server เพิ่ม damage จากการ์ดใน V30.4
- ห้ามย้ายสูตรดาเมจไป client หรือปิด RLS เพื่อแก้ UI
