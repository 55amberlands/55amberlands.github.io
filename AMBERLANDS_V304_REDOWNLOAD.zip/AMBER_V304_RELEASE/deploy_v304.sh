#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
[[ "$(git branch --show-current)" == main ]] || { echo 'STOP: switch to main' >&2; exit 1; }
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || { echo 'STOP: uncommitted edits, refusing overwrite' >&2; exit 1; }
python3 .git/amber_v304/AMBER_V304_RELEASE/install_v304.py
python3 tools/check_static_site.py
for f in v25_systems.js v28_boss_book.js v304_stability_title.js; do node --check "$f"; done
git add index.html v25_systems.js v28_boss_book.js v304_stability_title.js
git diff --cached --check
if ! git diff --cached --quiet; then
  git commit -m 'V30.4 stable skill UI unified world boss and server-verified titles'
  git push origin main
fi
echo 'PASS: V30.4 deployed to main; confirm GitHub Pages Actions green.'
