55 AMBERLANDS — V30.4 TITLE & UI STABILITY

สถานะ Supabase: ติดตั้ง migration ฉายา amber_v304_authoritative_title_selection เรียบร้อยแล้วโดย ChatGPT และตรวจ RLS/EXECUTE ผ่าน
โปรเจกต์: 55-amberlands (rfijdwnzuhvlkfptyoiy)
ห้ามรัน SQL ซ้ำโดยไม่จำเป็น

ติดตั้ง GitHub (ไฟล์ ZIP เดียว ผ่าน Add file -> Upload files -> Commit changes):
1. อัปโหลด ZIP นี้ที่ Repository root ชื่อ 55_AMBERLANDS_V30_4_STABLE_UI_TITLES.zip
2. เปิด Codespaces terminal ใน repo นี้ แล้ววางคำสั่ง:
cd "$(git rev-parse --show-toplevel)" && git switch main && git pull --ff-only origin main && unzip -oq 55_AMBERLANDS_V30_4_STABLE_UI_TITLES.zip -d .git/amber_v304 && bash .git/amber_v304/AMBER_V304_RELEASE/deploy_v304.sh
3. ตรวจ GitHub Actions -> deploy success; รีเฟรชเว็บ

สิ่งที่แก้จริง:
- Render สกิลซ้ำ: หยุดลบและสร้างปุ่มเมื่อข้อมูลเหมือนเดิม
- Render sprite/monster/inventory ซ้ำ: รักษา DOM และ Pixel V24 เว้นแต่ข้อมูลเปลี่ยน
- Render รูป portrait/logo: ไม่รีเซ็ตเป็นรูปเกมเก่าทุกครั้ง
- บอสโลกเดิม V27.3: แสดงเป็นการ์ดบนหน้าแรกของ World Boss V28 และคงแท็บบอสเดิม
- กิจกรรม > บอสโลก: เปิดหน้า World Boss ใหม่
- ฉายา: อ่านสิทธิ์, ฉายาที่เลือก และบันทึกผ่าน RPC จาก Supabase เท่านั้นเมื่อออนไลน์
- แสดงฉายาที่ไม่ผ่านการตรวจเซิร์ฟเวอร์ไม่ได้
- Realtime: ลดแสงวูบ, ย่อภาพบอส และจัดพื้นที่บนมือถือ

ข้อจำกัด:
- โบนัสการ์ด V25 แสดงใน client จากยอดฆ่า verified; สูตรดาเมจ Supabase ยังไม่ได้เพิ่มโบนัสการ์ด (ไม่แก้ในรุ่นนี้)
- ฉายาธาตุ set_fire/set_ice/set_prism ยังไม่ปลดจากฐานข้อมูลจนกว่าจะมี metadata ธาตุที่เซิร์ฟเวอร์ตรวจได้
- บอสเดิมและใหม่ยังเป็นคนละเซิร์ฟเวอร์กิจกรรมและรางวัล แค่รวบทางเข้าไว้หน้าเดียวกัน
- ยังไม่ได้ทดสอบในมือถือจริงหลัง Deploy; การผ่าน syntax กับการใช้งานจริงเป็นคนละขั้น

SQL ที่แนบอยู่ในโฟลเดอร์ sql/ เป็นสำเนาสำหรับสำรอง/ตรวจทาน ไม่จำเป็นต้องรันซ้ำ
หากต้องย้อน V30.3 ดู .amber_v304_backups และ commit history ของ GitHub
