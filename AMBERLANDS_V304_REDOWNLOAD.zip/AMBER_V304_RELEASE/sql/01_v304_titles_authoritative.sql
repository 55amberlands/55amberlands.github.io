-- 55 AMBERLANDS V30.4: server-verified cosmetic title selection.
-- No changes to combat, wallet, inventory, character progress or reward rules.
BEGIN;
CREATE TABLE IF NOT EXISTS public.amber_v304_title_pref(
  user_id uuid PRIMARY KEY,
  active_title text NOT NULL DEFAULT 'auto',
  updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  CONSTRAINT amber_v304_title_pref_title_check CHECK (active_title IN
    ('auto','set_fire','set_ice','set_prism','set_boss','boss3','k100','k1000','k10000','plus10','reb1','cards20','ck7','wb1'))
);
ALTER TABLE public.amber_v304_title_pref ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.amber_v304_title_pref FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.amber_v304_title(p_action text DEFAULT 'get', p_title text DEFAULT NULL)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO '' AS $v304$
DECLARE
 u uuid := (SELECT auth.uid());
 s jsonb; owned text[] := ARRAY[]::text[];
 oldpref text; chosen text; active text; kills bigint:=0; card_types int:=0;
 bossgear int:=0; boss_claim boolean:=false; max_enh boolean:=false;
 equip jsonb; rb int:=0;
BEGIN
 IF u IS NULL THEN RETURN pg_catalog.jsonb_build_object('ok',false,'reason','login_required'); END IF;
 IF p_action NOT IN ('get','set') THEN RETURN pg_catalog.jsonb_build_object('ok',false,'reason','invalid_action'); END IF;
 IF p_action='set' AND (p_title IS NULL OR p_title NOT IN ('auto','set_fire','set_ice','set_prism','set_boss','boss3','k100','k1000','k10000','plus10','reb1','cards20','ck7','wb1'))
 THEN RETURN pg_catalog.jsonb_build_object('ok',false,'reason','invalid_title'); END IF;
 SELECT save_data INTO s FROM public.amber_characters WHERE user_id=u;
 IF s IS NULL THEN RETURN pg_catalog.jsonb_build_object('ok',false,'reason','character_required'); END IF;
 rb:=LEAST(10,GREATEST(0,COALESCE((s#>>'{v25,rebirth}')::int,0)));
 equip := CASE WHEN pg_catalog.jsonb_typeof(s->'eq')='object' THEN s->'eq' ELSE '{}'::jsonb END;
 -- All kill counts come from server-issued reward receipts, not localStorage or client V25.ck.
 SELECT count(*) INTO kills FROM private.amber_v276_reward_receipts r
  WHERE r.recipient=u AND r.source_kind='server_monster' AND r.xp_delta>0;
 SELECT count(*) INTO card_types FROM (
   SELECT r.server_proof->>'monster_id' mid
   FROM private.amber_v276_reward_receipts r
   WHERE r.recipient=u AND r.source_kind='server_monster' AND r.xp_delta>0
   GROUP BY r.server_proof->>'monster_id' HAVING count(*)>=25
 ) cc;
 -- Only server-recognized equipped gear can unlock boss-set and +10 titles.
 SELECT count(*) FILTER (WHERE COALESCE(r.gear_data->>'bossDrop','false')='true'),
        COALESCE(bool_or(CASE WHEN COALESCE(r.gear_data->>'enh','0') ~ '^[0-9]{1,2}$' THEN (r.gear_data->>'enh')::int >= 10 ELSE false END),false)
 INTO bossgear,max_enh
 FROM pg_catalog.jsonb_each_text(equip) e
 JOIN private.amber_v285_gear_registry r ON r.gear_id=e.value AND r.holder_user_id=u AND r.location='inventory'
 WHERE e.key IN ('W','S','G','B','R');
 SELECT EXISTS (
    SELECT 1 FROM public.amber_ac_claims a WHERE a.user_id=u AND a.kind='worldboss_v273'
    UNION ALL
    SELECT 1 FROM public.amber_v28_boss_player b WHERE b.user_id=u AND b.claimed=true
 ) INTO boss_claim;
 IF kills>=100 THEN owned:=pg_catalog.array_append(owned,'k100'); END IF;
 IF kills>=1000 THEN owned:=pg_catalog.array_append(owned,'k1000'); END IF;
 IF kills>=10000 THEN owned:=pg_catalog.array_append(owned,'k10000'); END IF;
 IF rb>=1 THEN owned:=pg_catalog.array_append(owned,'reb1'); END IF;
 IF max_enh THEN owned:=pg_catalog.array_append(owned,'plus10'); END IF;
 IF card_types>=20 THEN owned:=pg_catalog.array_append(owned,'cards20'); END IF;
 IF EXISTS(SELECT 1 FROM public.amber_ac_checkins a WHERE a.user_id=u AND a.day_no>=7)
 THEN owned:=pg_catalog.array_append(owned,'ck7'); END IF;
 IF boss_claim THEN owned:=pg_catalog.array_append(owned,'wb1'); END IF;
 IF bossgear BETWEEN 3 AND 4 THEN owned:=pg_catalog.array_append(owned,'boss3'); END IF;
 IF bossgear>=5 THEN owned:=pg_catalog.array_append(owned,'set_boss'); END IF;
 -- Element-specific set titles require a server-side element registry; currently unavailable.
 -- Do NOT guess element from weapon names or trust the client for set_fire/ice/prism.
 SELECT active_title INTO oldpref FROM public.amber_v304_title_pref WHERE user_id=u;
 chosen:=COALESCE(oldpref, NULLIF(s#>>'{v25,titles,active}',''), 'auto');
 IF p_action='set' THEN
    IF p_title<>'auto' AND NOT (p_title=ANY(owned))
    THEN RETURN pg_catalog.jsonb_build_object('ok',false,'reason','title_locked','owned',pg_catalog.to_jsonb(owned)); END IF;
    chosen:=p_title;
    INSERT INTO public.amber_v304_title_pref(user_id,active_title) VALUES (u,chosen)
    ON CONFLICT(user_id) DO UPDATE SET active_title=EXCLUDED.active_title,updated_at=clock_timestamp();
 END IF;
 IF chosen<>'auto' AND NOT(chosen=ANY(owned)) THEN chosen:='auto'; END IF;
 active:=chosen;
 IF active='auto' THEN
    active:=CASE
      WHEN 'set_boss'=ANY(owned) THEN 'set_boss'
      WHEN 'boss3'=ANY(owned) THEN 'boss3'
      WHEN 'plus10'=ANY(owned) THEN 'plus10'
      WHEN 'reb1'=ANY(owned) THEN 'reb1'
      WHEN 'wb1'=ANY(owned) THEN 'wb1'
      WHEN 'k10000'=ANY(owned) THEN 'k10000'
      WHEN 'k1000'=ANY(owned) THEN 'k1000'
      WHEN 'k100'=ANY(owned) THEN 'k100'
      WHEN 'cards20'=ANY(owned) THEN 'cards20'
      WHEN 'ck7'=ANY(owned) THEN 'ck7'
      ELSE '' END;
 END IF;
 RETURN pg_catalog.jsonb_build_object('ok',true,'requested',chosen,'active',active,
    'owned',pg_catalog.to_jsonb(owned),'server_verified',true,'kills',kills,'boss_gear',bossgear);
END;
$v304$;
REVOKE ALL ON FUNCTION public.amber_v304_title(text,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.amber_v304_title(text,text) TO authenticated;
COMMIT;
