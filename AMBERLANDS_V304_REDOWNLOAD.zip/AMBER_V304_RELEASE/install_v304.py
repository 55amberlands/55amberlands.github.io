#!/usr/bin/env python3
"""55 AMBERLANDS V30.4; requires deployed V30.3; no SQL run by this script."""
from pathlib import Path
import re,sys,shutil
root=Path.cwd(); src=Path(__file__).resolve().parent
names=['index.html','v25_systems.js','v28_boss_book.js']
if not all((root/n).is_file() for n in names) or not (root/'v303_unified_ui_cards.js').exists():
    sys.exit('STOP: Requires installed V30.3. No files changed.')
a={n:(root/n).read_text(encoding='utf-8') for n in names}
idx,v25,hub=(a[n] for n in names)
if 'v304_stability_title.js?v=304' in idx:
    print('V30.4 already installed');sys.exit(0)
if 'v303_unified_ui_cards.js?v=303_unified' not in idx:
    sys.exit('STOP: V30.3 base not recognized')
def repl(text,old,new,desc):
    times=text.count(old)
    if times!=1:sys.exit(f'STOP: {desc}: expected 1, found {times}. No files changed.')
    return text.replace(old,new,1)
# V25 legacy event/title logic: RPC owns persistence and title qualifications.
v25=repl(v25,"function refreshTitles() {\n  const v = V();", "function refreshTitles() {\n  if(window.AMBER_CLOUD?.getStatus?.()?.cloudReady)return;\n  const v = V();", 'disable client-side title minting')
v25=repl(v25,"function activeTitleId() {\n  const v = V(), si = setInfo();", "function activeTitleId() {\n  const verified=window.AMBER_V304_TITLES?.active?.();\n  if(verified!==null && verified!==undefined)return verified;\n  const v = V(), si = setInfo();",'verified title priority')
v25=repl(v25,"const v = V(), si = setInfo(), act = activeTitleId();\n  const rows = Object.entries(TITLES).map(([id, t]) => { const own = t.live ? si.id === id : v.titles.owned.includes(id);", "const v = V(), si = setInfo(), act = activeTitleId();\n  const rows = Object.entries(TITLES).map(([id, t]) => { const own = window.AMBER_CLOUD?.getStatus?.()?.cloudReady ? !!window.AMBER_V304_TITLES?.owns?.(id) : (t.live ? si.id === id : v.titles.owned.includes(id));",'verified title unlock list')
v25=repl(v25,"  if (curTab === 'cards') await window.AMBER_V303_CARDS?.refresh?.(true);", "  if (curTab === 'cards') await window.AMBER_V303_CARDS?.refresh?.(true);\n  if (curTab === 'titles') await window.AMBER_V304_TITLES?.refresh?.(true);",'refresh title tab')
v25=repl(v25,"async function openHub(tab) {\n  curTab = tab || curTab;", "async function openHub(tab) {\n  if(tab==='boss'&&window.AMBER_V28_HUB?.open)return window.AMBER_V28_HUB.open('select');\n  curTab = tab || curTab;",'route old boss menu to new hub')
old="else if (a === 'title') { V().titles.active = b.dataset.id; commit(); decorateScene(); openHub('titles'); } else if (a === 'titleauto') { V().titles.active = 'auto'; commit(); openHub('titles'); }"
new="else if (a === 'title') { if(window.AMBER_CLOUD?.getStatus?.()?.cloudReady){ void window.AMBER_V304_TITLES?.select?.(b.dataset.id); } else {V().titles.active=b.dataset.id;commit();decorateScene();openHub('titles');} } else if (a === 'titleauto') { if(window.AMBER_CLOUD?.getStatus?.()?.cloudReady){void window.AMBER_V304_TITLES?.select?.('auto');} else {V().titles.active='auto';commit();openHub('titles');} }"
v25=repl(v25,old,new,'server title selection')
# Current V28 hub: display old-world boss tile directly above ten new bosses;
# the existing legacy tab and fully authoritative old boss API are retained.
hub=repl(hub,'<div class="px28h-grid">${LIST.map', '${pageLegacy()}<div class="px28h-grid">${LIST.map', 'legacy boss first-page tile')
# Old HTML rendering destroys skill DOM on every combat tick, even if unchanged.
# Only replace the exact function body, leave skill rules and event handlers untouched.
start=idx.find('function renderSkills(){')
end=idx.find('function openJobs()',start)
if start<0 or end<start or end-start>950:
    sys.exit('STOP: original skill renderer changed; no files changed')
block=idx[start:end]
if block.count("$('skills').innerHTML=")!=1 or not block.rstrip().endswith('}'):
    sys.exit('STOP: skill renderer differs from expected; no files changed')
block2=block.replace("$('skills').innerHTML=",'const __v304HTML=',1)
endat=block2.rfind('}')
block2=block2[:endat] + ";const __v304Box=$('skills');if(__v304Box.dataset.v304html!==__v304HTML){__v304Box.dataset.v304html=__v304HTML;__v304Box.innerHTML=__v304HTML;}}" + block2[endat+1:]
idx=idx[:start]+block2+idx[end:]
# Prevent older V1 renderer from continually re-creating pixel-art character,
# monster, inventory and spell HTML on every auto-combat frame.
scene_start=idx.find('function renderScene(){')
scene_end=idx.find('function renderMobs()',scene_start)
if scene_start<0 or scene_end<0 or scene_end-scene_start>1800:
    sys.exit('STOP: unexpected renderScene version')
scene=idx[scene_start:scene_end]
scene=repl(scene,"$('sprites').innerHTML=names.slice", "const __v304SpritesHTML=names.slice",'static sprite markup')
scene=repl(scene,".join('');$('mobimg').src=image(mob().asset);", ".join('');const __v304Sprites=$('sprites');if(__v304Sprites.dataset.v304Markup!==__v304SpritesHTML){__v304Sprites.dataset.v304Markup=__v304SpritesHTML;__v304Sprites.innerHTML=__v304SpritesHTML;}const __v304Mob=$('mobimg');if(__v304Mob.dataset.v304Asset!==String(mob().asset)){__v304Mob.dataset.v304Asset=String(mob().asset);__v304Mob.src=image(mob().asset);}",'sprite and monster diff')
idx=idx[:scene_start]+scene+idx[scene_end:]
for name,nextname,marker,node in [('renderMobs','renderBag','__v304MobsHTML','monsters'),('renderBag','renderSkills','__v304BagHTML','bag')]:
    a=idx.find('function '+name+'(){');b=idx.find('function '+nextname+'()',a)
    if a<0 or b<0 or b-a>1150:sys.exit('STOP: unexpected '+name+' version')
    block=idx[a:b]
    old="$('"+node+"').innerHTML="
    block=repl(block,old,'const '+marker+'=',name+' DOM diff')
    if name=='renderBag':
        block=repl(block,"$('bagcount').textContent", "const __v304Node=$('bag');if(__v304Node.dataset.v304Html!=="+marker+"){__v304Node.dataset.v304Html="+marker+";__v304Node.innerHTML="+marker+";} $('bagcount').textContent",'bag count after diff')
    else:
        last=block.rfind('}')
        block=block[:last]+";const __v304Node=$('monsters');if(__v304Node.dataset.v304Html!=="+marker+"){__v304Node.dataset.v304Html="+marker+";__v304Node.innerHTML="+marker+";}"+block[last:]
    idx=idx[:a]+block+idx[b:]
# New art assets are never swapped back to the old portrait between refreshes.
for pic in ['logo','portrait']:
    old="$('"+pic+"').src=image('"+pic+"');"
    new="if(!$('"+pic+"').dataset.v304Init){$('"+pic+"').src=image('"+pic+"');$('"+pic+"').dataset.v304Init='1';}"
    idx=repl(idx,old,new,'no old '+pic+' reset')
idx=repl(idx,'<script src="./v303_unified_ui_cards.js?v=303_unified"></script>', '<script src="./v303_unified_ui_cards.js?v=303_unified"></script>\n<script src="./v304_stability_title.js?v=304_title_v1"></script>', 'V30.4 script load')
for n in ['v25_systems.js','v28_boss_book.js']:
    hits=list(re.finditer(r'\./'+re.escape(n)+r'\?v=[^"\s<>]+',idx))
    if len(hits)!=1:sys.exit(f'STOP: script tag for {n} changed')
    m=hits[0];idx=idx[:m.start()]+'./'+n+'?v=304_title_ui_stable'+idx[m.end():]
# Allow exact reapplication as stable git commit + deterministic asset files.
backup=root/'.amber_v304_backups';backup.mkdir(exist_ok=True)
for n,data in a.items():
    f=backup/n
    if not f.exists():f.write_text(data,encoding='utf-8')
(root/'index.html').write_text(idx,encoding='utf-8')
(root/'v25_systems.js').write_text(v25,encoding='utf-8')
(root/'v28_boss_book.js').write_text(hub,encoding='utf-8')
shutil.copy2(src/'payload/v304_stability_title.js',root/'v304_stability_title.js')
print('PASS V30.4 client: stable skill DOM, boss on hub first page, verified title selection, responsive Realtime')
