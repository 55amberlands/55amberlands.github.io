55 AMBERLANDS V28.1 — Auto Save Fix (Server-only)

อาการ: ตี/ขายของผ่าน RPC ได้ แต่ Auto Save เก่าส่ง state ทั้งก้อนขึ้น
Supabase ทำให้ขึ้น V277_SAVE_SERVER_ONLY หลังเข้าโหมดเซิร์ฟเวอร์

แก้ไฟล์เดียว online_bridge.js (อ้างอิงไฟล์ main ที่มี Git blob SHA
521ea1476145544be5f887281d42a96dfb56792e ก่อนแก้)
- Auto Save → public.amber_v277_visual_save (การตั้งค่าภาพ/ข้อความเท่านั้น)
- ไม่เรียก public.amber_save_guarded เพื่อส่ง Gold/EXP/Inventory จากมือถืออีก
- ไม่แตะระบบต่อสู้/การซื้อขาย/ดันเจียน/บอส/UI/แอสเซต
- การเลือก map/mob ใช้ RPC แยกที่มีอยู่แล้ว
- ผู้เล่นต้องได้รับรางวัลจากเซิร์ฟเวอร์ จึงจะคงอยู่เมื่อรีเฟรช

อัปโหลด ZIP นี้เข้า GitHub main แล้วเปิด Codespaces Terminal:
  git pull --ff-only origin main
  unzip -o 55_AMBERLANDS_V28_1_AUTOSAVE_FIX.zip online_bridge.js
  node --check online_bridge.js
  git add online_bridge.js
  git commit -m "V28.1 visual-only autosave fix"
  git push origin main

หรืออัปโหลดเฉพาะ online_bridge.js จาก ZIP ลง repo แล้ว Commit Changes
ก่อนแก้ ZIP นี้ไม่ได้ถูก Deploy ให้โดย ChatGPT

สำคัญ: การแก้ไขนี้หยุดอาการเตือน V277_SAVE_SERVER_ONLY ที่เกิดจาก Auto Save
แต่ไม่ได้แปลว่าระบบย่อยเก่าทุกระบบถูกย้ายไป Supabase จนครบแล้ว
