55 AMBERLANDS — V30.1.2 ภาพออร่าฉายา / Title Aura Stable Fix
==========================================================
ฐานที่รองรับ: เกม V30.1 ที่ติดตั้งแพตช์ V30.1.1 (Ghost Sprite Fix) สำเร็จแล้ว

สาเหตุที่ตรวจพบจากโค้ด:
(1) index.html มี CSS ทั่วไป .sprite img {aspect-ratio:1; object-fit:cover}
    แต่เฟรมออร่าฉายาจาก v25_px_ui.js จริง ๆ เป็น 72×110 พิกเซล
    v25_systems.js ไม่เคยยกเลิก aspect-ratio/object-fit ของภาพพื้นฐาน
    ทำให้ลำแสงถูกบีบ/ครอบอย่างผิดสัดส่วน
(2) v25_systems.js เติมฉายา/ออร่าทุก 500ms แต่หน้าฉากจริงถูก Render ใหม่บ่อย
    จึงมีเวลาที่ภาพฉายาหายหรือกะพริบระหว่างรอบ
(3) ระบบตัวละครกับฉากห้องซ้อมใช้การวางภาพคนละกล่องกัน
    เลยอาจมีเอฟเฟกต์ไม่ตรงกึ่งกลางร่างตัวละคร

ไฟล์ที่แก้ใน GitHub (2 ไฟล์เท่านั้น):
- v25_systems.js: คืน aspect-ratio:auto, object-fit:contain ให้ภาพออร่าต้นฉบับ,
  ขยายขนาดอย่างเหมาะสมตามความกว้างรูปตัวละคร, ยึดตำแหน่งแสงตามตัวละครจริง
  เพิ่ม MutationObserver เฉพาะการสร้างลูกของ #sprites ใหม่
  และแก้เงื่อนไขไม่ให้สร้างป้าย/ภาพออร่าใหม่ทุกครั้งถ้าไม่เปลี่ยนฉายา
- index.html: เปลี่ยน query version ของ v25_systems.js เพื่อเคลียร์แคช

สิ่งที่ไม่เปลี่ยน:
- ไม่มีไฟล์ SQL / Supabase; ไม่มีแก้ไอเทม ฉายาที่ปลดล็อก หรือสูตรเกม
- ไม่สร้างตัวละครหรือ Canvas แสงซ้อนอีกชุด
- ไม่แก้แอสเซต V25 10 เฟรมเดิม (ใช้ชุดเดียวกับห้องซ้อม)
- ฉายาไฟยังเป็นสีไฟ ไม่เปลี่ยนเป็นฉายารุ้ง และบอสโลก V28 ไม่ถูกเพิ่ม

วิธีติดตั้ง:
(ก) อัปโหลด ZIP นี้ผ่าน GitHub > Add file > Upload files > Commit changes
(ข) เข้า Codespaces Terminal แล้ววางคำสั่งเดียว:
cd "$(git rev-parse --show-toplevel)" && git switch main && git pull --ff-only origin main && unzip -oq 55_AMBERLANDS_V30_1_2_AURA_RATIO_TITLE_STABLE.zip -d .git/amber_v3012 && bash .git/amber_v3012/AMBER_V3012_AURA_RATIO_STABLE_RELEASE/deploy_v3012.sh
(ค) ตรวจ GitHub Actions สำเร็จ แล้วปิดเกมเปิดใหม่/รีเฟรชหน้าเกม

หมายเหตุ: ทดสอบกับโครงสร้าง V30.1.1, สคริปต์ Syntax และ DOM fixture ก่อนปล่อย
และผลภาพจริง Android ยังต้องตรวจสอบหลัง Deploy
