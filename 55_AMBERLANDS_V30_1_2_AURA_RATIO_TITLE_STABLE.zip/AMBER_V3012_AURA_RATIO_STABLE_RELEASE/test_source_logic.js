const fs=require('fs'),vm=require('vm'),assert=require('assert');
const path=process.argv[2];
const all=fs.readFileSync(path,'utf8');
const begin=all.indexOf('/* V30.1.2: source-level live title hydration');
const end=all.indexOf('safe(decorateScene);\n\n/*',begin);
assert(begin>=0&&end>begin,'cannot find patched source');
const src=all.slice(begin,end+'safe(decorateScene);'.length);
const events={};let observed=null,obsOpts=null,auras=0;
class Img {constructor(){this.className='';this.dataset={};this.style={_map:new Map(),getPropertyValue(k){return this._map.get(k)||''},setProperty(k,v){this._map.set(k,v)}};this.src='';}}
class Sprite{
 constructor(){this.dataset={};this.hero={className:'px24-hero amber20-characterBody',getBoundingClientRect(){return {left:126,width:72}}};this.small={tag:'small'};this.children=[this.hero,this.small]}
 getBoundingClientRect(){return{left:90,width:135}}
 querySelector(q){if(q.includes('.px24-hero.amber20-characterBody')||q.includes('img.amber20-characterBody'))return this.hero;
  if(q.includes('.px25-plate'))return this.children.find(x=>x.className==='px25-plate')||null;
  if(q.includes('img.px25-aura'))return this.children.find(x=>x.className==='px25-aura')||null;
  if(q.includes('small'))return this.small;
  return null;}
 insertBefore(x,ref){x.parentElement=this;x.remove=()=>{const i=this.children.indexOf(x);if(i>=0)this.children.splice(i,1)};
 const idx=ref?this.children.indexOf(ref):-1;this.children.splice(idx<0?this.children.length:idx,0,x)}
}
let sprite=new Sprite();let top={dataset:{},insertAdjacentElement(_,x){return x}};
const context={
 window:{AMBER_SCENE_PLAYERS:[],addEventListener:(name,f)=>{events[name]=f}},
 document:{querySelectorAll:(q)=>q==='#sprites .sprite'?[sprite]:[],addEventListener:(name,f)=>{events[name]=f}},
 S:()=>({}),activeTitleId:()=> 'set_fire',TITLES:{set_fire:{name:'title'}},auraKind:()=> 'fire',titleHTML:()=> '<b>Test</b>',
 el:(tag,cl,h)=>{const e={className:cl,innerHTML:h,dataset:{},remove(){if(this.parentElement){const i=this.parentElement.children.indexOf(this);if(i>=0)this.parentElement.children.splice(i,1)}}};return e},
 $:(id)=>id==='sprites'?{test:'host'}:id==='pname'?top:null,
 PX:{ui:{auraURL:()=>'test://aura'}} ,Image:class extends Img{constructor(){super();auras++}},
 MutationObserver:class{constructor(fn){observed=fn}observe(_,opts){obsOpts=opts}},
 setInterval:(_,ms)=>{assert.equal(ms,500)},
 safe:fn=>fn(),console
};
vm.runInNewContext(src,context);
assert.equal(obsOpts.childList,true);assert.equal(obsOpts.subtree,undefined);
assert.equal(sprite.children.filter(x=>x.className==='px25-aura').length,1);
const aura=sprite.querySelector('img.px25-aura');
assert.equal(aura.style.getPropertyValue('--amber3012-aura-left'),'72px');
assert.equal(aura.style.getPropertyValue('--amber3012-aura-width'),'133px');
assert.equal(auras,1);
context.decorateScene();
assert.equal(auras,1,'should not recreate title aura every 500ms');
assert.strictEqual(sprite.querySelector('img.px25-aura'),aura);
sprite=new Sprite(); observed();
assert.equal(sprite.children.filter(x=>x.className==='px25-aura').length,1);
assert.equal(auras,2,'new scene should hydrate aura instantly');
console.log('PASS: preserved aura node on polling, immediately restored after scene redraw, centered on body');
