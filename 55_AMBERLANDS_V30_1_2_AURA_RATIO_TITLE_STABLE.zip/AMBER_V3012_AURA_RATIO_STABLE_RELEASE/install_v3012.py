#!/usr/bin/env python3
"""V30.1.2 live title aura: source-level CSS ratio/anchor and re-render stability.

Requires restored V30.1 + V30.1.1 ghost hero fix. Visual-only.
No player data, Supabase, combat or game balancing changes.
"""
from __future__ import annotations
from pathlib import Path
import re
import shutil
import sys

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd()
idx = root / 'index.html'
ui = root / 'v25_systems.js'
integration = root / 'v24_px_integration.js'

if not all(p.is_file() for p in (idx, ui, integration)):
    raise SystemExit('STOP: missing index.html / v25_systems.js / v24_px_integration.js')
html = idx.read_text(encoding='utf8')
js = ui.read_text(encoding='utf8')
integ = integration.read_text(encoding='utf8')
if 'V30.1.1 SOURCE FIX' not in integ:
    raise SystemExit('STOP: install V30.1.1 ghost sprite source fix before this aura fix')
if any(t in html for t in ('v28_boss_book.js', 'v308_live_fix.js', 'v28_ult_weapons.js')):
    raise SystemExit('STOP: this patch is only for V30.1.1, not the V30.2+ merge')
marker = 'AMBER_V3012_SOURCE_FIXED_AURA'
if marker in js:
    if 'v25_systems.js?v=3012_ratio_stable' not in html:
        raise SystemExit('STOP: partial V30.1.2 installation; inspect index.html and v25_systems.js')
    print('PASS: V30.1.2 already installed; no changes')
    sys.exit(0)
if 'AMBER_V3012_TITLE_AURA_FIDELITY' in js:
    raise SystemExit('STOP: old V30.1.2 CSS-only patch found. This package expects V30.1.1; avoid mixing two aura fixes.')

# Exact source rule: old version lacks aspect-ratio / object-fit overrides,
# so the base .sprite img { aspect-ratio: 1; object-fit: cover } crops 72x110 FX.
old_css = '.px25-aura{position:absolute!important;left:50%;bottom:-6px;width:150%!important;max-width:none!important;height:auto!important;border:0!important;border-radius:0!important;transform:translateX(-50%);z-index:0!important;pointer-events:none;image-rendering:pixelated;mix-blend-mode:screen;opacity:.95}'
new_css = '''/* AMBER_V3012_SOURCE_FIXED_AURA: do not crop 72x110 aura to 1:1 via legacy .sprite img selector.
   Reuse SAME V25 ten-frame sprites as boss-practice scene. Respect live character anchor.
   Never create duplicate hero layers or mask older sprites. */
#sprites .sprite{isolation:isolate}
#sprites .sprite>img.px25-aura{
  position:absolute!important;
  left:var(--amber3012-aura-left,50%)!important;
  bottom:-6px!important;
  width:var(--amber3012-aura-width,170%)!important;
  height:auto!important;
  max-width:none!important;
  aspect-ratio:auto!important;
  object-fit:contain!important;
  border:0!important;border-radius:0!important;
  background:transparent!important;box-shadow:none!important;
  transform:translateX(-50%)!important;
  z-index:2!important;
  pointer-events:none!important;
  image-rendering:pixelated!important;
  opacity:1!important;
  mix-blend-mode:screen!important;
  filter:brightness(1.21) saturate(1.22) drop-shadow(0 0 5px #ffd39180)!important;
}
#sprites .sprite>img.amber20-characterWing{z-index:1!important}
#sprites .sprite>img.px24-hero.amber20-characterBody{z-index:3!important}
#sprites .sprite>.px24-equipfx{z-index:4!important}
#sprites .sprite>.px25-plate{z-index:6!important}
#sprites .sprite>small{z-index:7!important}'''
if js.count(old_css) != 1:
    raise SystemExit('STOP: V25 aura CSS differs from expected V30.1.1; no files changed')

# Live scene can replace #sprites children on render. 500ms polling alone lets
# title and aura disappear until next interval, causing a visible blink.
old_block = re.compile(
    r'function decorateScene\(\) \{\n.*?\n\}\nsetInterval\(\(\) => safe\(decorateScene\), 500\);',
    flags=re.DOTALL,
)
new_block = r'''/* V30.1.2: source-level live title hydration; no duplicate player IMG. */
function alignTitleAura(sprite, aura) {
  // Anchor the V25 aura to the actual V24 hero body instead of the legacy flex cell.
  const body = sprite.querySelector(':scope > img.px24-hero.amber20-characterBody')
    || sprite.querySelector(':scope > img.amber20-characterBody');
  if (!body) return;
  const box = sprite.getBoundingClientRect();
  const hero = body.getBoundingClientRect();
  if (!(box.width > 0 && hero.width > 0)) return;
  const center = Math.round((hero.left + hero.width / 2 - box.left) * 10) / 10;
  // The original frame is 72x110: keep it proportional but bright enough at mobile size.
  const width = Math.max(126, Math.min(212, Math.round(hero.width * 1.85)));
  const leftValue = center + 'px', widthValue = width + 'px';
  if (aura.style.getPropertyValue('--amber3012-aura-left') !== leftValue)
    aura.style.setProperty('--amber3012-aura-left', leftValue);
  if (aura.style.getPropertyValue('--amber3012-aura-width') !== widthValue)
    aura.style.setProperty('--amber3012-aura-width', widthValue);
}
function decorateScene() {
  const st = S(); if (!st) return;
  const people = window.AMBER_SCENE_PLAYERS || [];
  document.querySelectorAll('#sprites .sprite').forEach((spr, i) => {
    const tid = i === 0 ? activeTitleId() : (people[i - 1] || {}).ttl || '';
    const key = tid || '-';
    const valid = !!(tid && TITLES[tid]);
    const auraKindNeeded = valid ? auraKind(tid) : '';
    let plate = spr.querySelector(':scope > .px25-plate');
    let aura = spr.querySelector(':scope > img.px25-aura');

    // React to real title change, not every animation tick. Keep unchanged IMG node
    // so the PX animation player does not restart its 10-frame sequence.
    if (spr.dataset.px25 !== key) {
      plate?.remove(); aura?.remove(); plate = null; aura = null;
      spr.dataset.px25 = key;
    }
    if (!valid) { plate?.remove(); aura?.remove(); return; }

    if (!plate) {
      plate = el('div', 'px25-plate', titleHTML(tid, true));
      spr.insertBefore(plate, spr.querySelector(':scope > small') || null);
    }
    if (!auraKindNeeded) { aura?.remove(); return; }
    if (!aura) {
      aura = new Image(); aura.className = 'px25-aura';
      aura.dataset.auraKind = auraKindNeeded;
      aura.src = PX.ui.auraURL(auraKindNeeded);
      spr.insertBefore(aura, spr.firstChild);
    } else if (aura.dataset.auraKind !== auraKindNeeded) {
      aura.dataset.auraKind = auraKindNeeded;
      aura.src = PX.ui.auraURL(auraKindNeeded);
    }
    alignTitleAura(spr, aura);
  });
  const top = $('pname');
  if (top) {
    let t = $('px25TopTitle'); const tid = activeTitleId();
    if (!t) { t = el('div', '', ''); t.id = 'px25TopTitle'; top.insertAdjacentElement('afterend', t); }
    const h = tid ? titleHTML(tid, true) : '';
    if (t.dataset.h !== h) { t.dataset.h = h; t.innerHTML = h; }
  }
}
setInterval(() => safe(decorateScene), 500);
// The game rewrites #sprites during combat and realtime synchronization.
// Restore the exact title/aura in the same microtask, before next browser paint,
// instead of leaving it missing for up to 500ms. Observe children of host only:
// adding aura/plate INSIDE sprite will not retrigger this observer.
const amber3012SpritesHost = $('sprites');
if (amber3012SpritesHost) {
  new MutationObserver(() => safe(decorateScene)).observe(amber3012SpritesHost, { childList: true });
}
window.addEventListener('resize', () => safe(decorateScene), { passive: true });
document.addEventListener('visibilitychange', () => { if (!document.hidden) safe(decorateScene); });
safe(decorateScene);'''

matches = list(old_block.finditer(js))
if len(matches) != 1:
    raise SystemExit(f'STOP: expected exactly 1 live title decorator, got {len(matches)}; nothing changed')
# Distinguish original version from unexpected modified structure before changing it.
old_func = matches[0].group(0)
checks = [
    "spr.dataset.px25 === key",
    "const a = new Image(); a.className = 'px25-aura'",
    "setInterval(() => safe(decorateScene), 500);",
]
if not all(x in old_func for x in checks):
    raise SystemExit('STOP: V25 render logic differs from expected V30.1.1; no files changed')

old_tag = '<script src="./v25_systems.js?v=297_crit_daily"></script>'
new_tag = '<script src="./v25_systems.js?v=3012_ratio_stable_20261026"></script>'
if html.count(old_tag) != 1:
    raise SystemExit('STOP: V25 index script tag differs from V30.1.1; no files changed')
new_js = old_block.sub(lambda _: new_block, js, count=1).replace(old_css, new_css, 1)
new_html = html.replace(old_tag, new_tag, 1)
assert new_js.count(marker) == 1
assert new_html.count('v25_systems.js') == html.count('v25_systems.js')
assert 'V30.1.1 SOURCE FIX' in integ

backup = root / '.git' / 'amber_v3012_source_backup'
backup.mkdir(exist_ok=True, parents=True)
for f in [ui, idx]:
    shutil.copy2(f, backup / f.name)
ui.write_text(new_js, encoding='utf8')
idx.write_text(new_html, encoding='utf8')
print('PASS: V30.1.2 live aura source fix installed: 72x110 uncropped, anchored to hero, title hydrated on redraw')
print('BACKUP: .git/amber_v3012_source_backup/ (not published)')
