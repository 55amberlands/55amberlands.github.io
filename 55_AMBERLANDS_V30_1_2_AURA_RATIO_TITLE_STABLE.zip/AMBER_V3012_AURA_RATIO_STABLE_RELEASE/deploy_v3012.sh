#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
[ "$(git branch --show-current)" = "main" ] || { echo 'STOP: switch to main first'; exit 1; }
# Never stomp other pending work. Uploaded ZIPs can remain untracked or committed.
git diff --quiet -- index.html v25_systems.js || { echo 'STOP: existing uncommitted edits to index.html/v25_systems.js'; exit 1; }
git diff --cached --quiet || { echo 'STOP: staged changes exist. Commit them first'; exit 1; }
python3 .git/amber_v3012/AMBER_V3012_AURA_RATIO_STABLE_RELEASE/install_v3012.py
node --check v25_systems.js
node .git/amber_v3012/AMBER_V3012_AURA_RATIO_STABLE_RELEASE/test_source_logic.js v25_systems.js
git diff --check -- index.html v25_systems.js
if git diff --quiet -- index.html v25_systems.js; then
  echo 'PASS: V30.1.2 already committed'
  exit 0
fi
git add -- index.html v25_systems.js
git commit -m 'V30.1.2 correct aura aspect ratio and anchor; prevent title flicker'
git push origin main
echo 'PASS: V30.1.2 pushed. Check GitHub Actions then reload game.'
