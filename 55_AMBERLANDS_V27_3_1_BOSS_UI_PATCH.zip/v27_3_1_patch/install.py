#!/usr/bin/env python3
"""Install V27.3.1 UX-only patch, guarded by V27.3 SHA256."""
from pathlib import Path
import json,hashlib,shutil,tempfile,subprocess,os
here=Path(__file__).resolve().parent
project=here.parent
meta=json.loads((here/'manifest.json').read_text())
name=meta['file'];src=here/'files'/name;dst=project/name
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
if not (project/'index.html').is_file():
 raise SystemExit('ERROR: แตก ZIP ที่โฟลเดอร์เดียวกับ index.html ก่อน')
if sha(src)!=meta['after_sha256']:
 raise SystemExit('ERROR: เนื้อหา PATCH ไม่ตรงกับ manifest')
cur=sha(dst)
if cur==meta['after_sha256']:
 print('OK: V27.3.1 already installed. No changes.');raise SystemExit(0)
if cur!=meta['before_sha256']:
 raise SystemExit('STOP: v26_realtime.js ไม่ตรงกับ V27.3 ที่ตรวจแล้ว จึงไม่เขียนทับ กรุณาส่งภาพสถานะ')
subprocess.run(['node','--check',str(src)],check=True)
backup=Path(tempfile.mkdtemp(prefix='amber_pre_v2731_',dir=str(project.parent)))
shutil.copy2(dst,backup/name)
tmp=dst.with_suffix('.v2731_temp')
try:
 shutil.copy2(src,tmp)
 os.replace(tmp,dst)
 if sha(dst)!=meta['after_sha256']: raise RuntimeError('hash mismatch after installation')
except Exception as e:
 if tmp.exists():tmp.unlink()
 shutil.copy2(backup/name,dst)
 raise SystemExit('ERROR: Reverted to V27.3: '+str(e))
print('SUCCESS: V27.3.1 World Boss UI Patch installed (v26_realtime.js only).')
print('Backup:',backup)
print('NO Supabase SQL changes. Test Codespaces Port 8000 before pushing.')
