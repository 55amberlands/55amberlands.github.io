# 55 AMBERLANDS V27.3.1 — ปุ่มพับ/กาง World Boss HUD

ต่อจาก **V27.3** ที่กำลังเปิด Public Beta ได้โดยตรง ไม่ต้องถอนแพตช์เก่า

## การเปลี่ยนแปลง

- แถบ Auto อยู่ใต้ HP/MP เหนือตัวละครปาร์ตี้เหมือนเดิม แต่ลดขนาดปุ่มเหลือหนึ่งแถวบาง ๆ
- **ปุ่มพับ ▲ และกาง ▼ AUTO อยู่ด้านขวาของแถบ** กดได้ตลอด
- เริ่มต้นพับไว้เพื่อให้เห็นตัวละครและปาร์ตี้ชัดขึ้น
- พับแถบแล้วระบบ Auto Bot / Auto Skill / Auto ยา **ยังทำงานตามสถานะเดิม**
- ไม่แก้ HP, ระบบโจมตี, ระบบจ่ายรางวัล, สูตรเกม หรือ SQL Supabase
- เปลี่ยนไฟล์ `v26_realtime.js` เพียงไฟล์เดียว

## วิธีติดตั้งด้วย GitHub Codespaces

1. อัปโหลด `55_AMBERLANDS_V27_3_1_BOSS_UI_PATCH.zip` ที่หน้า GitHub > Code > Add file > Upload files > Commit changes
2. ใน Codespaces เดิม รันคำสั่งต่อไปนี้ โดย **ไม่ต้อง git pull**

```bash
git fetch origin
git show origin/main:55_AMBERLANDS_V27_3_1_BOSS_UI_PATCH.zip > 55_AMBERLANDS_V27_3_1_BOSS_UI_PATCH.zip
unzip -o 55_AMBERLANDS_V27_3_1_BOSS_UI_PATCH.zip
python3 v27_3_1_patch/install.py
node --check v26_realtime.js
```

> ถ้าขึ้น STOP แปลว่าไฟล์ V27.3 เดิมไม่ตรงกับที่ตรวจแล้ว ให้หยุด ห้ามฝืนเขียนทับ

## ทดสอบก่อนขึ้นเว็บจริง

เข้า Codespaces Port 8000 และเปิดห้องบอส (ซ้อม) จะเห็น `▼ AUTO` ที่ด้านขวา กดเพื่อกางปุ่ม 4 ปุ่มในแถวบาง กด `▲` เพื่อพับซ่อน ยืนยันว่าผู้เล่น/ปาร์ตี้ไม่ถูกแถบบัง และปุ่ม Auto สลับเปิด/ปิดได้เหมือนเดิม

หลังทดสอบผ่าน ค่อย commit **เฉพาะ** `v26_realtime.js` จากนั้น `git fetch origin; git merge --no-edit origin/main; git push origin main` หากมี Conflict ให้หยุด ห้าม force push
