55 AMBERLANDS — V28.2 REBIRTH + AUTOSAVE CACHE FIX

Server side: public.amber_v282_rebirth() installed; server attack XP/ATK rebirth bonuses installed. No SQL rerun needed.
Web side: Replace root index.html and v25_systems.js with files from this ZIP. Do not upload this ZIP itself as the game.

Problem corrected:
- Old V25 reset level and stats only in JS; backend kept Lv100 and overwritten them after attack.
- New button waits for Supabase RPC; transaction preserves gold/gems, bags, gear/equipment, learned skills, shops/pets and character history. Max 10 rebirths, Lv100 required. Stats and level reset on server.
- index.html changes script cache query so Chrome loads the already-updated online_bridge.js V28.1 (without stale legacy save).

Codespaces terminal after uploading ZIP to GitHub root with Add file > Upload files > Commit changes:
  git pull --ff-only origin main
  unzip -o 55_AMBERLANDS_V28_2_REBIRTH_AUTOSAVE_PATCH.zip index.html v25_systems.js
  node --check v25_systems.js
  git add index.html v25_systems.js
  git commit -m "V28.2 server-authoritative rebirth and autosave cache fix"
  git push origin main

DO NOT git add . (untracked older patch folders exist). If a step errors, stop before git push.
Hard reload Chrome after GitHub Pages deploy. DO NOT clear site storage or delete saves.

Note: Older legacy client-side save data is not proof of server-reward ownership. Server mode remains mandatory for protected writes.
