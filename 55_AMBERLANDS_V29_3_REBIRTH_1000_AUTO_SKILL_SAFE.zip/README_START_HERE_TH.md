# 55 AMBERLANDS V29.3 — รีเบิร์น +1,000 แต้ม / ซ่อม AUTO Skill

ติดตั้ง SQL ใหม่บน Supabase แล้ว (2026-10-26) — ห้ามรันซ้ำใน Codespaces

## หลังติดตั้ง SQL
- ตัวละครที่รีเบิร์นแล้ว 2 ตัวได้รับแต้มสเตตัส **เพิ่มอีก 1,000 แต้มต่อ 1 ครั้ง** โดยไม่ลบ STR/DEX/INT/VIT/AGI/LUK, แต้มเดิม, Lv, ของ, เงิน, สกิล หรือประวัติรีเบิร์น
- Rebirth ใหม่ในอนาคตจะได้แต้มสเตตัสที่ยังไม่ได้ใช้เพิ่ม 1,000 แต้มต่อครั้ง (แทนสูตรแต้ม 20+50×ครั้งก่อนหน้า) แต่โบนัส ATK/DEF/HP/MP/EXP ที่มีอยู่ยังคงเดิม
- Supabase อนุญาตสกิลที่ **เรียนแล้วจริง** ของผู้เล่นรีเบิร์นแม้เลเวลกลับเป็น 1 โดยตรวจอาชีพ ผู้เป็นเจ้าของสกิล บัฟ และ MP ตามกติกา
- ข้อมูลก่อนชดเชยเก็บใน `private.amber_v293_rebirth_1000_receipts` เพื่อป้องกันแจกซ้ำและใช้ตรวจสอบย้อนหลัง

## ติดตั้งผ่าน GitHub Codespaces
1. อัปโหลด ZIP นี้ด้วย GitHub **Add file → Upload files → Commit changes**
2. เปิด Codespaces → Terminal → New Terminal แล้วคัดลอกบล็อกนี้ทั้งหมด:

```bash
git pull --ff-only origin main && \
unzip -o 55_AMBERLANDS_V29_3_REBIRTH_1000_AUTO_SKILL_SAFE.zip -d . && \
python3 install_v293_safe.py --check && \
python3 install_v293_safe.py --apply && \
python3 tools/check_static_site.py && \
git diff --check && \
git add index.html v25_systems.js v277_authority_client.js v19_skills_market_realtime.js && \
git commit -m "V29.3 rebirth 1000 points and auto skills" && \
git push origin main
```

หากเจอ `STOP:` **อย่าบังคับทับ** เพราะฐานไฟล์บน GitHub เปลี่ยนจากเวอร์ชันที่ตรวจแล้ว

## ขอบเขต
- ไม่แก้ Asset, Map, Sprite, รายการไอเทม หรือเงินผู้เล่น
- ข้ามสกิลบัฟในระบบโจมตี AUTO เนื่องจากยังไม่มี RPC ร่ายบัฟที่ตรวจสอบโดย Supabase; จะไม่เอาบัฟไปส่งเป็นสกิลโจมตี
- AUTO จะพยายามใช้สกิลโจมตีที่เลือกในช่องเมื่อ MP เพียงพอ และกลับไปโจมตีปกติเมื่อไม่มีสกิลใช้ได้
- ยังไม่ได้ทดสอบเล่นจริงผ่านบัญชีสองเครื่อง: ควรทดสอบในเกมหลัง Deploy
