#!/usr/bin/env python3
# 55 AMBERLANDS V29.3 — install strictly anchored, atomic client-only updates.
# SQL must be installed separately through the connected Supabase project. This installer NEVER runs SQL.
from pathlib import Path
import argparse
import datetime
import hashlib
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
FILES = ('index.html', 'v25_systems.js', 'v277_authority_client.js', 'v19_skills_market_realtime.js')
EXPECTED = {
    'index.html': '89151ec850ad4436268e18d2f2a4a1467e9c06e5',
    'v25_systems.js': 'b0f54557cc654b3d5916b907e7aec4d7aefd3ba0',
    'v277_authority_client.js': '7020aa56e49634aa080e09451d28e229b486670c',
    'v19_skills_market_realtime.js': 'e2ee8d5c0dc2fe76349ca0f6de916bb901e5b39d',
}

def blob_sha(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def once(text, old, new, name):
    if text.count(old) != 1:
        raise RuntimeError(f'STOP: {name} expected exactly one anchor; found {text.count(old)}. No changes made.')
    return text.replace(old, new, 1)

def alter(files):
    out = files.copy()
    n = 'v25_systems.js'
    s = out[n]
    s = once(s,
        'ค่าสเตตัส STR/DEX/INT/VIT/AGI/LUK และแต้มที่ยังไม่ใช้คงเดิม เพิ่มแต้มรีเบิร์นใหม่',
        'STR/DEX/INT/VIT/AGI/LUK เดิมและแต้มที่ยังไม่ใช้คงอยู่ เพิ่มแต้มสเตตัสที่ยังไม่ได้ใช้ +1,000 แต้มทันทีต่อการรีเบิร์น 1 ครั้ง', n)
    s = once(s,
        'ได้แต้มเพิ่มอีก (20 + 50 × จำนวนรีเบิร์น)',
        'ได้แต้มสเตตัสเพิ่มทันที +1,000 แต้มต่อการรีเบิร์นหนึ่งครั้ง', n)
    s = once(s,
        'โบนัสตอนนี้: ATK +${v.rebirth * 500}',
        'โบนัสรีเบิร์นที่ได้รับแล้ว: แต้มสเตตัส +${v.rebirth * 1000} · ATK +${v.rebirth * 500}', n)
    s = once(s,
        "'🔥 Supabase ยืนยันการเกิดใหม่ครั้งที่ ' + data.rebirth + '!'",
        "'🔥 รีเบิร์นครั้งที่ ' + data.rebirth + ' สำเร็จ · รับแต้มสเตตัส +1,000 ทันที และคงค่าเดิมทั้งหมด'", n)
    out[n] = s

    n = 'v277_authority_client.js'
    s = out[n]
    s = once(s,
        'let autoRetryAfter=0,autoErrorCount=0;',
        'let autoRetryAfter=0,autoErrorCount=0;\nconst blockedAutoSkillIds=new Set(); // V29.3: ignore only server-rejected skills for this session', n)
    s = once(s,
        'const usable=SKILLS.filter(x=>learned.includes(x.id)&&!x.buff&&Number(state.mp)>=Number(x.mp));',
        "const usable=SKILLS.filter(x=>learned.includes(x.id)&&x.job===state.job&&!x.buff&&Number(state.mp)>=Number(x.mp)\n    &&(Number(state.v25?.rebirth||0)>0||Number(state.lv)>=Number(x.level||1))\n    &&!blockedAutoSkillIds.has(x.id));", n)
    s = once(s,
        'const picked=manual||(lastAuto && state.autoSkill && Math.random()<0.35\n   ? (window.AMBER_V19?.pickSkill?.(usable)||null):null);',
        'const picked=manual||(lastAuto && state.autoSkill\n   ? (window.AMBER_V19?.pickSkill?.(usable)||null):null);', n)
    s = once(s,
        "if(/COOLDOWN|ระบบกำลังทำรายการ/.test(message))return;",
        "if(/COOLDOWN|ระบบกำลังทำรายการ/.test(message))return;\n   if(lastAuto && picked && /SKILL_INVALID|V277_MP_LOW/.test(message)){\n     blockedAutoSkillIds.add(picked.id);\n     tell('⚠️ AUTO ข้ามสกิลที่เซิร์ฟเวอร์ปฏิเสธ: '+String(picked.name||picked.id).slice(0,40)+' · เปลี่ยนเป็นโจมตีปกติต่อ');\n     return;\n   }", n)
    out[n] = s

    n = 'v19_skills_market_realtime.js'
    s = out[n]
    if s.count("sk.buff?'บัฟ':'โจมตี'") != 2:
        raise RuntimeError('STOP: V19 buff text signature changed. No files modified.')
    s = s.replace("sk.buff?'บัฟ':'โจมตี'", "sk.buff?'บัฟ (AUTO โจมตีจะข้าม)':'โจมตี'")
    s = once(s,
        'เลือกเฉพาะสกิลที่ต้องการให้ AUTO ใช้ · ช่องที่ว่างจะไม่สุ่มสกิลอื่น · สกิลที่เรียนแล้วเท่านั้น',
        'เลือกสกิลโจมตีที่เรียนแล้วให้ AUTO ใช้ (รีเบิร์นยังใช้สกิลเดิมได้) · สกิลบัฟจะไม่ถูกนำไปยิงมอน · ช่องว่างไม่สุ่มสกิลอื่น', n)
    out[n] = s

    n = 'index.html'
    s = out[n]
    for src,old,new in [
        ('v25_systems.js','292_rebirth_keep_stats','293_rebirth1000'),
        ('v277_authority_client.js','283_auto_rpc','293_auto_skill'),
        ('v19_skills_market_realtime.js','283_auto_slots','293_auto_skill')]:
        s = once(s,f'./{src}?v={old}',f'./{src}?v={new}',n)
    out[n] = s
    return out

def read_sources():
    sources={}
    for name in FILES:
        path=ROOT/name
        if not path.is_file() or path.is_symlink():
            raise RuntimeError(f'STOP: missing/unsafe file {name}')
        data=path.read_bytes()
        sha=blob_sha(data)
        if sha!=EXPECTED[name]:
            raise RuntimeError(f'STOP: {name} has changed from verified V29.2R source ({sha}). Do not force install.')
        sources[name]=data.decode('utf-8-sig')
    return sources

def syntax_check(changed):
    if shutil.which('node'):
        for name in FILES:
            if not name.endswith('.js'):continue
            with tempfile.NamedTemporaryFile('w',suffix='.js',encoding='utf-8',delete=False) as t:
                t.write(changed[name]); tmp=t.name
            try:
                proc=subprocess.run(['node','--check',tmp],text=True,capture_output=True)
                if proc.returncode!=0:raise RuntimeError(f'STOP: JS syntax invalid in {name}: {proc.stderr[:700]}')
            finally:
                os.unlink(tmp)
        print('PASS: syntax check for 3 updated JavaScript files')
    else:
        print('INFO: node unavailable; JavaScript syntax not validated here')

def main():
    ap=argparse.ArgumentParser()
    mx=ap.add_mutually_exclusive_group(required=True)
    mx.add_argument('--check',action='store_true')
    mx.add_argument('--apply',action='store_true')
    args=ap.parse_args()
    try:
        sources=read_sources()
        changed=alter(sources)
        syntax_check(changed)
        for name in FILES:
            if changed[name]==sources[name]:raise RuntimeError(f'STOP: {name} unchanged despite patch')
        if args.check:
            print('PASS: V29.3 checks passed; source anchors, hashes, 4 planned files validated; no files modified.')
            return 0
        backdir=ROOT/('.amber_backups/V293_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d_%H%M%S_%f'))
        backdir.mkdir(parents=True,exist_ok=False)
        for name in FILES:
            shutil.copy2(ROOT/name,backdir/name)
        written=[]
        try:
            for name in FILES:
                path=ROOT/name
                fd,tmp=tempfile.mkstemp(prefix='.v293_',dir=str(ROOT))
                with os.fdopen(fd,'w',encoding='utf-8',newline='') as handle:handle.write(changed[name])
                os.chmod(tmp,path.stat().st_mode)
                os.replace(tmp,path)
                written.append(name)
        except Exception:
            for name in written:
                shutil.copy2(backdir/name,ROOT/name)
            raise
        print('PASS: V29.3 applied to '+', '.join(FILES))
        print('BACKUP:',backdir.relative_to(ROOT))
        print('SQL: already applied to Supabase; do not run any SQL in Codespaces.')
        return 0
    except Exception as e:
        print(str(e),file=sys.stderr)
        return 1
if __name__=='__main__':raise SystemExit(main())
