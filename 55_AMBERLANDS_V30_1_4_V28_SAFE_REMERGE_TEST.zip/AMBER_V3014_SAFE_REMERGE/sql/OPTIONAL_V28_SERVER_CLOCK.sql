-- Optional V30.1.4 informational clock RPC only.
-- The original V28 boss join / attack remain server-authoritative WITHOUT this.
-- Run once in SQL Editor only if you want the 30-minute banner synchronized
-- with Supabase clock rather than the user's device clock.
-- This function is read-only; it does not edit characters, fragments, or boss state.
create or replace function public.amber_v28_clock()
returns jsonb
language sql
volatile
security invoker
set search_path = ''
as $$
  select pg_catalog.jsonb_build_object(
    'ok',true,
    'epoch_ms',(extract(epoch from pg_catalog.clock_timestamp())*1000)::bigint
  );
$$;
revoke all on function public.amber_v28_clock() from public, anon;
grant execute on function public.amber_v28_clock() to authenticated;
