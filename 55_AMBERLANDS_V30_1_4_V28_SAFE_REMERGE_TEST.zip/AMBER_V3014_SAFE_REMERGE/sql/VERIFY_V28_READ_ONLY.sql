-- Run after installation. Results are read-only; do NOT insert fake fragments on production.
SELECT count(*) AS world_boss_types, min(hp_max) AS min_hp,max(hp_max) AS max_hp,
 min(drop_chance) AS min_fragment_chance,max(drop_chance) AS max_fragment_chance
 FROM public.amber_v28_boss_def;
SELECT tablename,rowsecurity FROM pg_tables
 WHERE schemaname='public' AND tablename LIKE 'amber_v28_%' ORDER BY tablename;
SELECT routine_name FROM information_schema.routines
 WHERE routine_schema='public' AND routine_name LIKE 'amber_v28_%' ORDER BY routine_name;
SELECT has_table_privilege('authenticated','public.amber_v28_fragment_bal','SELECT') AS fragment_table_direct_read,
 has_table_privilege('authenticated','public.amber_v28_fragment_bal','UPDATE') AS fragment_table_direct_write;
SELECT count(*) AS ultimate_weapons_granted FROM public.amber_v28_ult_weapon;
