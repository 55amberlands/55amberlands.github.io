#!/usr/bin/env python3
"""55 AMBERLANDS V30.1.4 — source-guarded V28 remerge on a TEST BRANCH ONLY.
Preserves the V30.1.3 ghost/aura/wing/in-hand-FX fixes, V27.3 ore boss,
existing Supabase/players, and current equipment and bulk-sell ownership.
"""
from pathlib import Path
import sys, shutil
ROOT=Path.cwd()
DIR=Path(__file__).resolve().parent
PAY=DIR/'payload'
MARK='AMBER_V3014_WORLD_BOSSES_REMERGE_TEST_ONLY'

def need(s,key,label,n=1):
    c=s.count(key)
    if c!=n:raise RuntimeError(f'STOP incompatible source: {label} expected={n} observed={c}')
def rep(s,a,b,label):
    need(s,a,label)
    return s.replace(a,b,1)

def main():
    # Never patch protected production branch silently; the caller creates test branch.
    import subprocess
    branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip()
    if branch in ('main','master','') or not branch.startswith('test-v28-safe-remerge-'):
        raise RuntimeError('STOP: create a test-v28-safe-remerge-* branch BEFORE installing; main not allowed')
    required=['index.html','v25_systems.js','v26_realtime.js','v24_px_weapons.js',
              'v24_px_heroes.js','v24_px_integration.js','online_bridge.js','v23_bulksell.js',
              'v27_3_boss_client.js','tools/export_pages.py']
    for rel in required:
        if not (ROOT/rel).is_file():raise RuntimeError('STOP missing original game file: '+rel)
    files={f:(ROOT/f).read_text('utf-8') for f in required if f.endswith(('.html','.js','.py'))}
    idx=files['index.html']
    if MARK in idx:
        print('PASS V30.1.4 already installed, no duplicate changes.');return
    # If main is V30.1.2, apply V30.1.3's exact patch inside the TEST branch only.
    if 'AMBER_V3013_AURA_BACK_WINGS_HERO_TITLE_WEAPON_GLOW' not in files['v25_systems.js']:
        if 'AMBER_V3012_SOURCE_FIXED_AURA' not in files['v25_systems.js']:
            raise RuntimeError('STOP missing V30.1.2 aura fix. Never revert working scene.')
        import subprocess
        subprocess.run([sys.executable,str(DIR/'install_v3013_verified.py')],check=True)
        files={f:(ROOT/f).read_text('utf-8') for f in required if f.endswith(('.html','.js','.py'))}
        idx=files['index.html']
    for f,signal in [('v25_systems.js','AMBER_V3013_AURA_BACK_WINGS_HERO_TITLE_WEAPON_GLOW'),
                     ('v24_px_weapons.js','V3013_IN_HAND_ENHANCEMENT_FX'),
                     ('v24_px_heroes.js','V3013_BOW_WEAPON_FX'),
                     ('v24_px_integration.js','V30.1.1 SOURCE FIX')]:
        if signal not in files[f]:raise RuntimeError('STOP required protected fix missing: '+f+' '+signal)
    if 'v28_boss_book.js' in idx:raise RuntimeError('STOP V28 already installed: would risk duplicate render and HUD')
    if not (ROOT/'online_bridge.js').read_text('utf-8').count('async function hideOverlay()'):
        raise RuntimeError('STOP latest online bridge missing; refuse to downgrade it')
    # Original ore boss: presentation only. RPC names & existing game logic stay intact.
    v25=files['v25_systems.js']; need(v25,'function wbTick()','old boss warning')
    need(v25,'data-v25="wbprac">','old practice button')
    v25=v25.replace('บอสโลก','บอสแร่')
    v25=rep(v25,'data-v25="wbprac">',
       '''onclick="window.AMBER_V28_HUB && window.AMBER_V28_HUB.open('select')">🐉 บอสโลกใหม่ 10 ตัว</button><button data-v25="wbprac">''',
       'independent V28 entry in ore-boss activities tab')
    # Rename only the legacy V27.3 client-facing prize toast; RPC stays unchanged.
    v273=files['v27_3_boss_client.js']
    v273=rep(v273,'เซิร์ฟเวอร์จ่ายรางวัล World Boss แล้ว',
              'เซิร์ฟเวอร์จ่ายรางวัลบอสแร่แล้ว','legacy V27.3 prize toast')
    # Keep V30.1.3's full aura CSS unchanged; cosmetic CSS is layer-limited inside payload.
    wp=files['v24_px_weapons.js'];
    wp=rep(wp,'function build(spec) {','function build(spec) {\n  if (spec.ult && PX.ultWeapons) return PX.ultWeapons.build(spec); // V3014 ultimate asset on real weapon', 'V28 weapon build')
    wp=rep(wp,'function fx(dst, spec, x, y, ang, t, sc = 1) {',
              'function fx(dst, spec, x, y, ang, t, sc = 1) {\n  if (spec.ult && PX.ultWeapons?.fx) return PX.ultWeapons.fx(dst, spec, x, y, ang, t, sc); // V3014 only actual +10 lightning',
              'V28 lightning on in-hand weapon')
    # V30.1.3 cache key already contains enh level, so do not touch it again.
    vp=files['v26_realtime.js']
    anchors=['async function openArena(practice) {', 'window.AMBER_V273',
             'serverMode: real, server:', 'boss: pickBoss()',
             'const joined = await window.AMBER_V273.join();',
             'if (result?.ok === true) {\n        v.wb.claimed = event;', 'function myRow()']
    for x in anchors:
        if x not in vp:raise RuntimeError('STOP incompatible V26 realtime arena anchor: '+x)
    vp=vp.replace('บอสโลก','บอสแร่') # only original old boss screen names, no V28 files
    picker="""function pickBossId(id) {
  try { const b=PX.worldBosses.get(id);if(b) return {name:b.name,lv:b.lv,boss:true,map:'worldboss',scene:b.scene,
    wb28:b.id,col:b.col,element:b.element,title:b.title,hp28:b.hp,atk28:b.atk}; }
  catch(e) {console.warn('[V3014 V28 boss asset]',e)} return pickBoss();
}
"""
    vp=rep(vp,'function myRow()',picker+'function myRow()','V28 boss picker')
    vp=rep(vp,'async function openArena(practice) {',
       'const API=()=>ARENA.api || window.AMBER_V273;\nasync function openArena(practice,opt) {\n  opt=opt||{};', 'arena adapter')
    vp=rep(vp,'if (real && !window.AMBER_V273?.ready?.())',
           'if (real && !(opt.api || window.AMBER_V273)?.ready?.())','authorized arena API')
    vp=rep(vp,'serverMode: real, server:', 'api:opt.api||null, isV28:!!opt.bossId, serverMode: real, server:', 'arena session')
    vp=rep(vp,'boss: pickBoss()', 'boss: (opt.bossId ? pickBossId(opt.bossId) : pickBoss())', 'V28 boss selection')
    vp=rep(vp,'const joined = await window.AMBER_V273.join();',
           'const joined = await (opt.api || window.AMBER_V273).join(opt.bossId);','server boss join')
    vp=rep(vp,'if (result?.ok === true) {\n        v.wb.claimed = event;',
         '''if (ARENA.api && result?.ok === true) {
        rewardTxt='✅ Supabase ยืนยันรางวัล'+(result.fragments_text ? ' · '+String(result.fragments_text) : (result.reason_text ? ' · '+String(result.reason_text) : ''));
        window.AMBER_V28S?.refreshFragments?.();
      } else if (result?.ok === true) {
        v.wb.claimed = event;''', 'keep old ore awards apart from V28 fragments')
    # Any old V273 arena calls that must use selected API use fallback to V273.
    vp=vp.replace('window.AMBER_V273','API()')
    vp=vp.replace('const API=()=>ARENA.api || API();', 'const API=()=>ARENA.api || window.AMBER_V273;')
    vp=vp.replace('(opt.api || API())','(opt.api || window.AMBER_V273)')
    vp=vp.replace('(opt.api || API()).join','(opt.api || window.AMBER_V273).join')
    if 'const API=()=>ARENA.api || window.AMBER_V273;' not in vp or 'pickBossId(opt.bossId)' not in vp:
        raise RuntimeError('STOP V28 arena adapter validation failed')
    # Select name per active arena, never label the 10 V28 bosses "ore bosses".
    original="ARENA.practice || ARENA.simulated ? 'ซ้อมบอสแร่ (ไม่มีรางวัลจริง)' : 'บอสแร่ทุก 3 ชั่วโมง · ยืนยันโดย Supabase'"
    replacement="ARENA.isV28 ? (ARENA.practice ? 'ซ้อมบอสโลก V28 (ไม่มีรางวัลจริง)' : 'บอสโลก V28 · ยืนยันโดย Supabase') : (ARENA.practice || ARENA.simulated ? 'ซ้อมบอสแร่ (ไม่มีรางวัลจริง)' : 'บอสแร่ทุก 3 ชั่วโมง · ยืนยันโดย Supabase')"
    vp=rep(vp,original,replacement,'correct separate arena labels')
    # A V28 boss defeat announces only V28; old ore boss is unchanged.
    server_defeat='if (s.defeated) finishArena(true);'
    if vp.count(server_defeat)!=1:raise RuntimeError('STOP expected one arena boss defeat path')
    vp=rep(vp,server_defeat,
       "if (s.defeated) { if (ARENA.api) try { window.AMBER_V28?.bossDown?.(ARENA.ev,ARENA.boss?.name,s.ranking); } catch (_) {} finishArena(true); }",
       'V28 defeat announcement isolated')
    # PWA icons are included as references but current manifest and SW are intentionally preserved.
    index=idx
    need(index,'</body>','index script insertion')
    tags='''\n<!-- AMBER_V3014_WORLD_BOSSES_REMERGE_TEST_ONLY | V30.1.3 source is still baseline -->
<script src="./v28_px_icons.js?v=3014"></script>
<script src="./v28_px_worldbosses.js?v=3014"></script>
<script src="./v28_skill_vfx.js?v=3014"></script>
<script src="./v28_battle_hud.js?v=3014_keep_original_hud"></script>
<script src="./v28_bag_costumes.js?v=3014_server_rpc"></script>
<script src="./v28_ult_weapons.js?v=3014_plus0_lights_at_plus10"></script>
<script src="./v28_boss_book.js?v=3014_independent_hub"></script>
<script src="./v3014_two_boss_announcements.js?v=3014_30min"></script>
'''
    index=rep(index,'</body>',tags+'</body>','index V28 assets')
    index=rep(index,'v25_systems.js?v=3013_aura_weapon_fx','v25_systems.js?v=3014_ore_boss_labels','title script cache-bust')
    index=rep(index,'v24_px_weapons.js?v=3013_aura_weapon_fx','v24_px_weapons.js?v=3014_ult_plus10','weapon script cache-bust')
    # If expected base V26 query differs, refuse rather than overwrite arbitrary file.
    import re
    rx=r'v26_realtime\.js\?v=[^"\s<>]+'
    match=re.findall(rx,index)
    if len(match)!=1:raise RuntimeError('STOP V26 script tag mismatch')
    index=index.replace(match[0],'v26_realtime.js?v=3014_ore_v28_split')
    # All source modifications were computed before writes. Never overwrite old V28 names.
    for src in PAY.glob('*.js'):
        if (ROOT/src.name).exists():raise RuntimeError('STOP duplicate installed V28 asset '+src.name)
    staged={'v25_systems.js':v25,'v24_px_weapons.js':wp,'v26_realtime.js':vp,'v27_3_boss_client.js':v273,'index.html':index}
    backup=ROOT/'.amber_v3014_backup';backup.mkdir(exist_ok=True)
    for fn,new_content in staged.items():
        old=ROOT/fn
        if not (backup/fn).exists():shutil.copy2(old,backup/fn)
        old.write_text(new_content,'utf-8')
    for src in PAY.glob('*.js'):
        target=ROOT/src.name
        shutil.copy2(src,target)
    print('PASS: V30.1.4 test branch installed; V3013 aura/hero/wing/weapon FX preserved.')
    print('      Original boss=บอสแร่; 10 V28 bosses separate; V28 exchange is server +0.')
    print('      No Supabase SQL, no player data, no old bridge modifications.')

if __name__=='__main__':
    try:main()
    except Exception as exc:sys.exit(str(exc))
