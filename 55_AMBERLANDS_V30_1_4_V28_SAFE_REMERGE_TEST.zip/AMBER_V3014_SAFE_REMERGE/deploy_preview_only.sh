#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
if [[ -n "$(git status --porcelain --untracked-files=no)" ]]; then
  echo 'STOP: There are staged/unstaged tracked changes. Do not discard your work.' >&2
  git status --short
  exit 1
fi
BASE=main
BRANCH=test-v28-safe-remerge-20261026
# Only this zip's root directory is required; the script is executed from the extracted .git path.
# No force-push / no mutation of remote main / no production Supabase SQL.
git switch "$BASE"
git pull --ff-only origin "$BASE"
if git show-ref --quiet --verify "refs/heads/$BRANCH"; then
  git switch "$BRANCH"
  echo 'Using existing V28 test branch.'
else
  git switch -c "$BRANCH"
fi
python3 .git/amber_v3014/AMBER_V3014_SAFE_REMERGE/install_v3014.py
for f in v28_*.js v3014_two_boss_announcements.js v24_px_weapons.js v24_px_heroes.js v24_px_integration.js v25_systems.js v26_realtime.js; do
  node --check "$f"
done
if [[ -f tools/check_static_site.py ]]; then python3 tools/check_static_site.py; fi
git add -- index.html v25_systems.js v26_realtime.js v24_px_weapons.js \
  v24_px_heroes.js v27_3_boss_client.js v28_px_icons.js v28_px_worldbosses.js v28_skill_vfx.js \
  v28_battle_hud.js v28_bag_costumes.js v28_ult_weapons.js v28_boss_book.js \
  v3014_two_boss_announcements.js
git diff --cached --check
if git diff --cached --quiet; then
  echo 'PASS: V30.1.4 test branch already installed; no duplicate commit.'
else
  git commit -m 'V30.1.4 safe V28 remerge on isolated preview branch'
fi
# Push ONLY preview branch; GitHub Pages continues to deploy main unchanged.
git push -u origin "$BRANCH"
printf '\nPASS: V30.1.4 pushed to TEST BRANCH ONLY. MAIN IS UNCHANGED.\n'
printf 'Important: GitHub Pages publishes main, not this test branch. Test in Codespaces preview or separate repository.\n'
