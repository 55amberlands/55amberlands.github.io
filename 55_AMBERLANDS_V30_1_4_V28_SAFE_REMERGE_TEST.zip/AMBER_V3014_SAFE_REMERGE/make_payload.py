from pathlib import Path
P=Path(__file__).parent/'payload'
# V28 book: independent boss hub. Do not hijack V27.3 ore arena and no top nav duplicates.
p=P/'v28_boss_book.js';s=p.read_text()
a=s.index('/* the 3-hourly world-boss banner / button now opens the boss-selection page instead of a random boss */')
b=s.index('window.AMBER_V28_HUB =',a)
s=s[:a]+'''/* V3014 source-safe merge: do not override AMBER_V26.openArena (old ore boss).
 * No V28 nav toolbar button: launch from ore-boss activities tab and V28 announcement below ore alert.
 */
'''+s[b:]
s=s.replace('เมื่อตีบวก <b>+10</b>', 'อาวุธที่แลกได้เริ่ม <b>+0</b> · เมื่อตีบวกถึง <b>+10</b>')
p.write_text(s)
# V28 client-side HUD visual-only; preserve V3013 base HUD and sprites.
p=P/'v28_battle_hud.js';s=p.read_text();s=s.replace('if (tier < 7) { if (o) o.remove(); return; }\n    const ultOn = !!(d.ult && tier >= 10 && window.PX && PX.ultWeapons);', '''// V3014: V3013 owns regular +7..+10 in-hand weapon FX; do not add a
    // second giant aura that masks heroes and wings. Only an actual ultimate +10
    // may use the unique V28 lightning sprite, drawn BEHIND the character.
    const ultOn = !!(d.ult && tier >= 10 && window.PX && PX.ultWeapons);
    if (!ultOn) { if (o) o.remove(); return; }''')
s=s.replace('#sprites .sprite>.px28-enh{position:absolute;left:-12%;right:-12%;top:-6%;bottom:-4%;pointer-events:none;z-index:8;', '#sprites .sprite>.px28-enh{position:absolute;left:-12%;right:-12%;top:-6%;bottom:-4%;pointer-events:none;z-index:1;')
s=s.replace('safe(paintAura); safe(labels); safe(paintHud); safe(hookEnhance);','safe(paintAura); safe(hookEnhance);')
# Leave implementation available, but no duplicated always-on HUD, title tags, potion toolbar.
p.write_text(s)
# V28 costumes: server RPC only, layer image below titles but keep visible cosmetic highlights.
p=P/'v28_bag_costumes.js';s=p.read_text().replace('#sprites .sprite>.px28-cos-b{z-index:1}#sprites .sprite>.px28-cos-f{z-index:9;mix-blend-mode:screen}', '#sprites .sprite>.px28-cos-b{z-index:1}#sprites .sprite>.px28-cos-f{z-index:4;mix-blend-mode:screen;opacity:.75}')
s=s.replace('#sprites .sprite>img.px24-hero.px28-costumed{position:relative;z-index:4;', '#sprites .sprite>img.px24-hero.px28-costumed{position:relative;z-index:5;')
p.write_text(s)
# Harden ultimate recognition: only named V28 legendary from canonical family.
p=P/'v28_ult_weapons.js';s=p.read_text();s=s.replace('const isUlt = g => !!g && (g.ult === true || RE.test(String(g.name || g.w || \'\')));', "const isUlt = g => !!g && RE.test(String(g.name || g.w || '')) && (/^ult_(?:sword|fist|bow|staff)_/.test(String(g.id || '')) || !g.id); // V3014 reject legacy/test gear mislabeled ult")
assert "V3014 reject legacy/test gear" in s
p.write_text(s)
