55 AMBERLANDS V30.1.4 — V28 SAFE REMERGE (TEST BRANCH ONLY)
วันที่ 26 ตุลาคม 2026

ฐานเกม: V30.1.3 ของเดิม (แก้ตัวละครซ้อน, ออร่า, ฉายา, ปีก, เอฟเฟกต์ +7–+10 แล้ว)
ถ้า GitHub ยังอยู่ V30.1.2, ตัวติดตั้งจะลงการแก้ V30.1.3 ให้ในสาขาทดสอบเท่านั้น
ห้ามแตก ZIP V28 ต้นฉบับทับ root ของเกม เพราะ index.html และ v25_systems.js ใน ZIP เป็นต้นฉบับรุ่นเก่า

ทำอะไรบ้าง
1. Rename UI บอสโลกเก่า -> บอสแร่ (ใช้ AMBER_V273 และรางวัลเดิม, ไม่เปลี่ยนชื่อตาราง/เซฟ/RPC)
2. วางบอสโลก V28 ใหม่ 10 ตัว แยกหน้าเลือกบอส/สมุดบอส/แลกอาวุธ (ใช้ RPC amber_v28_*)
3. ประกาศ 30 นาทีก่อนเกิด + ระหว่างเกิด จะแสดงอยู่ใต้ประกาศบอสแร่เดิม ไม่แปะปุ่มบนหน้า Dashboard
4. ใช้ V28 weapon original 4 classes; แลกจากเซิร์ฟเวอร์ได้ +0 เท่านั้น และสายฟ้าที่ตัวอาวุธเมื่อ +10 จริง
5. เพิ่มภาพไอเทมปัจจุบันในรายการขายหลายชิ้น (พึ่ง PXI / PX.items.gearImg ของเกมเดิม)
6. 12 ชุดคอสตูม V28 ซื้อ/สวมผ่าน RPC amber_v302_costume ที่ติดตั้งบน Supabase แล้วเท่านั้น
7. รักษา HUD เดิม, ตัวละครจริง, ปีก, ออร่า, เอฟเฟกต์อาวุธ +7-10; ไม่วาด HUD/ฮีโร่อีกชุดซ้อน
8. ไม่ติดตั้ง service worker จาก ZIP V28 เดิม เพื่อป้องกันโหลดไฟล์เกมเวอร์ชันเก่าจากแคช

สถานะ Supabase (อ่านจริงก่อนแพ็ก ZIP):
- ติดตั้ง public.amber_v28_info/fragments/join/attack/status/claim/leave/exchange ครบแล้ว
- 10 boss definitions, fragment balance/ledger, ultimate registry ครบแล้ว
- public.amber_v302_costume (ซื้อ/สวม/ถอดชุดผ่านเซิร์ฟเวอร์) ติดตั้งแล้ว
- public.amber_v284_bulk_sell (ขายหลายชิ้นบนเซิร์ฟเวอร์) ติดตั้งแล้ว
- ฟังก์ชัน public.amber_v28_exchange สร้าง gear `enh:0` แล้ว ไม่ต้องรัน SQL V28 ซ้ำ
- OPTIONAL_V28_SERVER_CLOCK.sql เป็นส่วนเพิ่มที่ไม่บังคับ: ให้เวลาประกาศอิงนาฬิกา Supabase
  หากยังไม่รัน การนับถอยหลังเป็นเวลาไทยตามนาฬิกาเครื่อง (เซิร์ฟเวอร์ยังเป็นฝ่ายตัดสินเข้าห้องจริง)

วิธีติดตั้งอย่างปลอดภัย
1) อัปโหลด ZIP นี้ไปไว้ ROOT GitHub/Codespaces โดยไม่แตกทับไฟล์เกม (ZIP อย่างเดียว)
2) เปิด Codespaces Terminal ใน Repository
3) รันคำสั่งเดียว (ดูด้านล่าง) สคริปต์จะ Git switch จาก main ไป branch ชื่อ
   test-v28-safe-remerge-20261026 และ PUSH เฉพาะสาขานั้น
4) main และ GitHub Pages จริงไม่ได้ถูกเปลี่ยนโดยสคริปต์นี้
5) ทดสอบ Codespaces Preview หรือ Clone Repo ทดสอบแยก + แนะนำ Supabase STAGING
6) หลังผู้ใช้ยืนยันและผ่านทดสอบจริงจึงค่อยพิจารณารวมเข้า main (ไม่มี auto merge)

cd "$(git rev-parse --show-toplevel)" && unzip -oq 55_AMBERLANDS_V30_1_4_V28_SAFE_REMERGE_TEST.zip -d .git/amber_v3014 && bash .git/amber_v3014/AMBER_V3014_SAFE_REMERGE/deploy_preview_only.sh

คำเตือนการทดสอบ: ในสาขาทดสอบ ระบบออนไลน์ยังชี้ Supabase Production ของเดิมใน online_bridge.js
อย่าใช้บัญชีผู้เล่นจริงทดสอบแลกอาวุธ/ซื้อสินค้า/รับเศษ/ตีบอส โดยไม่สลับไป STAGING ก่อน
จำกัดการทดลองใน branch แยกเฉพาะ UI และไฟล์ asset, หรือใช้ Supabase STAGING แยก

การรักษาความปลอดภัย: ไม่แก้ schema/SQL จริง/Save/EXP/Gold/อัตราดรอป และไม่แจกของจาก client
ถ้าเช็คไฟล์ไม่ผ่าน ตัวติดตั้งจะ STOP (ไม่ฝืนทับ code ที่ไม่ตรง)
