#!/usr/bin/env python3
"""V30.1.3: stable transparent aura layering and level-specific Pixel V24 in-hand enhancement light.

Strictly applies to V30.1.2 files; no SQL, no inventory, no old world-boss V28.
"""
from pathlib import Path
import sys, shutil

ROOT=Path.cwd()
MARK='AMBER_V3013_AURA_BACK_WINGS_HERO_TITLE_WEAPON_GLOW'


def checked_replace(s, old, new, label):
    count=s.count(old)
    if count!=1:
        raise RuntimeError(f'STOP: {label}: expected exactly one source match, found {count}')
    return s.replace(old,new,1)

v25_path=ROOT/'v25_systems.js'
w_path=ROOT/'v24_px_weapons.js'
h_path=ROOT/'v24_px_heroes.js'
idx_path=ROOT/'index.html'
for p in (v25_path,w_path,h_path,idx_path,ROOT/'v24_px_integration.js'):
    if not p.is_file(): raise RuntimeError(f'STOP missing source: {p.name}')

v25=v25_path.read_text('utf-8')
w=w_path.read_text('utf-8')
h=h_path.read_text('utf-8')
idx=idx_path.read_text('utf-8')

if MARK in v25:
    assert 'v25_systems.js?v=3013_aura_weapon_fx' in idx
    assert 'V3013_IN_HAND_ENHANCEMENT_FX' in w
    assert 'V3013_BOW_WEAPON_FX' in h
    print('PASS: V30.1.3 already installed (no duplicate patch)')
    sys.exit(0)
if 'AMBER_V3012_SOURCE_FIXED_AURA' not in v25:
    raise RuntimeError('STOP: V30.1.2 source aura fix is not installed. Keep the current V30.1.2 release.')
if 'V30.1.1 SOURCE FIX' not in (ROOT/'v24_px_integration.js').read_text('utf-8'):
    raise RuntimeError('STOP: V30.1.1 ghost character guard not installed')
if 'v25_systems.js?v=3012_ratio_stable_20261026' not in idx:
    raise RuntimeError('STOP: current index.html is not the expected V30.1.2 version')
if 'v28_ult_weapons.js' in idx:
    raise RuntimeError('STOP: V28 world boss layer detected. This patch is for V30.1.2 only')

# V30.1.2's aura dimensions and center anchor are preserved unchanged.
# Only change z-index of this *exact* source-owned block (not unrelated UI).
start=v25.index('/* AMBER_V3012_SOURCE_FIXED_AURA:')
end=v25.index('\n.px25-emote{',start)
css=v25[start:end]
css=checked_replace(css,'z-index:2!important;', 'z-index:0!important;', 'source title aura behind wings')
css=checked_replace(css,'#sprites .sprite>img.amber20-characterWing{z-index:1!important}', '#sprites .sprite>img.amber20-characterWing{z-index:1!important}', 'wing layer intact')
css=checked_replace(css,'#sprites .sprite>img.px24-hero.amber20-characterBody{z-index:3!important}', '#sprites .sprite>img.px24-hero.amber20-characterBody{z-index:3!important}', 'hero layer intact')
css=checked_replace(css,'#sprites .sprite>.px24-equipfx{z-index:4!important}', '#sprites .sprite>.px24-equipfx{z-index:0!important}', 'ambient gear effects behind hero')
css=checked_replace(css,'#sprites .sprite>.px25-plate{z-index:6!important}', '#sprites .sprite>.px25-plate{z-index:12!important}', 'title plate frontmost')
css=checked_replace(css,'#sprites .sprite>small{z-index:7!important}', '#sprites .sprite>small{z-index:11!important}', 'name near title front')
css+='\n/* '+MARK+' -- original 72x110 sprite, one aura only, behind wings and actual hero. */\n'
v25_new=v25[:start]+css+v25[end:]

# The V24 sprite cache previously ignored enhancement level (same hero rendered at +7 and +10).
old_key="PX.weaponKey = s => s ? [s.cls, s.tier, s.theme, s.seed].join('|') : 'none';"
new_key="PX.weaponKey = s => s ? [s.cls, s.tier, s.theme, s.seed, Math.max(0, Math.min(10, Math.floor(Number(s.enh) || 0)))].join('|') : 'none'; // V3013_IN_HAND_ENHANCEMENT_FX"
w_new=checked_replace(w,old_key,new_key,'weapon animation cache key')
start=w_new.index('function fx(dst, spec, x, y, ang, t, sc = 1) {')
end=w_new.index('\n/* local-space points of every op',start)
if "const th = spec.theme || 'normal'; if (th === 'normal' || th === 'training') return;" not in w_new[start:end]:
    raise RuntimeError('STOP: unexpected weapon FX source; likely another patch / V28 active')
fx_new=r'''function fx(dst, spec, x, y, ang, t, sc = 1) {
  // V3013_IN_HAND_ENHANCEMENT_FX: visual-only +7..+10 lights are rasterized
  // ON the weapon at its real grip angle. No DOM overlays / duplicate hero.
  const th = spec.theme || 'normal';
  const enh = Math.max(0, Math.min(10, Math.floor(Number(spec.enh) || 0)));
  if ((th === 'normal' || th === 'training') && enh < 7) return;
  const b = build(spec), a = ang * Math.PI / 180;
  const ca = Math.cos(a), sa = Math.sin(a);
  const at = (lx, ly) => [x + (lx * ca - ly * sa) * sc, y + (lx * sa + ly * ca) * sc];
  if (th !== 'normal' && th !== 'training') {
    // Preserve the original flame / frost / prism particles even below +7.
    const r = rng(hash(th) + Math.floor(t * 8));
    for (let i = 0; i < 4; i++) {
      const ly = -(r() * (b.len || 20)), lx = (r() - .5) * 5, p = at(lx, ly);
      const up = ((t * 3 + i * .27) % 1);
      if (th === 'fire') { dst.px(p[0], p[1] - up * 4, up < .5 ? '#ffd24a' : '#ff7a2a'); }
      else if (th === 'ice') { dst.px(p[0], p[1] + up * 2, '#ffffff'); if (i % 2) dst.px(p[0] + 1, p[1] + up * 2, '#9fe8ff'); }
      else { dst.px(p[0], p[1] - up * 3, RAIN[(i + Math.floor(t * 7)) % 7]); }
    }
  }
  if (enh < 7) return;
  const palette = {
    7:  ['#60cfff', '#c9f7ff'],        // blue edge sparkles
    8:  ['#ffcc4d', '#fff4b6'],        // gold halo sparks
    9:  ['#f368ff', '#ffd3ff'],        // violet-pink intense flares
    10: ['#e7faff', '#ffffff']         // white/rainbow radiance
  }[enh];
  const phase = Math.floor((((Number(t) || 0) % 1) + 1) % 1 * 8);
  const r = rng(hash('V3013-' + enh) + (spec.seed | 0) * 37 + phase * 113);
  const len = Math.max(7, Math.min(30, b.len || 20));
  const count = 4 + (enh - 6) * 3;
  for (let i = 0; i < count; i++) {
    const h = -(2 + r() * (len - 2));
    const offset = (r() - .5) * (3 + (enh - 7) * 1.5);
    const pos = at(offset, h);
    const cc = enh === 10 ? RAIN[(i + phase) % RAIN.length] : palette[i % 2];
    dst.px(pos[0], pos[1], cc);
    if (enh >= 8 && i % 3 === 0) {
      dst.px(pos[0] + 1, pos[1], '#ffffff');
      dst.px(pos[0], pos[1] - 1, palette[0]);
    }
    if (enh >= 9 && i % 4 === 0) {
      dst.px(pos[0] - 1, pos[1], palette[0]);
      dst.px(pos[0], pos[1] + 1, palette[1]);
    }
  }
  if (enh === 10) {
    // Small pixel-light trails and transparent vapor follow the weapon tip,
    // not the character's face. +10 only; no gameplay damage change.
    const pulse = (phase & 1) ? 1 : -1;
    for (let j = 0; j < 4; j++) {
      const v = at((j % 2 ? -2 : 2) + pulse, -(len * .72) - j * 2);
      dst.px(v[0], v[1] - j, PX.alpha('#e2dcff', .35 + j * .08));
      if ((j & 1) === 0) dst.px(v[0] + 1, v[1] - j, '#ffffff');
    }
  }
}'''
w_new=w_new[:start]+fx_new+w_new[end:]

# Bow did not invoke PX.weapon.fx at all; add one effect call next to its held bow.
bow='const pull = P.pull | 0; PX.weapon.stamp(spr, wp, hF[0] + 1, hF[1] - 1, 0, { scale: 1, pull, arrow: !!P.arrow, arrowLen: 20 });'
h_new=checked_replace(h,bow,bow+'\n    PX.weapon.fx(spr, wp, hF[0] + 1, hF[1] - 1, 0, P.fxT, 1); // V3013_BOW_WEAPON_FX','bow carried weapon fx')

# Cache-bust only 3 affected files. No existing V28 scripts are restored.
idx_new=checked_replace(idx,'v25_systems.js?v=3012_ratio_stable_20261026','v25_systems.js?v=3013_aura_weapon_fx','v25 script cache version')
idx_new=checked_replace(idx_new,'v24_px_weapons.js?v=24_2','v24_px_weapons.js?v=3013_aura_weapon_fx','weapon script cache version')
idx_new=checked_replace(idx_new,'v24_px_heroes.js?v=24_2','v24_px_heroes.js?v=3013_aura_weapon_fx','hero script cache version')

# Only touch files after *all* preconditions/replacements passed.
for p in (v25_path,w_path,h_path,idx_path):
    backup=p.with_name(p.name+'.v3013bak')
    if not backup.exists(): shutil.copy2(p,backup)
for p,data in [(v25_path,v25_new),(w_path,w_new),(h_path,h_new),(idx_path,idx_new)]:
    p.write_text(data,'utf-8')
print('PASS: V30.1.3 patched source aura z-order + weapon +7/+8/+9/+10 in-hand FX')
print('      No SQL / gear inventories / boss V28 files modified')
