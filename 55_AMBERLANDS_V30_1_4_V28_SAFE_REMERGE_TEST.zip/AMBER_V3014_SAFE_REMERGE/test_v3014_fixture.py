from pathlib import Path
import subprocess, shutil, tempfile
DIR=Path(__file__).resolve().parent
BASE=Path('/mnt/data/v3013_deploy_git_smoke')
root=Path(tempfile.mkdtemp(prefix='v3014_smoke_',dir='/mnt/data'))
for n in ['v25_systems.js','v24_px_weapons.js','v24_px_heroes.js','v24_px_integration.js']:
 shutil.copy2(BASE/n,root/n)
# Fixture: exact old V26 entrypoints, complete enough to syntax-check source mutations.
vp=r'''(()=>{
const ARENA = {on:true};
function pickBoss(){return {name:'เดิม',lv:1}}
function myRow(){return {name:'Hero'}}
function finishArena(win){}
const V25=()=>({wbWindow:()=>({open:true})});
async function openArena(practice) {
  const real=!practice;
  if (real && !window.AMBER_V273?.ready?.()) return;
  Object.assign(ARENA, {on:true,serverMode: real, server: null,boss: pickBoss()});
  const joined = await window.AMBER_V273.join();
  const result={ok:true};const v={wb:{}};const event='test';
  if (result?.ok === true) {
        v.wb.claimed = event;
  }
  const title=`👑 ${ARENA.practice || ARENA.simulated ? 'ซ้อมบอสโลก (ไม่มีรางวัลจริง)' : 'บอสโลกทุก 3 ชั่วโมง · ยืนยันโดย Supabase'}`;
  const s={defeated:true};
  if (s.defeated) finishArena(true);
  else if(s.ended||!V25().wbWindow().open) finishArena(false);
  return joined;
}
})();'''
(root/'v26_realtime.js').write_text(vp)
(root/'index.html').write_text('''<html><body><script src="./v24_px_weapons.js?v=3013_aura_weapon_fx"></script><script src="./v24_px_heroes.js?v=3013_aura_weapon_fx"></script><script src="./v25_systems.js?v=3013_aura_weapon_fx"></script><script src="./v26_realtime.js?v=297_crit_daily"></script></body></html>''')
(root/'online_bridge.js').write_text('async function hideOverlay() {}')
(root/'v23_bulksell.js').write_text('// existing bulk sell authority')
(root/'v27_3_boss_client.js').write_text("const note = 'เซิร์ฟเวอร์จ่ายรางวัล World Boss แล้ว'; // old boss API unchanged")
(root/'tools').mkdir()
(root/'tools/export_pages.py').write_text('from pathlib import Path\n')
subprocess.run(['git','init','-q'],cwd=root,check=True)
subprocess.run(['git','config','user.email','tester@example.test'],cwd=root,check=True)
subprocess.run(['git','config','user.name','Test'],cwd=root,check=True)
subprocess.run(['git','add','.'],cwd=root,check=True)
subprocess.run(['git','commit','-qm','V30.1.3 baseline'],cwd=root,check=True)
subprocess.run(['git','switch','-c','test-v28-safe-remerge-local'],cwd=root,check=True,stdout=subprocess.DEVNULL)
run=subprocess.run(['python3',str(DIR/'install_v3014.py')],cwd=root,text=True,capture_output=True)
print('INSTALL_RC:',run.returncode,'OUT:',run.stdout.strip(),'ERR:',run.stderr.strip())
if run.returncode: raise SystemExit(1)
for f in list(root.glob('v28_*.js'))+[root/'v3014_two_boss_announcements.js',root/'v25_systems.js',root/'v26_realtime.js',root/'v24_px_weapons.js']:
 r=subprocess.run(['node','--check',str(f)],text=True,capture_output=True)
 if r.returncode:print('JS_ERROR',f.name,r.stderr);raise SystemExit(1)
html=(root/'index.html').read_text();vp=(root/'v26_realtime.js').read_text();v25=(root/'v25_systems.js').read_text()
checks={
 'v3013_unchanged': 'AMBER_V3013_AURA_BACK_WINGS_HERO_TITLE_WEAPON_GLOW' in v25,
 'ghostfix': 'V30.1.1 SOURCE FIX' in (root/'v24_px_integration.js').read_text(),
 'old_ore_title': '👑 บอสแร่' in v25,
 'old_ore_api':'const API=()=>ARENA.api || window.AMBER_V273;' in vp,
 'V28_additive': 'v28_boss_book.js' in html and 'v28_ult_weapons.js' in html,
 'boss10': 'const LIST' in (root/'v28_px_worldbosses.js').read_text(),
 'no_nav_hijack': 'V.__hub28' not in (root/'v28_boss_book.js').read_text(),
 'server_cosmetics': "client.rpc('amber_v302_costume'" in (root/'v28_bag_costumes.js').read_text(),
 'no_client_cosmetics_mint': 'st.gems -=' not in (root/'v28_bag_costumes.js').read_text(),
 'V28_only_ult10_fx': 'spec?.enh || 0)) < 10' in (root/'v28_ult_weapons.js').read_text(),
 'aura_back_unchanged': 'z-index:0!important' in v25,
 'ann30min':'30*60000' in (root/'v3014_two_boss_announcements.js').read_text(),
 'no_sql_changes': not any(root.rglob('*.sql')),
}
print('CHECKS:',checks)
assert all(checks.values())
again=subprocess.run(['python3',str(DIR/'install_v3014.py')],cwd=root,text=True,capture_output=True)
assert again.returncode==0 and 'already installed' in again.stdout,(again.stdout,again.stderr)
print('PASS idempotent repeat install')
print('SMOKE_REPO',root)
