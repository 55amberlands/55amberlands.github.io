-- 55 AMBERLANDS V29.8 — World-map boss respawn authority
-- Safe for V29.7 server state. No character resets, no old EXP/reward edits.
BEGIN;
CREATE TABLE IF NOT EXISTS private.amber_v298_map_boss_spawns (
  monster_id text PRIMARY KEY REFERENCES private.amber_v276_monsters(monster_id),
  defeated_at timestamptz,
  available_at timestamptz NOT NULL DEFAULT '-infinity'::timestamptz,
  updated_at timestamptz NOT NULL DEFAULT clock_timestamp()
);
REVOKE ALL ON private.amber_v298_map_boss_spawns FROM PUBLIC,anon,authenticated;
INSERT INTO private.amber_v298_map_boss_spawns(monster_id)
SELECT monster_id FROM private.amber_v276_monsters
 WHERE is_boss AND map_id NOT IN ('dungeon','worldboss')
ON CONFLICT(monster_id) DO NOTHING;
CREATE TABLE IF NOT EXISTS private.amber_v298_function_backups(
  signature text PRIMARY KEY,
  original_definition text NOT NULL,
  backed_up_at timestamptz NOT NULL DEFAULT clock_timestamp()
);
REVOKE ALL ON private.amber_v298_function_backups FROM PUBLIC,anon,authenticated;
INSERT INTO private.amber_v298_function_backups(signature,original_definition)
SELECT n.nspname||'.'||p.proname||'('||pg_get_function_identity_arguments(p.oid)||')',pg_get_functiondef(p.oid)
 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
 WHERE n.nspname='public' AND p.proname IN ('amber_v277_attack','amber_v283_auto_attack')
ON CONFLICT(signature) DO NOTHING;

-- Read-only public RPC for the user's current map. No ability to advance/forge a spawn.
CREATE OR REPLACE FUNCTION public.amber_v298_map_boss_status(p_monster_id text DEFAULT NULL)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO ''
AS $body$
DECLARE u uuid:=(SELECT auth.uid()); player_map text; rows jsonb; 
        found_monster text; dead_until timestamptz; stamp timestamptz:=clock_timestamp();
BEGIN
  IF u IS NULL THEN RAISE EXCEPTION 'V298_LOGIN_REQUIRED'; END IF;
  SELECT save_data->>'map' INTO player_map FROM public.amber_characters WHERE user_id=u;
  IF player_map IS NULL THEN RAISE EXCEPTION 'V298_CHARACTER_REQUIRED'; END IF;
  IF p_monster_id IS NOT NULL THEN
    SELECT m.monster_id,b.available_at INTO found_monster,dead_until
      FROM private.amber_v276_monsters m
      JOIN private.amber_v298_map_boss_spawns b ON b.monster_id=m.monster_id
      WHERE m.monster_id=p_monster_id AND m.map_id=player_map AND m.is_boss;
    IF found_monster IS NULL THEN RAISE EXCEPTION 'V298_BOSS_NOT_IN_CURRENT_MAP'; END IF;
    RETURN jsonb_build_object('ok',true,'monster_id',found_monster,'respawning',dead_until>stamp,
      'respawn_at',CASE WHEN dead_until>stamp THEN dead_until ELSE NULL END,
      'seconds_left',CASE WHEN dead_until>stamp THEN greatest(0,ceil(extract(epoch from dead_until-stamp))::int) ELSE 0 END,
      'server_now',stamp);
  END IF;
  SELECT coalesce(jsonb_agg(jsonb_build_object(
    'monster_id',m.monster_id,'respawning',b.available_at>stamp,
    'respawn_at',CASE WHEN b.available_at>stamp THEN b.available_at ELSE NULL END,
    'seconds_left',CASE WHEN b.available_at>stamp THEN greatest(0,ceil(extract(epoch from b.available_at-stamp))::int) ELSE 0 END
  ) ORDER BY m.monster_id),'[]'::jsonb) INTO rows
    FROM private.amber_v276_monsters m
    JOIN private.amber_v298_map_boss_spawns b ON b.monster_id=m.monster_id
    WHERE m.map_id=player_map AND m.is_boss;
  RETURN jsonb_build_object('ok',true,'map_id',player_map,'bosses',rows,'server_now',stamp);
END $body$;
REVOKE ALL ON FUNCTION public.amber_v298_map_boss_status(text) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.amber_v298_map_boss_status(text) TO authenticated;

DO $v298$
DECLARE f oid; src text; before_text text; after_text text; hits integer;
BEGIN
 SELECT p.oid INTO f FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
   WHERE n.nspname='public' AND p.proname='amber_v277_attack';
 IF f IS NULL THEN RAISE EXCEPTION 'V298_ATTACK_MISSING'; END IF;
 src:=pg_get_functiondef(f);
 IF strpos(src,'V298_MAP_BOSS_RESPAWN_GUARD')>0 THEN RAISE EXCEPTION 'V298_ALREADY_INSTALLED'; END IF;
 before_text:='now_at timestamptz:=clock_timestamp(); roll int; n int;';
 after_text:='now_at timestamptz:=clock_timestamp(); roll int; n int; v298_ready_at timestamptz; v298_dead_at timestamptz;';
 hits:=(length(src)-length(replace(src,before_text,'')))/length(before_text);
 IF hits<>1 THEN RAISE EXCEPTION 'V298_ATTACK_DECLARE_MISMATCH %',hits; END IF;
 src:=replace(src,before_text,after_text);
 before_text:=$oldmap$IF s->>'map' IS DISTINCT FROM m.map_id THEN RAISE EXCEPTION 'V277_MAP_MISMATCH'; END IF;$oldmap$;
 after_text:=$newmap$IF s->>'map' IS DISTINCT FROM m.map_id THEN RAISE EXCEPTION 'V277_MAP_MISMATCH'; END IF;
  IF m.is_boss AND s->>'mob' IS DISTINCT FROM p_monster_id THEN RAISE EXCEPTION 'V298_BOSS_TARGET_MISMATCH'; END IF;$newmap$;
 hits:=(length(src)-length(replace(src,before_text,'')))/length(before_text);
 IF hits<>1 THEN RAISE EXCEPTION 'V298_MAP_VALIDATION_CHANGED %',hits; END IF;
 src:=replace(src,before_text,after_text);
 before_text:=$oldhp$IF hp_me<=0 THEN RAISE EXCEPTION 'V277_CHARACTER_DEAD'; END IF;$oldhp$;
 after_text:=$newhp$IF hp_me<=0 THEN RAISE EXCEPTION 'V277_CHARACTER_DEAD'; END IF;
  -- V298_MAP_BOSS_RESPAWN_GUARD: serialize boss hits; dead boss cannot take damage or award anything.
  IF m.is_boss THEN
    SELECT available_at,defeated_at INTO v298_ready_at,v298_dead_at
      FROM private.amber_v298_map_boss_spawns
      WHERE monster_id=m.monster_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'V298_BOSS_SPAWN_ROW_MISSING'; END IF;
    IF v298_ready_at>now_at THEN
      RETURN jsonb_build_object('ok',true,'save',s,'monster_id',m.monster_id,
        'monster_hp',0,'damage',0,'crit',false,'hit',false,'killed',false,
        'reward_exp',0,'reward_gold',0,'drop_name',NULL,
        'boss_respawning',true,'respawn_at',v298_ready_at,
        'respawn_seconds',greatest(0,ceil(extract(epoch from v298_ready_at-now_at))::int));
    END IF;
  END IF;$newhp$;
 hits:=(length(src)-length(replace(src,before_text,'')))/length(before_text);
 IF hits<>1 THEN RAISE EXCEPTION 'V298_HP_GUARD_CHANGED %',hits; END IF;
 src:=replace(src,before_text,after_text);
 before_text:='IF e.monster_id IS DISTINCT FROM m.monster_id THEN e.remaining_hp:=m.hp; END IF;';
 after_text:='IF e.monster_id IS DISTINCT FROM m.monster_id OR (m.is_boss AND v298_dead_at IS NOT NULL AND (e.last_action_at IS NULL OR e.last_action_at<=v298_dead_at)) THEN e.remaining_hp:=m.hp; END IF;';
 hits:=(length(src)-length(replace(src,before_text,'')))/length(before_text);
 IF hits<>1 THEN RAISE EXCEPTION 'V298_ENCOUNTER_RESET_CHANGED %',hits; END IF;
 src:=replace(src,before_text,after_text);
 before_text:='killed:=true;hp_mon:=m.hp;';
 after_text:=$newkill$killed:=true;
    IF m.is_boss THEN
      hp_mon:=0;
      v298_ready_at:=now_at+interval '5 minutes';
      UPDATE private.amber_v298_map_boss_spawns
        SET defeated_at=now_at, available_at=v298_ready_at,updated_at=now_at
        WHERE monster_id=m.monster_id;
    ELSE hp_mon:=m.hp; END IF;$newkill$;
 hits:=(length(src)-length(replace(src,before_text,'')))/length(before_text);
 IF hits<>1 THEN RAISE EXCEPTION 'V298_INSTANT_BOSS_RESPAWN_CHANGED %',hits; END IF;
 src:=replace(src,before_text,after_text);
 before_text:=$oldret$RETURN jsonb_build_object('ok',true,'monster_hp',hp_mon,$oldret$;
 after_text:=$newret$RETURN jsonb_build_object('ok',true,
   'monster_id',p_monster_id,'boss_respawning',m.is_boss AND killed,
   'respawn_at',CASE WHEN m.is_boss AND killed THEN v298_ready_at ELSE NULL END,
   'monster_hp',hp_mon,$newret$;
 hits:=(length(src)-length(replace(src,before_text,'')))/length(before_text);
 IF hits<>1 THEN RAISE EXCEPTION 'V298_ATTACK_RETURN_CHANGED %',hits; END IF;
 EXECUTE replace(src,before_text,after_text);

 -- Guard auto-potion BEFORE it consumes potions during an already dead boss.
 SELECT p.oid INTO f FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
   WHERE n.nspname='public' AND p.proname='amber_v283_auto_attack';
 IF f IS NULL THEN RAISE EXCEPTION 'V298_AUTO_ATTACK_MISSING'; END IF;
 src:=pg_get_functiondef(f);
 before_text:=$oldauto$IF NOT FOUND THEN RAISE EXCEPTION 'V283_CHARACTER_NOT_FOUND'; END IF;$oldauto$;
 after_text:=$newauto$IF NOT FOUND THEN RAISE EXCEPTION 'V283_CHARACTER_NOT_FOUND'; END IF;
 -- V298_AUTO_BOSS_PRECHECK: no potion or other inventory effect while a boss is respawning.
 IF EXISTS(SELECT 1 FROM private.amber_v298_map_boss_spawns b
     WHERE b.monster_id=p_monster_id AND b.available_at>clock_timestamp()) THEN
   RETURN jsonb_build_object('ok',true,'save',s,'monster_id',p_monster_id,
    'monster_hp',0,'damage',0,'crit',false,'hit',false,'killed',false,
    'reward_exp',0,'reward_gold',0,'boss_respawning',true,
    'respawn_at',(SELECT available_at FROM private.amber_v298_map_boss_spawns WHERE monster_id=p_monster_id),
    'auto_hp_used',false,'auto_mp_used',false);
 END IF;$newauto$;
 hits:=(length(src)-length(replace(src,before_text,'')))/length(before_text);
 IF hits<>1 THEN RAISE EXCEPTION 'V298_AUTO_ATTACK_ANCHOR_CHANGED %',hits; END IF;
 EXECUTE replace(src,before_text,after_text);
END $v298$;
COMMIT;
NOTIFY pgrst,'reload schema';
