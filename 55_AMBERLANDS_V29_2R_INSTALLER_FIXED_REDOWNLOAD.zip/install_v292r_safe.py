#!/usr/bin/env python3
"""55 AMBERLANDS V29.2R -- restored character stats, gear and full upper-ore UI; fail-closed installer."""
import argparse
import hashlib
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone

EXPECTED = {
    'v12_patch.js': 'af8093b738a2782ddad6c742fca618a30d989cac',
    'v16_inventory_market.js': '691449e9519a6fbdcbcd5dd92b148383ce885686',
    'v23_2_boss_loot.js': 'fd25a5f544f933392c5de15a939020f5270aa443',
    'v25_systems.js': 'af68d885efe4c534053af2661dff4a5c3bd5f0b2',
    'index.html': '5c5368f26b664ef03f7b75de101576310796babe',
}

def blob_sha(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode('ascii') + b'\0' + raw).hexdigest()

def replace_one(src, before, after, filename):
    count = src.count(before)
    if count != 1:
        raise RuntimeError(f'STOP: {filename}: expected exactly one anchor, found {count}: {before[:85]}')
    return src.replace(before, after, 1)

def patch_file(filename, src):
    if filename == 'v12_patch.js':
        # IMPORTANT: Visual-only equipment stats must agree with server combat for reborn owners.
        src=replace_one(src,
          "if(!g||slot!=='R'&&g.cls&&g.cls!==cls||Number(g.req||1)>lv)continue;",
          "if(!g||(slot!=='R'&&g.cls&&g.cls!==cls)||Number(g.req||1)>100||(Number(g.req||1)>lv&&Number(state.v25?.rebirth||0)<1))continue;",
          filename)
    elif filename == 'v16_inventory_market.js':
        before = "ga:['ไข่มุกพิทักษ์','หินตีบวกชุด/เกราะ','ใช้ตีบวกอุปกรณ์ที่ไม่ใช่อาวุธในเมนูอุปกรณ์','มีโอกาสดรอป 0.10% ต่อการกำจัดในช่วงทดสอบ']\n};"
        after = "ga:['ไข่มุกพิทักษ์','หินตีบวกชุด/เกราะ','ใช้ตีบวกอุปกรณ์ที่ไม่ใช่อาวุธในเมนูอุปกรณ์','มีโอกาสดรอป 0.10% ต่อการกำจัดในช่วงทดสอบ'],\n" \
                " ore_fire:['แร่อัคคี','แร่เสริมตีบวกอาวุธ','ใช้เพิ่มโอกาสตีบวกอาวุธ +5% (สูงสุด 95%)','ได้จากรางวัลบอสดันเจียน · สามารถขายให้ NPC หรือตั้งขายในตลาดผู้เล่น'],\n" \
                " ore_ice:['แร่เหมันต์','แร่เสริมตีบวกชุด/อุปกรณ์','ใช้เพิ่มโอกาสตีบวกเสื้อ ถุงมือ รองเท้า และแหวน +5% (สูงสุด 95%)','ได้จากรางวัลบอสดันเจียน · สามารถขายให้ NPC หรือตั้งขายในตลาดผู้เล่น'],\n" \
                " ore_prism:['แร่รุ้งดารา','แร่เสริมตีบวกทุกชนิด','ใช้เพิ่มโอกาสตีบวกอาวุธหรืออุปกรณ์ +10% (สูงสุด 95%)','ได้จากรางวัลบอสดันเจียน / บอสโลก · สามารถขายให้ NPC หรือตั้งขายในตลาดผู้เล่น']\n};"
        src=replace_one(src,before,after,filename)
        src=replace_one(src,"for(const k of ['gw','ga'])",'for(const k of Object.keys(MAT_HELP))',filename)
        # The legacy item modal should describe server-recognized rebirth gear privilege correctly.
        src=replace_one(src,
          "desc:`ต้องมีเลเวล ${g.req||1} ขึ้นไปจึงสวมได้${g.cls?' และต้องเป็นอาชีพ '+g.cls:''}`",
          "desc:`${(Number(state.v25?.rebirth)||0)>=1&&Number(g.req||1)<=100?'รีเบิร์นแล้วสวมได้โดยไม่ล็อกเลเวล':'ต้องมีเลเวล '+(g.req||1)+' ขึ้นไปจึงสวมได้'}${g.cls?' และต้องเป็นอาชีพ '+g.cls:''}`",
          filename)
    elif filename == 'v23_2_boss_loot.js':
        src=replace_one(src,'root.appendChild(section)};',
              "const upper=root.querySelector('.amber15-potions');if(upper)upper.insertAdjacentElement('afterend',section);else root.prepend(section)};",filename)
        src=replace_one(src,'แตะอุปกรณ์แล้วเลือกแร่ที่ต้องการก่อนกดตีบวก · แร่เสริมใช้ครั้งละ 1 เม็ด',
              'แตะไอคอนแร่เพื่อดูรายละเอียด / ขายให้ NPC / ลงขายในตลาด · ใช้แร่ตีบวกจากหน้าอุปกรณ์',filename)
    elif filename == 'v25_systems.js':
        src=replace_one(src,'ของ ทอง และสกิลที่เรียนยังอยู่ · ยืนยัน?',
              'ค่าสเตตัส STR/DEX/INT/VIT/AGI/LUK และแต้มที่ยังไม่ใช้คงเดิม เพิ่มแต้มรีเบิร์นใหม่ · ของ ทอง และสกิลยังอยู่ · ยืนยัน?',filename)
        src=replace_one(src,'ของ ทอง สกิล การ์ด ฉายา ยังอยู่ · ได้แต้มสเตตัสเริ่มต้นเพิ่ม',
              'STR/DEX/INT/VIT/AGI/LUK และแต้มสเตตัสเดิมไม่หาย · ได้แต้มเพิ่มอีก (20 + 50 × จำนวนรีเบิร์น) · ของ ทอง สกิล การ์ด ฉายา ยังอยู่',filename)
        # Keep unchanged styles, menus, and item pictures; messaging above matches the installed SQL.
    elif filename == 'index.html':
        src=replace_one(src,'./v12_patch.js?v=289_pet_rebirth','./v12_patch.js?v=292r_rebirth_owned_gear',filename)
        src=replace_one(src,'./v16_inventory_market.js?v=20','./v16_inventory_market.js?v=292_ores',filename)
        src=replace_one(src,'./v23_2_boss_loot.js?v=24_2','./v23_2_boss_loot.js?v=292_ores_top',filename)
        src=replace_one(src,'./v25_systems.js?v=289_pet_rebirth','./v25_systems.js?v=292_rebirth_keep_stats',filename)
    else:
        raise RuntimeError('Unexpected file: '+filename)
    return src

def main():
    ap=argparse.ArgumentParser(description='Read-only check or safely apply V29.2R patch to the precise V29.1 base source.')
    group=ap.add_mutually_exclusive_group(required=True)
    group.add_argument('--check',action='store_true')
    group.add_argument('--apply',action='store_true')
    args=ap.parse_args()
    root=Path.cwd()
    originals={}; replacements={}
    for name, expected in EXPECTED.items():
        p=root/name
        if not p.is_file(): raise RuntimeError('STOP: Required file missing: '+name)
        raw=p.read_bytes()
        got=blob_sha(raw)
        if got!=expected:
            raise RuntimeError(f'STOP: {name} changed; expected GitHub blob {expected}, found {got}. No files modified. Do not force.')
        txt=raw.decode('utf-8')
        new_txt=patch_file(name,txt)
        originals[name]=raw
        replacements[name]=new_txt.encode('utf-8')
        print(f'PASS {name}: source {got[:12]} + all anchors')
    # Verify syntax before ANY live-file modifications.
    node=shutil.which('node')
    if not node:
        raise RuntimeError('STOP: Node.js is required for preflight JavaScript syntax checks')
    with tempfile.TemporaryDirectory() as td:
        for name,data in replacements.items():
            if not name.endswith('.js'): continue
            file=Path(td)/name
            file.write_bytes(data)
            cp=subprocess.run([node,'--check',str(file)],capture_output=True,text=True)
            if cp.returncode: raise RuntimeError('STOP: JavaScript syntax failed for '+name+': '+cp.stderr[-900:])
            print('PASS JavaScript syntax:',name)
    if args.check:
        print('PASS: All V29.2R checks succeeded. No files modified.');return
    backup=root/'.v292r_backup'
    if backup.exists(): raise RuntimeError('STOP: Existing .v292r_backup found. Refusing to overwrite the previous backup')
    backup.mkdir(mode=0o700)
    try:
        for name,raw in originals.items():
            (backup/name).write_bytes(raw)
        for name,data in replacements.items():
            target=root/name
            tmp=target.with_name(target.name+'.v292r_new')
            tmp.write_bytes(data)
            tmp.replace(target)
    except BaseException:
        for name,raw in originals.items():
            (root/name).write_bytes(raw)
        raise
    print('PASS: V29.2R installed, five source files modified. NO assets or player records touched.')
    print('BACKUP: .v292r_backup/ (not included in git add).')
    print('NEXT: python3 tools/check_static_site.py && git diff --check')

if __name__=='__main__':
    try: main()
    except Exception as exc:
        print(str(exc),file=sys.stderr);sys.exit(1)
