# 55 AMBERLANDS V29.2R — Installer Fixed (2026-10-26)

แพตช์นี้แก้ข้อผิดพลาดตัวติดตั้งเดิมเท่านั้น ไม่แก้ SQL และไม่เพิ่ม/ลบไอเทม

## สาเหตุ
ตัวติดตั้งชุดเดิมค้นหาสตริง `./v12_patch.js?v=285_server_equipment` ใน `index.html`
แต่ไฟล์บน GitHub ใช้ `./v12_patch.js?v=289_pet_rebirth` อยู่แล้ว
ตัวติดตั้งเดิมจึงหยุดที่ `STOP: index.html: expected exactly one anchor, found 0`.

## วิธีติดตั้ง
1. อัปโหลด ZIP นี้ที่ GitHub > Add file > Upload files > Commit.
2. เปิด Codespaces > Terminal > New Terminal (อย่ารัน `set -e`).
3. วางคำสั่งด้านล่างทั้งหมดแล้วกด Enter:

```bash
git pull --ff-only origin main && \
unzip -o 55_AMBERLANDS_V29_2R_INSTALLER_FIXED_REDOWNLOAD.zip -d . && \
python3 install_v292r_safe.py --check && \
python3 install_v292r_safe.py --apply && \
python3 tools/check_static_site.py && \
git diff --check && \
git add index.html v12_patch.js v16_inventory_market.js v23_2_boss_loot.js v25_systems.js && \
git commit -m "V29.2R rebirth gear stats and upper ores" && \
git push origin main
```

หากคำสั่งใดล้มเหลว คำสั่งหลัง `&&` จะหยุด แต่ Terminal จะยังเปิดอยู่เพื่อแสดงข้อความผิดพลาด
ส่งภาพหน้าจอ Terminal ที่เห็นบรรทัด `STOP:` หรือ `Traceback:` มา

## ความปลอดภัย
- ติดตั้งทับเฉพาะ 5 ไฟล์เกมหลังตรวจ Git blob SHA และ JS Syntax ผ่าน
- สร้าง `.v292r_backup` ไว้ก่อนแทนที่ไฟล์จริง
- ไม่รัน SQL หรือทำการกู้คืน NaHee ซ้ำ
- ถ้ามีข้อความ `STOP` อย่าบังคับแทนที่ไฟล์
