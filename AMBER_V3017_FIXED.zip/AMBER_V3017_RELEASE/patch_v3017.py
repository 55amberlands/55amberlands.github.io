#!/usr/bin/env python3
"""V30.1.7: render verified world-boss +10 titles as compact, title-only plaques.
No server calls or gameplay / hero / wing / aura / weapon effect changes.
"""
from pathlib import Path
import sys, shutil
root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()
f = root/'v25_systems.js'
h = root/'index.html'
u = root/'v28_ult_weapons.js'
for p in [f,h,u]:
    if not p.is_file(): raise SystemExit('STOP: missing '+p.name)
s=f.read_text('utf-8'); html=h.read_text('utf-8'); ult=u.read_text('utf-8')
if 'AMBER_V3017_TITLE_ONLY_FIXED' in s:
    if 'v25_systems.js?v=3017_title_only_compact' not in html:
        raise SystemExit('STOP: V3017 already in JS but stale HTML cache tag')
    print('PASS: V30.1.7 already installed; no duplicate changes')
    sys.exit(0)
for marker in ['AMBER_V3016_V28_TITLE_ASSET_RESTORED','AMBER_V3012_SOURCE_FIXED_AURA','AMBER_V3013_AURA_BACK_WINGS_HERO_TITLE_WEAPON_GLOW','amber_v310_title','amber_v291_verified_cards']:
    if marker not in s: raise SystemExit('STOP: expected V30.1.6 feature missing: '+marker)
for marker in ['.px25-title.t-bolt','window.AMBER_V28_ULT','px28-ult-frame']:
    if marker not in ult: raise SystemExit('STOP: V28 title asset unavailable: '+marker)

old_names = """const ULT_NAMES = {
  ult_fist:'⚡ ราชันกรงเล็บอัสนี',
  ult_sword:'⚡ จักรพรรดิดาบสายฟ้า',
  ult_bow:'⚡ เทพพรานวชิระ',
  ult_staff:'⚡ จอมเวทอัสนีนิรันดร์'
};"""
new_names = """/* AMBER_V3017_TITLE_ONLY_FIXED: IDs remain unchanged; visual title names
 * are distinct from weapon names. This is display-only and server-authorized. */
const ULT_NAMES = {
  ult_fist:'⚡ จ้าวแห่งอสุนี',
  ult_sword:'⚡ ราชันพายุ',
  ult_bow:'⚡ ผู้ล่าเมฆา',
  ult_staff:'⚡ มหาเวทอัสนี'
};"""

old_fn = """  const v28cls = V3016_ULT_JOB[id];
  if (v28cls) {
    // Actual V28 weapon art + the ORIGINAL V28 electric title/frame, not a new
    // V25 rainbow-label substitute. The cache ensures no 500ms animation reset.
    let icon = v3016TitleIcons[id] || '';
    if (!icon) {
      try { icon = window.AMBER_V28_ULT?.icon?.(v28cls) || ''; } catch(e) { icon=''; }
      if (icon) v3016TitleIcons[id] = icon;
    }
    const name = window.AMBER_V28_ULT?.DEFS?.[v28cls]?.title;
    const display = name ? '⚡ '+name : t.name;
    const img = icon ? `<img class=\"px3016-v28-icon\" src=\"${esc(icon)}\" alt=\"\">` : '';
    return `<span class=\"px25-title t-bolt px28-ult-frame px3016-v28-badge${small ? ' sm' : ''}\">${img}<b>${esc(display)}</b></span>`;
  }"""
new_fn = """  if (V3016_ULT_JOB[id]) {
    // V3017: only the TITLE, never the equipment icon or equipment name.
    // Original V28 t-bolt + electric frame style is kept unchanged.
    return `<span class=\"px25-title t-bolt px28-ult-frame px3016-v28-badge${small ? ' sm' : ''}\"><b>${esc(t.name)}</b></span>`;
  }"""

old_css = """// V30.1.6: use genuine V28 weapon art inside the lightning title badge.
// Kept inside the existing title markup: NOT a new player Sprite layer.
css.textContent += `
.px25-title.px3016-v28-badge{display:inline-flex!important;align-items:center!important;gap:7px!important;max-width:min(100%,350px)!important;white-space:normal!important;line-height:1.28!important;overflow:visible!important;padding:4px 9px!important;isolation:isolate}
.px25-title.px3016-v28-badge.sm{font-size:10.5px!important;gap:4px!important;padding:2px 6px!important}
.px25-title.px3016-v28-badge>.px3016-v28-icon{width:29px!important;height:29px!important;min-width:29px!important;max-width:none!important;aspect-ratio:auto!important;object-fit:contain!important;image-rendering:pixelated!important;box-shadow:0 0 8px #4ae8ff88!important;border:0!important;position:relative!important;z-index:1!important}
.px25-title.px3016-v28-badge.sm>.px3016-v28-icon{width:19px!important;height:19px!important;min-width:19px!important}
.px25-title.px3016-v28-badge>b{position:relative;z-index:2;overflow-wrap:anywhere;white-space:normal}
.px25-plate .px3016-v28-badge{max-width:230px!important}
`;"""
new_css = """// AMBER_V3017_TITLE_PLAQUE_HORIZONTAL: Fix V3016 portrait-column wrapping.
// Limit rules to the verified V28 lightning title only; hero, wings and aura
// use their existing V3013 layers and remain untouched.
css.textContent += `
.px25-title.px3016-v28-badge{
  display:inline-flex!important;align-items:center!important;justify-content:center!important;
  box-sizing:border-box!important;width:max-content!important;max-width:none!important;
  min-width:max-content!important;flex:0 0 auto!important;
  white-space:nowrap!important;overflow-wrap:normal!important;word-break:keep-all!important;
  line-height:1.25!important;overflow:visible!important;padding:4px 11px!important;
  font-size:13px!important;isolation:isolate
}
.px25-title.px3016-v28-badge.sm{font-size:11px!important;padding:3px 8px!important}
.px25-title.px3016-v28-badge>b{
  position:relative;z-index:2;display:inline-block!important;
  width:max-content!important;max-width:none!important;white-space:nowrap!important;
  overflow-wrap:normal!important;word-break:keep-all!important;flex:0 0 auto!important
}
/* Parent is just 78px wide on mobile. Its badge MUST be free to grow sideways. */
#sprites .sprite>.px25-plate:has(.px3016-v28-badge){
  position:absolute!important;left:50%!important;transform:translateX(-50%)!important;
  width:max-content!important;min-width:max-content!important;max-width:none!important;
  white-space:nowrap!important;bottom:calc(100% + 5px)!important;
  z-index:12!important;pointer-events:none!important;overflow:visible!important
}
@media(max-width:380px){#sprites .sprite>.px25-plate .px3016-v28-badge.sm{font-size:10px!important;padding:3px 6px!important}}
`;"""

before_after = [(old_names,new_names,'legendary title names'),(old_fn,new_fn,'title display (remove equipment name and icon)'),(old_css,new_css,'fixed horizontal title plaque')]
for before,after,label in before_after:
    count=s.count(before)
    if count != 1: raise SystemExit(f'STOP: {label} differs from expected V3016 source ({count} matches); NOTHING WRITTEN')
    s=s.replace(before,after,1)
cache_old='<script src="./v25_systems.js?v=3016_v28_title_assets"></script>'
cache_new='<script src="./v25_systems.js?v=3017_title_only_compact"></script>'
if html.count(cache_old)!=1: raise SystemExit('STOP: expected V3016 index.html tag missing; NOTHING WRITTEN')
html=html.replace(cache_old,cache_new,1)

# No client-side title cheat: all active selections still use the same secured RPC.
for must in ["rpc('amber_v310_title'","rpc('amber_v291_verified_cards'",'setInterval(() => safe(decorateScene), 500);','AMBER_V3013_AURA_BACK_WINGS_HERO_TITLE_WEAPON_GLOW']:
    if must not in s: raise SystemExit('STOP: missing preserved system: '+must)
# Never add files to the live page or mutate SQL. Two-file atomic preparation.
backup=root/'.git'/'amber_v3017_source_backup'
backup.mkdir(parents=True,exist_ok=True)
for p in [f,h]:
    if not (backup/p.name).exists():shutil.copy2(p,backup/p.name)
f.write_text(s,'utf-8');h.write_text(html,'utf-8')
print('PASS: V30.1.7 title-only fixed; t-bolt preserved; only v25_systems.js and index.html changed')
