#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
BASE='a2472a70413914c814f1120d8e426cc22a0c9563'
ZIP='55_AMBERLANDS_V30_1_7_COMPACT_REAL_TITLES_FIX.zip'
BACKUP='backup-v3016-before-v3017-20261027'

git switch main
git pull --ff-only origin main
if grep -q 'AMBER_V3017_TITLE_ONLY_FIXED' v25_systems.js && grep -q 'v25_systems.js?v=3017_title_only_compact' index.html; then
  echo 'PASS: V30.1.7 already installed on main.'
  exit 0
fi
if test -n "$(git status --porcelain --untracked-files=no)"; then
  echo 'STOP: tracked files have uncommitted local changes. Nothing deployed.'
  exit 1
fi
if ! git merge-base --is-ancestor "$BASE" HEAD; then
  echo 'STOP: current main is not based on verified V30.1.6. Nothing deployed.'
  exit 1
fi
# Allow the GitHub "Add file" upload commit but NO modified game code since V3016.
mapfile -t CHANGED < <(git diff --name-only "$BASE" HEAD)
for file in "${CHANGED[@]}"; do
  case "$file" in
    55_AMBERLANDS_V30_1_7_COMPACT_REAL_TITLES_FIX.zip|55_AMBERLANDS_V30_1_6_RESTORE_V28_TITLE_ASSETS.zip) ;;
    *) echo "STOP: unexpected code change since V3016: $file"; exit 1 ;;
  esac
done
if [[ ! -f "$ZIP" ]]; then
  echo "STOP: ZIP is absent. Upload $ZIP via GitHub Add file first."
  exit 1
fi
if [[ ! -f "${BASH_SOURCE[0]%/*}/patch_v3017.py" ]]; then
  echo 'STOP: installer was not extracted from V3017 ZIP.'
  exit 1
fi

git push origin "$BASE:refs/heads/$BACKUP"
python3 "${BASH_SOURCE[0]%/*}/patch_v3017.py" .
node --check v25_systems.js
for anchor in 'v28_ult_weapons.js?v=3014_plus0_lights_at_plus10' 'v3015_stable_skills.js?v=3015_source_stable' 'v28_boss_book.js?v=3014_independent_hub'; do
  grep -Fq "$anchor" index.html || { echo "STOP: missing V28 or skill dependency: $anchor"; exit 1; }
done

git add v25_systems.js index.html
git diff --cached --check
git commit -m 'V30.1.7 fix portrait-wrapped titles; separate titles from weapon labels'
git push origin main
printf '\nPASS: V30.1.7 pushed to MAIN. V30.1.6 backed up to %s.\n' "$BACKUP"
