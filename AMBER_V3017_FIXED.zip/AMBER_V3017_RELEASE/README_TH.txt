55 AMBERLANDS — V30.1.7 ฉายาเป็นฉายา ไม่ใช่ชื่ออาวุธ
===============================================
ฐาน V30.1.6 (GitHub commit a2472a70413914c814f1120d8e426cc22a0c9563)

ปัญหา:
1. V3016 กำหนด max-width:min(100%,350px) ซึ่ง 100% มาจาก Sprite ตัวละครที่กว้างเพียง ~78px ทำให้ป้ายสายฟ้าแตกแนวตั้ง
2. โค้ด titleHTML() เอาชื่อจาก V28.ULT.DEFS.title พร้อมรูปอาวุธใส่ป้ายบนหัวจนดูเป็นชื่ออาวุธ

แก้เฉพาะ v25_systems.js และ index.html:
- ฉายาใหม่ตามอาชีพ: หมัด=จ้าวแห่งอสุนี, ดาบ=ราชันพายุ, ธนู=ผู้ล่าเมฆา, เวท=มหาเวทอัสนี
- คง ID เดิม ult_fist / ult_sword / ult_bow / ult_staff ใน Supabase และเงื่อนไข +10 ไม่เปลี่ยน
- ป้ายหัวใช้ข้อความฉายาเท่านั้น ไม่นำรูปหรือชื่ออาวุธขึ้นไป
- คงกรอบและประกายสายฟ้า V28 ที่ใช้คลาส t-bolt, px28-ult-frame
- จำกัดขนาดแนวนอนเฉพาะ #sprites .sprite>.px25-plate ของฉายาสายฟ้า
- ไม่แตะ canvas เกม, sprite, ข้อมูลผู้เล่น, เพิ่มลดเลือด, คอย, ดาเมจ, แสงอาวุธ +10
- ไม่ต้องรัน SQL; V3016 แก้ CHECK constraint รองรับ ID ทั้ง 4 แล้ว

ติดตั้ง:
1) Upload ไฟล์ ZIP นี้เข้า GitHub main ผ่าน Add file > Upload files > Commit changes
2) ใน Codespaces Terminal:
cd "$(git rev-parse --show-toplevel)" && git switch main && git pull --ff-only origin main && unzip -oq 55_AMBERLANDS_V30_1_7_COMPACT_REAL_TITLES_FIX.zip -d .git/amber_v3017 && bash .git/amber_v3017/AMBER_V3017_RELEASE/deploy_v3017.sh

ตรวจหลัง Deploy:
- ฉายาบนหัวเป็นแนวนอน ไม่ใช่เสายาว
- ฉายากับอาวุธแยกจากกัน; ชื่ออาวุธอยู่ในกระเป๋า
- ออร่า ปีก ตัวละคร ไม่ถูกซ้อนหรือตัด
- ผู้เล่นอาชีพหมัดที่สวมกรงเล็บตำนาน +10 สามารถเลือกฉายา 'จ้าวแห่งอสุนี'
- เช็กเอฟเฟกต์อาวุธ +10 และบอส V28 ยังคงทำงาน

ยังไม่ยืนยันภาพจริงบน Android หลัง Deploy; ต้องดูหน้ามือถืออีกครั้ง
