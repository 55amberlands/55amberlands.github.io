-- 55 AMBERLANDS V30.2 World Boss V28 adapter; additive installation only.
-- Never drops or overwrites any V27-V30 existing player tables/functions.
BEGIN;
CREATE TABLE IF NOT EXISTS public.amber_v28_boss_def (
 boss_id text PRIMARY KEY, lv integer NOT NULL CHECK (lv BETWEEN 1 AND 10),
 name text NOT NULL, element text NOT NULL DEFAULT '', hp_max bigint NOT NULL CHECK(hp_max>0),
 atk integer NOT NULL CHECK(atk>0), defense integer NOT NULL DEFAULT 0 CHECK(defense>=0),
 fragment_id text NOT NULL UNIQUE, fragment_name text NOT NULL DEFAULT '',
 drop_chance numeric NOT NULL DEFAULT .30 CHECK(drop_chance BETWEEN 0 AND 1)
);
CREATE TABLE IF NOT EXISTS public.amber_v28_boss_event(
 event_key text NOT NULL, boss_id text NOT NULL REFERENCES public.amber_v28_boss_def(boss_id),
 hp_now bigint NOT NULL CHECK(hp_now>=0),defeated_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT clock_timestamp(),PRIMARY KEY(event_key,boss_id)
);
CREATE TABLE IF NOT EXISTS public.amber_v28_boss_player(
 event_key text NOT NULL, boss_id text NOT NULL, user_id uuid NOT NULL,
 damage bigint NOT NULL DEFAULT 0 CHECK(damage>=0), hp integer NOT NULL CHECK(hp>=0),
 mp integer NOT NULL CHECK(mp>=0), last_hit_at timestamptz,joined_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 claimed boolean NOT NULL DEFAULT false,claimed_at timestamptz,
 PRIMARY KEY(event_key,boss_id,user_id),
 FOREIGN KEY(event_key,boss_id) REFERENCES public.amber_v28_boss_event(event_key,boss_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS amber_v28_one_boss_per_round ON public.amber_v28_boss_player(event_key,user_id);
CREATE TABLE IF NOT EXISTS public.amber_v28_fragment_ledger(
 id bigserial PRIMARY KEY, user_id uuid NOT NULL,fragment_id text NOT NULL,
 delta integer NOT NULL CHECK(delta<>0),reason text NOT NULL CHECK(reason IN('boss_drop','exchange')),
 event_key text,boss_id text,created_at timestamptz NOT NULL DEFAULT clock_timestamp()
);
CREATE UNIQUE INDEX IF NOT EXISTS amber_v28_one_drop_per_event ON public.amber_v28_fragment_ledger(user_id,fragment_id,event_key,reason) WHERE reason='boss_drop';
CREATE TABLE IF NOT EXISTS public.amber_v28_fragment_bal(
 user_id uuid NOT NULL, fragment_id text NOT NULL,qty integer NOT NULL DEFAULT 0 CHECK(qty>=0),PRIMARY KEY(user_id,fragment_id)
);
CREATE TABLE IF NOT EXISTS public.amber_v28_status_throttle(
 user_id uuid PRIMARY KEY,last_at timestamptz NOT NULL DEFAULT 'epoch'::timestamptz
);
CREATE TABLE IF NOT EXISTS public.amber_v28_ult_weapon(
 user_id uuid NOT NULL,cls text NOT NULL CHECK(cls IN('ดาบ','หมัด','ธนู','จอมเวท')),
 gear_id text NOT NULL UNIQUE,created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 PRIMARY KEY(user_id,cls)
);
INSERT INTO public.amber_v28_boss_def(boss_id,lv,name,element,hp_max,atk,defense,fragment_id,fragment_name,drop_chance) VALUES
('phoenix',1,'ฟีนิกซ์เพลิงอมตะ','ไฟ',150000,1200,120,'frag_phoenix','ขนนกเพลิงอมตะ',.30),
('titan',2,'ไททันอสุนีบาต','สายฟ้า',220000,1900,260,'frag_titan','แก่นสายฟ้าไททัน',.30),
('cerberus',3,'เซอร์เบอรัสแห่งนรก','ไฟนรก',330000,2900,420,'frag_cerberus','เขี้ยวสามเศียรนรก',.30),
('leviathan',4,'เลวีอาธานมหาสมุทร','น้ำ',480000,4300,750,'frag_leviathan','เกล็ดมหาสมุทรลึก',.30),
('empress',5,'จันทราจักรพรรดินี','จันทรา',710000,6500,1150,'frag_empress','เศษจันทราสะท้อนแสง',.30),
('lich',6,'ราชาลิชวิญญาณ','วิญญาณ',1050000,9500,1850,'frag_lich','กระดูกวิญญาณมรกต',.30),
('solar',7,'มังกรสุริยะทอง','แสง',1550000,14000,2800,'frag_solar','เกล็ดสุริยะทอง',.30),
('magma',8,'ยักษ์หินลาวา','ลาวา',2300000,21000,4400,'frag_magma','แก่นลาวาหลอมละลาย',.30),
('prism',9,'โคลอสซัสปริซึม','สายรุ้ง',3400000,31000,6800,'frag_prism','ปริซึมเจ็ดสี',.30),
('seraph',10,'เซราฟว่างเปล่า','ความว่างเปล่า',5000000,46000,10000,'frag_seraph','ปีกแห่งความว่างเปล่า',.30)
ON CONFLICT(boss_id) DO NOTHING;
DO $$DECLARE t text;BEGIN FOREACH t IN ARRAY ARRAY['amber_v28_boss_def','amber_v28_boss_event','amber_v28_boss_player','amber_v28_fragment_ledger','amber_v28_fragment_bal','amber_v28_status_throttle','amber_v28_ult_weapon'] LOOP
 EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY',t);
 EXECUTE format('REVOKE ALL ON public.%I FROM PUBLIC,anon,authenticated',t);
END LOOP;END$$;
REVOKE ALL ON SEQUENCE public.amber_v28_fragment_ledger_id_seq FROM PUBLIC,anon,authenticated;
COMMIT;
