-- V30.2 ATOMIC MIGRATION: all-or-nothing; preserves V27-V30 data.
BEGIN;
-- 01_WORLD_BOSS_SERVER.sql
-- 55 AMBERLANDS V30.2 World Boss V28 adapter; additive installation only.
-- Never drops or overwrites any V27-V30 existing player tables/functions.
CREATE TABLE IF NOT EXISTS public.amber_v28_boss_def (
 boss_id text PRIMARY KEY, lv integer NOT NULL CHECK (lv BETWEEN 1 AND 10),
 name text NOT NULL, element text NOT NULL DEFAULT '', hp_max bigint NOT NULL CHECK(hp_max>0),
 atk integer NOT NULL CHECK(atk>0), defense integer NOT NULL DEFAULT 0 CHECK(defense>=0),
 fragment_id text NOT NULL UNIQUE, fragment_name text NOT NULL DEFAULT '',
 drop_chance numeric NOT NULL DEFAULT .30 CHECK(drop_chance BETWEEN 0 AND 1)
);
CREATE TABLE IF NOT EXISTS public.amber_v28_boss_event(
 event_key text NOT NULL, boss_id text NOT NULL REFERENCES public.amber_v28_boss_def(boss_id),
 hp_now bigint NOT NULL CHECK(hp_now>=0),defeated_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT clock_timestamp(),PRIMARY KEY(event_key,boss_id)
);
CREATE TABLE IF NOT EXISTS public.amber_v28_boss_player(
 event_key text NOT NULL, boss_id text NOT NULL, user_id uuid NOT NULL,
 damage bigint NOT NULL DEFAULT 0 CHECK(damage>=0), hp integer NOT NULL CHECK(hp>=0),
 mp integer NOT NULL CHECK(mp>=0), last_hit_at timestamptz,joined_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 claimed boolean NOT NULL DEFAULT false,claimed_at timestamptz,
 PRIMARY KEY(event_key,boss_id,user_id),
 FOREIGN KEY(event_key,boss_id) REFERENCES public.amber_v28_boss_event(event_key,boss_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS amber_v28_one_boss_per_round ON public.amber_v28_boss_player(event_key,user_id);
CREATE TABLE IF NOT EXISTS public.amber_v28_fragment_ledger(
 id bigserial PRIMARY KEY, user_id uuid NOT NULL,fragment_id text NOT NULL,
 delta integer NOT NULL CHECK(delta<>0),reason text NOT NULL CHECK(reason IN('boss_drop','exchange')),
 event_key text,boss_id text,created_at timestamptz NOT NULL DEFAULT clock_timestamp()
);
CREATE UNIQUE INDEX IF NOT EXISTS amber_v28_one_drop_per_event ON public.amber_v28_fragment_ledger(user_id,fragment_id,event_key,reason) WHERE reason='boss_drop';
CREATE TABLE IF NOT EXISTS public.amber_v28_fragment_bal(
 user_id uuid NOT NULL, fragment_id text NOT NULL,qty integer NOT NULL DEFAULT 0 CHECK(qty>=0),PRIMARY KEY(user_id,fragment_id)
);
CREATE TABLE IF NOT EXISTS public.amber_v28_status_throttle(
 user_id uuid PRIMARY KEY,last_at timestamptz NOT NULL DEFAULT 'epoch'::timestamptz
);
CREATE TABLE IF NOT EXISTS public.amber_v28_ult_weapon(
 user_id uuid NOT NULL,cls text NOT NULL CHECK(cls IN('ดาบ','หมัด','ธนู','จอมเวท')),
 gear_id text NOT NULL UNIQUE,created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 PRIMARY KEY(user_id,cls)
);
INSERT INTO public.amber_v28_boss_def(boss_id,lv,name,element,hp_max,atk,defense,fragment_id,fragment_name,drop_chance) VALUES
('phoenix',1,'ฟีนิกซ์เพลิงอมตะ','ไฟ',150000,1200,120,'frag_phoenix','ขนนกเพลิงอมตะ',.30),
('titan',2,'ไททันอสุนีบาต','สายฟ้า',220000,1900,260,'frag_titan','แก่นสายฟ้าไททัน',.30),
('cerberus',3,'เซอร์เบอรัสแห่งนรก','ไฟนรก',330000,2900,420,'frag_cerberus','เขี้ยวสามเศียรนรก',.30),
('leviathan',4,'เลวีอาธานมหาสมุทร','น้ำ',480000,4300,750,'frag_leviathan','เกล็ดมหาสมุทรลึก',.30),
('empress',5,'จันทราจักรพรรดินี','จันทรา',710000,6500,1150,'frag_empress','เศษจันทราสะท้อนแสง',.30),
('lich',6,'ราชาลิชวิญญาณ','วิญญาณ',1050000,9500,1850,'frag_lich','กระดูกวิญญาณมรกต',.30),
('solar',7,'มังกรสุริยะทอง','แสง',1550000,14000,2800,'frag_solar','เกล็ดสุริยะทอง',.30),
('magma',8,'ยักษ์หินลาวา','ลาวา',2300000,21000,4400,'frag_magma','แก่นลาวาหลอมละลาย',.30),
('prism',9,'โคลอสซัสปริซึม','สายรุ้ง',3400000,31000,6800,'frag_prism','ปริซึมเจ็ดสี',.30),
('seraph',10,'เซราฟว่างเปล่า','ความว่างเปล่า',5000000,46000,10000,'frag_seraph','ปีกแห่งความว่างเปล่า',.30)
ON CONFLICT(boss_id) DO NOTHING;
DO $$DECLARE t text;BEGIN FOREACH t IN ARRAY ARRAY['amber_v28_boss_def','amber_v28_boss_event','amber_v28_boss_player','amber_v28_fragment_ledger','amber_v28_fragment_bal','amber_v28_status_throttle','amber_v28_ult_weapon'] LOOP
 EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY',t);
 EXECUTE format('REVOKE ALL ON public.%I FROM PUBLIC,anon,authenticated',t);
END LOOP;END$$;
REVOKE ALL ON SEQUENCE public.amber_v28_fragment_ledger_id_seq FROM PUBLIC,anon,authenticated;
-- 02_WORLD_BOSS_RPC.sql
-- Install after 01_WORLD_BOSS_SERVER.sql. Use authenticated RPC only.
CREATE OR REPLACE FUNCTION public.amber_v28_info() RETURNS jsonb LANGUAGE sql STABLE
SET search_path TO '' AS $$SELECT jsonb_build_object('ok',true,'version',28,'mode','server_verified')$$;
CREATE OR REPLACE FUNCTION public.amber_v28_fragments() RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path TO '' AS $$
DECLARE u uuid:=auth.uid(); fr jsonb:='{}'::jsonb; b record; wa jsonb;
BEGIN
 IF u IS NULL THEN RETURN jsonb_build_object('ok',false,'reason','login_required');END IF;
 FOR b IN SELECT d.fragment_id,coalesce(x.qty,0) qty FROM public.amber_v28_boss_def d
 LEFT JOIN public.amber_v28_fragment_bal x ON x.fragment_id=d.fragment_id AND x.user_id=u LOOP
 fr:=jsonb_set(fr,ARRAY[b.fragment_id],to_jsonb(b.qty),true);
 END LOOP;
 SELECT coalesce(jsonb_agg(jsonb_build_object('cls',w.cls,'gear_id',w.gear_id)),'[]'::jsonb)
 INTO wa FROM public.amber_v28_ult_weapon w WHERE w.user_id=u;
 RETURN jsonb_build_object('ok',true,'fragments',fr,'weapons',wa);
END$$;
CREATE OR REPLACE FUNCTION public.amber_v28_join(p_boss_id text) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER
SET search_path TO '' AS $$
DECLARE u uuid:=auth.uid(); local_time timestamp:=clock_timestamp() AT TIME ZONE 'Asia/Bangkok';
 ek text; b public.amber_v28_boss_def%rowtype; e public.amber_v28_boss_event%rowtype;
 p public.amber_v28_boss_player%rowtype; s jsonb; v jsonb; other text;
BEGIN
 IF u IS NULL THEN RETURN jsonb_build_object('ok',false,'reason','login_required');END IF;
 SELECT * INTO b FROM public.amber_v28_boss_def WHERE boss_id=p_boss_id;
 IF NOT FOUND THEN RETURN jsonb_build_object('ok',false,'reason','bad_boss'); END IF;
 IF mod(extract(hour from local_time)::int,3)<>0 OR extract(minute from local_time)>=30
 THEN RETURN jsonb_build_object('ok',false,'reason','window_closed'); END IF;
 ek:=to_char(local_time,'YYYY-MM-DD"T"HH24');
 PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(ek||u::text,0));
 SELECT boss_id INTO other FROM public.amber_v28_boss_player WHERE event_key=ek AND user_id=u LIMIT 1;
 IF other IS NOT NULL AND other<>p_boss_id THEN RETURN jsonb_build_object('ok',false,'reason','already_in_other_boss');END IF;
 SELECT save_data INTO s FROM public.amber_characters WHERE user_id=u;
 IF s IS NULL THEN RETURN jsonb_build_object('ok',false,'reason','character_missing'); END IF;
 v:=private.amber_v300_max_vitals(u,s);
 INSERT INTO public.amber_v28_boss_event(event_key,boss_id,hp_now) VALUES(ek,b.boss_id,b.hp_max)
 ON CONFLICT(event_key,boss_id) DO NOTHING;
 SELECT * INTO e FROM public.amber_v28_boss_event WHERE event_key=ek AND boss_id=b.boss_id FOR UPDATE;
 IF e.defeated_at IS NOT NULL OR e.hp_now<=0 THEN RETURN jsonb_build_object('ok',false,'reason','boss_defeated');END IF;
 INSERT INTO public.amber_v28_boss_player(event_key,boss_id,user_id,hp,mp)
 VALUES(ek,b.boss_id,u,LEAST((v->>'max_hp')::integer,greatest(0,coalesce((s->>'hp')::int,0))),
 LEAST((v->>'max_mp')::integer,greatest(0,coalesce((s->>'mp')::int,0))))
 ON CONFLICT(event_key,boss_id,user_id) DO NOTHING;
 SELECT * INTO p FROM public.amber_v28_boss_player WHERE event_key=ek AND boss_id=b.boss_id AND user_id=u;
 IF p.claimed THEN RETURN jsonb_build_object('ok',false,'reason','already_claimed');END IF;
 RETURN jsonb_build_object('ok',true,'event_key',ek,'boss_id',b.boss_id,'boss_hp',e.hp_now,
 'boss_max_hp',b.hp_max,'my_hp',p.hp,'my_mp',p.mp,'my_damage',p.damage,'ranking','[]'::jsonb);
END$$;
CREATE OR REPLACE FUNCTION public.amber_v28_status(p_event_key text,p_boss_id text) RETURNS jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path TO '' AS $$
DECLARE u uuid:=auth.uid(); e public.amber_v28_boss_event%rowtype; b public.amber_v28_boss_def%rowtype;
 p public.amber_v28_boss_player%rowtype; rank_rows jsonb;
BEGIN
 IF u IS NULL THEN RETURN jsonb_build_object('ok',false,'reason','login_required');END IF;
 -- Prevent abusive polling. This table is never accessible directly from browser roles.
 INSERT INTO public.amber_v28_status_throttle(user_id,last_at) VALUES(u,clock_timestamp())
 ON CONFLICT(user_id) DO UPDATE SET last_at=EXCLUDED.last_at
 WHERE public.amber_v28_status_throttle.last_at < EXCLUDED.last_at - interval '250 milliseconds';
 IF NOT FOUND THEN RETURN jsonb_build_object('ok',false,'reason','rate_limited');END IF;
 IF p_event_key IS NULL OR length(p_event_key)>32 THEN RETURN jsonb_build_object('ok',false,'reason','bad_event');END IF;
 IF p_boss_id IS NULL THEN SELECT boss_id INTO p_boss_id FROM public.amber_v28_boss_player WHERE user_id=u AND event_key=p_event_key LIMIT 1;END IF;
 IF p_boss_id IS NULL THEN RETURN jsonb_build_object('ok',false,'reason','not_joined');END IF;
 SELECT * INTO p FROM public.amber_v28_boss_player
 WHERE user_id=u AND event_key=p_event_key AND boss_id=p_boss_id;
 IF NOT FOUND THEN RETURN jsonb_build_object('ok',false,'reason','not_joined');END IF;
 SELECT * INTO e FROM public.amber_v28_boss_event WHERE event_key=p_event_key AND boss_id=p_boss_id;
 SELECT * INTO b FROM public.amber_v28_boss_def WHERE boss_id=p_boss_id;
 SELECT coalesce(jsonb_agg(z),'[]'::jsonb) INTO rank_rows FROM (
 SELECT jsonb_build_object('name',COALESCE(c.character_name,'ผู้เล่น'),'damage',f.damage) z
 FROM public.amber_v28_boss_player f LEFT JOIN public.amber_characters c ON c.user_id=f.user_id
 WHERE f.event_key=p_event_key AND f.boss_id=p_boss_id ORDER BY f.damage DESC,f.joined_at ASC LIMIT 5
 ) tops;
 RETURN jsonb_build_object('ok',true,'event_key',p_event_key,'boss_id',p_boss_id,
 'boss_hp',e.hp_now,'boss_max_hp',b.hp_max,'my_hp',p.hp,'my_mp',p.mp,
 'my_damage',p.damage,'ranking',rank_rows,'defeated',e.defeated_at IS NOT NULL,
 'ended', e.defeated_at IS NULL AND (clock_timestamp() AT TIME ZONE 'Asia/Bangkok') >= 
 (to_timestamp(p_event_key,'YYYY-MM-DD"T"HH24') AT TIME ZONE 'Asia/Bangkok')+interval '30 minutes');
END$$;
CREATE OR REPLACE FUNCTION public.amber_v28_attack(p_skill boolean DEFAULT false,p_auto_potion boolean DEFAULT false)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO '' AS $$
DECLARE u uuid:=auth.uid(); local_time timestamp:=clock_timestamp() AT TIME ZONE 'Asia/Bangkok';
 ek text:=to_char(clock_timestamp() AT TIME ZONE 'Asia/Bangkok','YYYY-MM-DD"T"HH24');
 p public.amber_v28_boss_player%rowtype;e public.amber_v28_boss_event%rowtype;
 b public.amber_v28_boss_def%rowtype;s jsonb; cs jsonb; v jsonb;
 atk integer; defense_player integer; crit_p numeric; acc numeric; cd timestamptz:=clock_timestamp();
 hit integer:=0;incoming integer:=0;newhp integer;newmp integer;usedhp boolean:=false;usedmp boolean:=false;
 hp_max integer; stock integer;dice numeric;
BEGIN
 IF u IS NULL THEN RETURN jsonb_build_object('ok',false,'reason','login_required');END IF;
 IF mod(extract(hour from local_time)::int,3)<>0 OR extract(minute from local_time)>=30
 THEN RETURN jsonb_build_object('ok',false,'reason','window_closed','ended',true);END IF;
 SELECT * INTO p FROM public.amber_v28_boss_player WHERE event_key=ek AND user_id=u LIMIT 1;
 IF NOT FOUND THEN RETURN jsonb_build_object('ok',false,'reason','not_joined');END IF;
 SELECT * INTO e FROM public.amber_v28_boss_event WHERE event_key=ek AND boss_id=p.boss_id FOR UPDATE;
 SELECT * INTO p FROM public.amber_v28_boss_player WHERE event_key=ek AND boss_id=p.boss_id AND user_id=u FOR UPDATE;
 SELECT * INTO b FROM public.amber_v28_boss_def WHERE boss_id=p.boss_id;
 IF e.defeated_at IS NOT NULL OR e.hp_now<=0 THEN RETURN jsonb_build_object('ok',false,'reason','boss_defeated','defeated',true);END IF;
 IF p.claimed THEN RETURN jsonb_build_object('ok',false,'reason','already_claimed');END IF;
 IF p.hp<=0 THEN RETURN jsonb_build_object('ok',false,'reason','player_defeated');END IF;
 IF p.last_hit_at IS NOT NULL AND cd-p.last_hit_at < interval '900 milliseconds'
 THEN RETURN jsonb_build_object('ok',false,'reason','cooldown');END IF;
 SELECT save_data INTO s FROM public.amber_characters WHERE user_id=u FOR UPDATE;
 IF s IS NULL THEN RETURN jsonb_build_object('ok',false,'reason','character_missing');END IF;
 cs:=private.amber_v285_combat_stats(u,s);
 v:=private.amber_v300_max_vitals(u,s);
 atk:=greatest(1,coalesce((cs->>'atk')::integer,1));
 defense_player:=greatest(0,coalesce((cs->>'def')::integer,0));
 crit_p:=least(.8,greatest(0,coalesce((cs->>'crit')::numeric,0)));
 acc:=least(.985,greatest(.2,coalesce((cs->>'accuracy')::numeric,.8)));
 hp_max:=(v->>'max_hp')::integer;
 newhp:=p.hp;newmp:=p.mp;
 IF p_skill AND newmp>=50 THEN newmp:=newmp-50;usedmp:=true;END IF;
 IF random()<=acc THEN
   dice:=.88+random()*.24;
   hit:=greatest(1,round(atk*dice*(CASE WHEN usedmp THEN 1.5 ELSE 1 END) *
        (CASE WHEN random()<crit_p THEN 1.85 ELSE 1 END)-b.defense*.30)::int);
   hit:=least(hit,atk*6,e.hp_now::integer);
 END IF;
 incoming:=greatest(1,round((b.atk*(1+(b.lv-1)*.15))*(.9+random()*.2)-defense_player*.65)::integer);
 newhp:=greatest(0,newhp-incoming);
 IF coalesce(p_auto_potion,false) AND newhp>0 AND newhp<hp_max*.4 THEN
   stock:=coalesce((s->>'potHP')::integer,0);
   IF stock>0 THEN
     newhp:=least(hp_max,newhp+greatest(130,round(hp_max*.55)::integer));
     s:=jsonb_set(s,'{potHP}',to_jsonb(stock-1),true);usedhp:=true;
     UPDATE public.amber_characters SET save_data=s WHERE user_id=u;
   END IF;
 END IF;
 UPDATE public.amber_v28_boss_event SET hp_now=greatest(0,hp_now-hit),
 defeated_at=CASE WHEN hp_now-hit<=0 THEN cd ELSE defeated_at END
 WHERE event_key=ek AND boss_id=p.boss_id;
 UPDATE public.amber_v28_boss_player SET damage=damage+hit,hp=newhp,mp=newmp,last_hit_at=cd
 WHERE event_key=ek AND boss_id=p.boss_id AND user_id=u;
 RETURN (SELECT public.amber_v28_status(ek,p.boss_id)) || jsonb_build_object(
 'ok',true,'hit_damage',hit,'incoming_damage',incoming,'used_skill',usedmp,
 'used_hp_pot',usedhp,'used_mp_pot',false,'my_hp',newhp,'my_mp',newmp,
 'my_damage',p.damage+hit,'boss_hp',greatest(0,e.hp_now-hit),
 'defeated',e.hp_now-hit<=0,'ended',false);
END$$;
CREATE OR REPLACE FUNCTION public.amber_v28_claim(p_event_key text) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO '' AS $$
DECLARE u uuid:=auth.uid();p public.amber_v28_boss_player%rowtype;
 e public.amber_v28_boss_event%rowtype;b public.amber_v28_boss_def%rowtype;
 n integer:=0;note text:='';
BEGIN
 IF u IS NULL THEN RETURN jsonb_build_object('ok',false,'reason','login_required');END IF;
 IF p_event_key IS NULL OR length(p_event_key)>32 THEN RETURN jsonb_build_object('ok',false,'reason','bad_event');END IF;
 SELECT * INTO p FROM public.amber_v28_boss_player WHERE event_key=p_event_key AND user_id=u LIMIT 1;
 IF NOT FOUND THEN RETURN jsonb_build_object('ok',false,'reason','not_joined'); END IF;
 SELECT * INTO e FROM public.amber_v28_boss_event WHERE event_key=p_event_key AND boss_id=p.boss_id FOR UPDATE;
 SELECT * INTO p FROM public.amber_v28_boss_player WHERE event_key=p_event_key AND user_id=u FOR UPDATE;
 SELECT * INTO b FROM public.amber_v28_boss_def WHERE boss_id=p.boss_id;
 IF e.defeated_at IS NULL THEN RETURN jsonb_build_object('ok',false,'reason','boss_not_defeated');END IF;
 IF p.claimed THEN RETURN jsonb_build_object('ok',false,'reason','already_claimed');END IF;
 IF p.damage>=100000 AND random()<b.drop_chance THEN n:=2+floor(random()*2)::integer;END IF;
 UPDATE public.amber_v28_boss_player SET claimed=true,claimed_at=clock_timestamp()
 WHERE event_key=p_event_key AND boss_id=p.boss_id AND user_id=u;
 IF n>0 THEN
   INSERT INTO public.amber_v28_fragment_ledger(user_id,fragment_id,delta,reason,event_key,boss_id)
   VALUES(u,b.fragment_id,n,'boss_drop',p_event_key,p.boss_id);
   INSERT INTO public.amber_v28_fragment_bal(user_id,fragment_id,qty) VALUES(u,b.fragment_id,n)
   ON CONFLICT(user_id,fragment_id) DO UPDATE SET qty=public.amber_v28_fragment_bal.qty+EXCLUDED.qty;
 END IF;
 IF p.damage<100000 THEN note:='ดาเมจไม่ถึง 100,000';
 ELSIF n=0 THEN note:='สุ่มไม่พบเศษบอส'; END IF;
 RETURN jsonb_build_object('ok',true,'event_key',p_event_key,'fragment_id',b.fragment_id,
 'fragment_count',n,'fragments_text',CASE WHEN n>0 THEN b.fragment_name||' ×'||n ELSE '' END,
 'reason_text',note);
END$$;
CREATE OR REPLACE FUNCTION public.amber_v28_leave() RETURNS jsonb LANGUAGE sql STABLE
SET search_path TO '' AS $$SELECT jsonb_build_object('ok',true)$$;
REVOKE ALL ON FUNCTION public.amber_v28_info(),public.amber_v28_fragments(),
public.amber_v28_join(text),public.amber_v28_status(text,text),
public.amber_v28_attack(boolean,boolean),public.amber_v28_claim(text),public.amber_v28_leave()
FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.amber_v28_info(),public.amber_v28_fragments(),
public.amber_v28_join(text),public.amber_v28_status(text,text),
public.amber_v28_attack(boolean,boolean),public.amber_v28_claim(text),public.amber_v28_leave()
TO authenticated;

-- Exchange 30 pieces of every world-boss fragment for exactly one +0 weapon.
-- Added outside the earlier transaction so it can be deployed independently if needed.
CREATE OR REPLACE FUNCTION public.amber_v28_exchange(p_cls text) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO '' AS $$
DECLARE u uuid:=auth.uid(); s jsonb; gear jsonb; item jsonb; options jsonb;
 req record; orig integer; gid text; label text; baseline integer:=9000;
 mainstat text; cfg text; total_missing integer:=0;
BEGIN
 IF u IS NULL THEN RETURN jsonb_build_object('ok',false,'reason','login_required');END IF;
 IF p_cls NOT IN('ดาบ','หมัด','ธนู','จอมเวท') THEN RETURN jsonb_build_object('ok',false,'reason','bad_class');END IF;
 PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended('ultimate:'||u::text,0));
 IF EXISTS(SELECT 1 FROM public.amber_v28_ult_weapon WHERE user_id=u AND cls=p_cls)
 THEN RETURN jsonb_build_object('ok',false,'reason','already_owned');END IF;
 SELECT save_data INTO s FROM public.amber_characters WHERE user_id=u FOR UPDATE;
 IF s IS NULL THEN RETURN jsonb_build_object('ok',false,'reason','character_missing');END IF;
 gear:=coalesce(s->'gear','[]'::jsonb);
 IF jsonb_typeof(gear)<>'array' OR jsonb_array_length(gear)>=200 THEN RETURN jsonb_build_object('ok',false,'reason','bag_full');END IF;
 FOR req IN SELECT d.fragment_id,coalesce(b.qty,0) qty FROM public.amber_v28_boss_def d
 LEFT JOIN public.amber_v28_fragment_bal b ON b.fragment_id=d.fragment_id AND b.user_id=u ORDER BY d.fragment_id LOOP
  IF req.qty<30 THEN total_missing:=total_missing+1;END IF;
 END LOOP;
 IF total_missing>0 THEN RETURN jsonb_build_object('ok',false,'reason','not_enough_fragments');END IF;
 -- All quantities must be rechecked and locked for concurrent exchange attempts.
 FOR req IN SELECT fragment_id,qty FROM public.amber_v28_fragment_bal WHERE user_id=u ORDER BY fragment_id FOR UPDATE LOOP
   IF req.qty<30 THEN RETURN jsonb_build_object('ok',false,'reason','not_enough_fragments');END IF;
 END LOOP;
 IF (SELECT count(*) FROM public.amber_v28_fragment_bal b JOIN public.amber_v28_boss_def d
       ON b.fragment_id=d.fragment_id WHERE b.user_id=u AND b.qty>=30)<>10
 THEN RETURN jsonb_build_object('ok',false,'reason','not_enough_fragments');END IF;
 CASE p_cls
 WHEN 'ดาบ' THEN label:='⚡ ดาบจักรพรรดิอสุนีบาต [ตำนานบอสโลก]';mainstat:='STR';cfg:='ult_sword';
 WHEN 'หมัด' THEN label:='⚡ กรงเล็บมังกรฟ้าผ่า [ตำนานบอสโลก]';mainstat:='STR';cfg:='ult_fist';
 WHEN 'ธนู' THEN label:='⚡ ธนูวชิระพิฆาตสวรรค์ [ตำนานบอสโลก]';mainstat:='DEX';cfg:='ult_bow';
 WHEN 'จอมเวท' THEN label:='⚡ คทาเทพีอัสนีพิภพ [ตำนานบอสโลก]';mainstat:='INT';cfg:='ult_staff';
 END CASE;
 gid:=cfg||'_'||replace(gen_random_uuid()::text,'-','');
 options:=jsonb_build_array(jsonb_build_array('ATK',1650),jsonb_build_array('CRIT',15),jsonb_build_array(mainstat,400),jsonb_build_array('HP',3000));
 item:=jsonb_build_object('id',gid,'slot','W','cls',p_cls,'name',label,
    'rar',3,'lv',100,'req',1,'enh',0,'mythic',true,'bossDrop',true,'ult',true,
    'bound',true,'base',jsonb_build_object('ATK',baseline),'opts',options);
 -- The item is registered in the same authoritative equipment ledger used for combat.
 INSERT INTO private.amber_v285_gear_registry(gear_id,location,holder_user_id,gear_data,provenance)
 VALUES(gid,'inventory',u,item,'server_observed');
 FOR req IN SELECT fragment_id FROM public.amber_v28_boss_def ORDER BY fragment_id LOOP
   UPDATE public.amber_v28_fragment_bal SET qty=qty-30 WHERE user_id=u AND fragment_id=req.fragment_id AND qty>=30;
   IF NOT FOUND THEN RAISE EXCEPTION 'V28_RACE_RETRY';END IF;
   INSERT INTO public.amber_v28_fragment_ledger(user_id,fragment_id,delta,reason,event_key,boss_id)
   VALUES(u,req.fragment_id,-30,'exchange',NULL,NULL);
 END LOOP;
 INSERT INTO public.amber_v28_ult_weapon(user_id,cls,gear_id) VALUES(u,p_cls,gid);
 s:=jsonb_set(s,'{gear}',gear||jsonb_build_array(item),true);
 UPDATE public.amber_characters SET save_data=s WHERE user_id=u;
 RETURN jsonb_build_object('ok',true,'cls',p_cls,'gear',item);
END$$;
REVOKE ALL ON FUNCTION public.amber_v28_exchange(text) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.amber_v28_exchange(text) TO authenticated;
-- 03_COSTUME_SERVER.sql
-- Security fix: V28 cosmetic purchase must not mint cosmetics or subtract gems locally.
CREATE OR REPLACE FUNCTION public.amber_v302_costume(p_action text,p_id text DEFAULT NULL)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO '' AS $$
DECLARE u uuid:=auth.uid();s jsonb; co jsonb; ow jsonb;price integer;required_job text; gem_count bigint;
BEGIN
 IF u IS NULL THEN RETURN jsonb_build_object('ok',false,'reason','login_required');END IF;
 SELECT save_data INTO s FROM public.amber_characters WHERE user_id=u FOR UPDATE;
 IF s IS NULL THEN RETURN jsonb_build_object('ok',false,'reason','character_missing');END IF;
 co:=coalesce(s->'cos28','{"owned":[],"equipped":""}'::jsonb);
 ow:=coalesce(co->'owned','[]'::jsonb);
 IF jsonb_typeof(ow)<>'array' OR jsonb_array_length(ow)>24 THEN RETURN jsonb_build_object('ok',false,'reason','invalid_cosmetics');END IF;
 required_job:=CASE WHEN p_id LIKE 'sw_%' THEN 'ดาบ' WHEN p_id LIKE 'fi_%' THEN 'หมัด'
 WHEN p_id LIKE 'bo_%' THEN 'ธนู' WHEN p_id LIKE 'ma_%' THEN 'จอมเวท' ELSE NULL END;
 price:=CASE p_id
 WHEN 'sw_thunder' THEN 1800 WHEN 'sw_inferno' THEN 2200 WHEN 'sw_holy' THEN 3000
 WHEN 'fi_dragon' THEN 1800 WHEN 'fi_storm' THEN 2200 WHEN 'fi_void' THEN 3000
 WHEN 'bo_wind' THEN 1800 WHEN 'bo_sun' THEN 2200 WHEN 'bo_night' THEN 3000
 WHEN 'ma_arcane' THEN 1800 WHEN 'ma_frost' THEN 2200 WHEN 'ma_star' THEN 3000 ELSE NULL END;
 IF p_action='buy' THEN
  IF price IS NULL THEN RETURN jsonb_build_object('ok',false,'reason','bad_costume');END IF;
  IF ow ? p_id THEN RETURN jsonb_build_object('ok',false,'reason','already_owned');END IF;
  gem_count:=greatest(0,coalesce((s->>'gems')::bigint,0));
  IF gem_count<price THEN RETURN jsonb_build_object('ok',false,'reason','not_enough_gems');END IF;
  ow:=ow||to_jsonb(p_id);co:=jsonb_set(co,'{owned}',ow,true);
  s:=jsonb_set(s,'{gems}',to_jsonb(gem_count-price),true);
 ELSIF p_action='wear' THEN
  IF price IS NULL OR NOT(ow ? p_id) OR s->>'job' IS DISTINCT FROM required_job
  THEN RETURN jsonb_build_object('ok',false,'reason','not_owned_or_wrong_class');END IF;
  co:=jsonb_set(co,'{equipped}',to_jsonb(p_id),true);
 ELSIF p_action='strip' THEN co:=jsonb_set(co,'{equipped}',to_jsonb(''::text),true);
 ELSE RETURN jsonb_build_object('ok',false,'reason','bad_action');END IF;
 s:=jsonb_set(s,'{cos28}',co,true);
 UPDATE public.amber_characters SET save_data=s WHERE user_id=u;
 RETURN jsonb_build_object('ok',true,'save',s,'cos28',co);
END$$;
REVOKE ALL ON FUNCTION public.amber_v302_costume(text,text) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.amber_v302_costume(text,text) TO authenticated;
-- 04_ULT_WEAPON_TRANSFER_GUARD.sql
-- Bind ultimate-weapon ownership at registry level; upgrades remain allowed.
CREATE OR REPLACE FUNCTION private.amber_v302_ult_bound_guard()
RETURNS trigger LANGUAGE plpgsql SET search_path TO '' AS $$
BEGIN
 IF OLD.gear_data->>'ult'='true' OR OLD.gear_data->>'name' LIKE '%[ตำนานบอสโลก]%' THEN
   IF NEW.location IS DISTINCT FROM OLD.location
      OR NEW.holder_user_id IS DISTINCT FROM OLD.holder_user_id
      OR NEW.gear_data->>'id' IS DISTINCT FROM OLD.gear_data->>'id'
      OR NEW.gear_data->>'ult' IS DISTINCT FROM 'true'
   THEN RAISE EXCEPTION 'V302_ULT_BOUND_CANNOT_TRANSFER';END IF;
 END IF;
 RETURN NEW;
END$$;
DROP TRIGGER IF EXISTS amber_v302_ult_bound_on_registry ON private.amber_v285_gear_registry;
CREATE TRIGGER amber_v302_ult_bound_on_registry
BEFORE UPDATE ON private.amber_v285_gear_registry
FOR EACH ROW EXECUTE FUNCTION private.amber_v302_ult_bound_guard();
COMMIT;

-- Run after installation. Results are read-only; do NOT insert fake fragments on production.
SELECT count(*) AS world_boss_types, min(hp_max) AS min_hp,max(hp_max) AS max_hp,
 min(drop_chance) AS min_fragment_chance,max(drop_chance) AS max_fragment_chance
 FROM public.amber_v28_boss_def;
SELECT tablename,rowsecurity FROM pg_tables
 WHERE schemaname='public' AND tablename LIKE 'amber_v28_%' ORDER BY tablename;
SELECT routine_name FROM information_schema.routines
 WHERE routine_schema='public' AND routine_name LIKE 'amber_v28_%' ORDER BY routine_name;
SELECT has_table_privilege('authenticated','public.amber_v28_fragment_bal','SELECT') AS fragment_table_direct_read,
 has_table_privilege('authenticated','public.amber_v28_fragment_bal','UPDATE') AS fragment_table_direct_write;
SELECT count(*) AS ultimate_weapons_granted FROM public.amber_v28_ult_weapon;
