-- Bind ultimate-weapon ownership at registry level; upgrades remain allowed.
BEGIN;
CREATE OR REPLACE FUNCTION private.amber_v302_ult_bound_guard()
RETURNS trigger LANGUAGE plpgsql SET search_path TO '' AS $$
BEGIN
 IF OLD.gear_data->>'ult'='true' OR OLD.gear_data->>'name' LIKE '%[ตำนานบอสโลก]%' THEN
   IF NEW.location IS DISTINCT FROM OLD.location
      OR NEW.holder_user_id IS DISTINCT FROM OLD.holder_user_id
      OR NEW.gear_data->>'id' IS DISTINCT FROM OLD.gear_data->>'id'
      OR NEW.gear_data->>'ult' IS DISTINCT FROM 'true'
   THEN RAISE EXCEPTION 'V302_ULT_BOUND_CANNOT_TRANSFER';END IF;
 END IF;
 RETURN NEW;
END$$;
DROP TRIGGER IF EXISTS amber_v302_ult_bound_on_registry ON private.amber_v285_gear_registry;
CREATE TRIGGER amber_v302_ult_bound_on_registry
BEFORE UPDATE ON private.amber_v285_gear_registry
FOR EACH ROW EXECUTE FUNCTION private.amber_v302_ult_bound_guard();
COMMIT;
