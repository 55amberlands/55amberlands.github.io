-- Security fix: V28 cosmetic purchase must not mint cosmetics or subtract gems locally.
BEGIN;
CREATE OR REPLACE FUNCTION public.amber_v302_costume(p_action text,p_id text DEFAULT NULL)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO '' AS $$
DECLARE u uuid:=auth.uid();s jsonb; co jsonb; ow jsonb;price integer;required_job text; gem_count bigint;
BEGIN
 IF u IS NULL THEN RETURN jsonb_build_object('ok',false,'reason','login_required');END IF;
 SELECT save_data INTO s FROM public.amber_characters WHERE user_id=u FOR UPDATE;
 IF s IS NULL THEN RETURN jsonb_build_object('ok',false,'reason','character_missing');END IF;
 co:=coalesce(s->'cos28','{"owned":[],"equipped":""}'::jsonb);
 ow:=coalesce(co->'owned','[]'::jsonb);
 IF jsonb_typeof(ow)<>'array' OR jsonb_array_length(ow)>24 THEN RETURN jsonb_build_object('ok',false,'reason','invalid_cosmetics');END IF;
 required_job:=CASE WHEN p_id LIKE 'sw_%' THEN 'ดาบ' WHEN p_id LIKE 'fi_%' THEN 'หมัด'
 WHEN p_id LIKE 'bo_%' THEN 'ธนู' WHEN p_id LIKE 'ma_%' THEN 'จอมเวท' ELSE NULL END;
 price:=CASE p_id
 WHEN 'sw_thunder' THEN 1800 WHEN 'sw_inferno' THEN 2200 WHEN 'sw_holy' THEN 3000
 WHEN 'fi_dragon' THEN 1800 WHEN 'fi_storm' THEN 2200 WHEN 'fi_void' THEN 3000
 WHEN 'bo_wind' THEN 1800 WHEN 'bo_sun' THEN 2200 WHEN 'bo_night' THEN 3000
 WHEN 'ma_arcane' THEN 1800 WHEN 'ma_frost' THEN 2200 WHEN 'ma_star' THEN 3000 ELSE NULL END;
 IF p_action='buy' THEN
  IF price IS NULL THEN RETURN jsonb_build_object('ok',false,'reason','bad_costume');END IF;
  IF ow ? p_id THEN RETURN jsonb_build_object('ok',false,'reason','already_owned');END IF;
  gem_count:=greatest(0,coalesce((s->>'gems')::bigint,0));
  IF gem_count<price THEN RETURN jsonb_build_object('ok',false,'reason','not_enough_gems');END IF;
  ow:=ow||to_jsonb(p_id);co:=jsonb_set(co,'{owned}',ow,true);
  s:=jsonb_set(s,'{gems}',to_jsonb(gem_count-price),true);
 ELSIF p_action='wear' THEN
  IF price IS NULL OR NOT(ow ? p_id) OR s->>'job' IS DISTINCT FROM required_job
  THEN RETURN jsonb_build_object('ok',false,'reason','not_owned_or_wrong_class');END IF;
  co:=jsonb_set(co,'{equipped}',to_jsonb(p_id),true);
 ELSIF p_action='strip' THEN co:=jsonb_set(co,'{equipped}',to_jsonb(''::text),true);
 ELSE RETURN jsonb_build_object('ok',false,'reason','bad_action');END IF;
 s:=jsonb_set(s,'{cos28}',co,true);
 UPDATE public.amber_characters SET save_data=s WHERE user_id=u;
 RETURN jsonb_build_object('ok',true,'save',s,'cos28',co);
END$$;
REVOKE ALL ON FUNCTION public.amber_v302_costume(text,text) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.amber_v302_costume(text,text) TO authenticated;
COMMIT;
