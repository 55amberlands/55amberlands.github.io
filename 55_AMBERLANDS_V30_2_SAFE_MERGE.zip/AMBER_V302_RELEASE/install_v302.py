#!/usr/bin/env python3
from pathlib import Path
import re,shutil,sys,subprocess
root=Path(__file__).resolve().parent.parent.parent if False else Path.cwd()
script_dir=Path(__file__).resolve().parent
payload=script_dir/'payload'
required=['index.html','v24_px_weapons.js','v26_realtime.js','online_bridge.js','v300_authoritative_vitals_ui.js','tools/export_pages.py']
if not all((root/f).is_file() for f in required):sys.exit('ERROR: Run in live repo root with V30.1 files')
if not (root/'online_bridge.js').read_text().count('async function hideOverlay()'):
    sys.exit('ERROR: V30.1 login gate not installed. Refusing to overwrite older build.')
marker='v302_crit_anchor.js?v=302'
srcidx=(root/'index.html').read_text()
if marker in srcidx:
    print('V30.2 already installed; no duplicate scripts.');sys.exit(0)
ex=(root/'tools/export_pages.py').read_text()
if ex.count("file.suffix in {'.html','.js','.css'}")!=1 or ex.count("if (root/'assets').is_dir():")!=1:
    sys.exit('ERROR: GitHub Pages export script changed; cannot add PWA icons safely')
ex=ex.replace("file.suffix in {'.html','.js','.css'}", "file.suffix in {'.html','.js','.css','.webmanifest'}")
ex=ex.replace("if (root/'assets').is_dir():", "if (root/'icons').is_dir(): shutil.copytree(root/'icons',out/'icons')\nif (root/'assets').is_dir():")
wp=(root/'v24_px_weapons.js').read_text()
vp=(root/'v26_realtime.js').read_text()
# Base changes are narrow and guarded; a mismatch must fail before touching files.
checks=[(wp,'function build(spec) {',1),(wp,'function fx(dst, spec, x, y, ang, t, sc = 1) {',1),
(vp,'async function openArena(practice) {',1),
(vp,'window.AMBER_V273',11),(vp,'serverMode: real, server:',1),
(vp,'boss: pickBoss()',1),(vp,'const joined = await window.AMBER_V273.join();',1),
(srcidx,'v300_authoritative_vitals_ui.js',1),
(srcidx,'</body>',1)]
for text,key,n in checks:
 if text.count(key)!=n: sys.exit('ERROR: incompatible live version, expected '+str(n)+' occurrences of '+key+', got '+str(text.count(key)))
wp=wp.replace('function build(spec) {','function build(spec) {\n  if (spec.ult && PX.ultWeapons) return PX.ultWeapons.build(spec);',1)
wp=wp.replace('function fx(dst, spec, x, y, ang, t, sc = 1) {',
  'function fx(dst, spec, x, y, ang, t, sc = 1) {\n  if (spec.ult && PX.ultWeapons?.fx) return PX.ultWeapons.fx(dst, spec, x, y, ang, t, sc);',1)
# The V28 arena adapter only reroutes server RPC calls for the new boss-select entry.
picker='''function pickBossId(id) {
 try { const b=PX.worldBosses.get(id);if(b) return {name:b.name,lv:b.lv,boss:true,map:'worldboss',scene:b.scene,
 wb28:b.id,col:b.col,element:b.element,title:b.title,hp28:b.hp,atk28:b.atk}; }
 catch(e) {console.warn('[V302 boss asset]',e)}return pickBoss();
}
'''
i=vp.index('function myRow()')
vp=vp[:i]+picker+vp[i:]
vp=vp.replace('async function openArena(practice) {','const API=()=>ARENA.api || window.AMBER_V273;\nasync function openArena(practice,opt) {\n  opt=opt||{};',1)
vp=vp.replace('if (real && !window.AMBER_V273?.ready?.())','if (real && !(opt.api || window.AMBER_V273)?.ready?.())',1)
vp=vp.replace('serverMode: real, server:', 'api:opt.api||null, serverMode: real, server:',1)
vp=vp.replace('boss: pickBoss()', 'boss: (opt.bossId ? pickBossId(opt.bossId):pickBoss())',1)
vp=vp.replace('const joined = await window.AMBER_V273.join();','const joined = await (opt.api || window.AMBER_V273).join(opt.bossId);',1)
# Remaining arena calls use API(), but fallback still points to V27.3 for the old world boss.
# World-boss V28 rewards are fragments, not the legacy V273 gold/ore reward object.
legacy_claim='if (result?.ok === true) {\n        v.wb.claimed = event;'
if vp.count(legacy_claim)!=1:sys.exit('ERROR: expected legacy claim branch exactly once')
vp=vp.replace(legacy_claim, '''if (ARENA.api && result?.ok === true) {
        rewardTxt='✅ Supabase ยืนยันรางวัล'+(result.fragments_text ? ' · '+String(result.fragments_text) : (result.reason_text ? ' · '+String(result.reason_text) : ''));
        window.AMBER_V28S?.refreshFragments?.();
      } else if (result?.ok === true) {
        v.wb.claimed = event;''',1)
vp=vp.replace('window.AMBER_V273', 'API()')
# Undo any rewrites in API declaration and the API0 selection itself.
vp=vp.replace('const API=()=>ARENA.api || API();','const API=()=>ARENA.api || window.AMBER_V273;')
vp=vp.replace('(opt.api || API())','(opt.api || window.AMBER_V273)')
vp=vp.replace('(opt.api || API()).join', '(opt.api || window.AMBER_V273).join')
# It is crucial that V28 join/attack/claim get the opted API, while old fights retain V273.
if 'const API=()=>ARENA.api || window.AMBER_V273;' not in vp or 'pickBossId(opt.bossId)' not in vp:
    sys.exit('ERROR: API patch did not validate')
# Append new assets AFTER existing V30.0 to preserve authoritative patch ordering.
tags='''\n<!-- 55 AMBERLANDS V30.2: additive V28 visual assets + server-backed world bosses -->
<script src="./v28_px_icons.js?v=302"></script>
<script src="./v28_px_worldbosses.js?v=302"></script>
<script src="./v28_skill_vfx.js?v=302"></script>
<script src="./v28_battle_hud.js?v=302"></script>
<script src="./v28_bag_costumes.js?v=302_server_cosmetics"></script>
<script src="./v28_ult_weapons.js?v=302_plus10_only"></script>
<script src="./v28_boss_book.js?v=302"></script>
<script src="./v302_crit_anchor.js?v=302"></script>
'''
srcidx=srcidx.replace('</body>',tags+'</body>',1)
if 'rel="manifest"' not in srcidx:srcidx=srcidx.replace('</head>','<link rel="manifest" href="./manifest.webmanifest?v=302"></head>',1)
# Do not install sw.js; it would persist old HTML/JS across versions.
backup=root/'.amber_v302_backups'
backup.mkdir(exist_ok=True)
for p in ['index.html','v24_px_weapons.js','v26_realtime.js','tools/export_pages.py']:
 b=backup/p
 b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():shutil.copy2(root/p,b)
for p in payload.iterdir():
 if p.is_file():shutil.copy2(p,root/p.name)
for p in ['manifest.webmanifest']:
 shutil.copy2(script_dir/p,root/p)
(root/'icons').mkdir(exist_ok=True)
for p in (script_dir/'icons').glob('*'):
 if p.is_file():shutil.copy2(p,root/'icons'/p.name)
(root/'index.html').write_text(srcidx)
(root/'v24_px_weapons.js').write_text(wp)
(root/'v26_realtime.js').write_text(vp)
(root/'tools/export_pages.py').write_text(ex)
print('V30.2 patches installed to working tree; original files backed up.')
print('SQL still requires applying 01 -> 02 -> 03 in Supabase SQL Editor before world-boss reward/exchange works.')
