55 AMBERLANDS V30.2 — SAFE MERGE OF V28 + V30.1 (26 October 2026)

IMPORTANT: Do not upload the original AMBERLANDS_V28_PATCH.zip as a deploy over current V30.1.
This archive installs ONLY newly compatible assets and patches the live V30.1 source.
SQL อยู่ใน ZIP แต่ยังไม่ถูกรันบน Production โดยอัตโนมัติ (ต้องเปิด SQL Editor เพื่อใช้สิทธิ์เจ้าของฐานข้อมูล).

1. ตั้งค่า Supabase โปรเจกต์ 55-amberlands (rfijdwnzuhvlkfptyoiy)
   Supabase Dashboard > SQL Editor > New query
   เปิดไฟล์ sql/00_ALL_IN_ONE.sql คัดลอกทั้งหมดแล้วกด Run ครั้งเดียว
   มีระบบบอสโลก 10 ตัว HP/ATK/DEF, เศษ/รางวัล/คูลดาวน์/กันรับซ้ำ, แลกอาวุธ +0, และชุดคอสตูมที่ตรวจจากเซิร์ฟเวอร์
   หาก SQL ไม่สำเร็จ ห้าม Deploy client หรือส่งคำสั่งซ้ำจนทราบ error
   ตรวจสอบด้วยไฟล์ sql/05_VERIFY_READ_ONLY.sql อีกครั้ง

2. Upload this ZIP through GitHub Add file -> Upload files at repo root (ZIP as file).
Recommended one-line command in GitHub Codespaces Terminal:
cd "$(git rev-parse --show-toplevel)" && git switch main && git pull --ff-only origin main && unzip -oq 55_AMBERLANDS_V30_2_SAFE_MERGE.zip -d .git/amber_v302 && bash .git/amber_v302/AMBER_V302_RELEASE/deploy_v302.sh

Note: Installer deliberately refuses to overwrite uncommitted tracked files.

NOTES:
- World-boss weapon exchange creates an unenhanced +0 item in the server registry. +10 lightning only after actual enhancement.
- Server RPC owns boss HP, boss DEF, boss ATK, player stats/equipped items, cooldown, drops, 10 fragment ledgers, claims and exchanges.
- V28 costumes: buy/equip must use server RPC (no client-minted coins or cosmetics).
- Smaller critical hits next to monsters, hidden behind inventory modal.
- Existing V30.1 online Bridge, saves, older boss/dungeon/market/players are not reset.
- Intentionally does NOT install sw.js because cached HTML caused stale game flashes. GitHub Pages export includes manifest.webmanifest + icons.
- This is a TEST/BETA patch. Real gameplay still requires authenticated player acceptance tests; do not claim anti-cheat is perfect.
