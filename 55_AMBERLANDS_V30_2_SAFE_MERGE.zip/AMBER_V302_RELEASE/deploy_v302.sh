#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
if [[ -n "$(git status --porcelain --untracked-files=no)" ]]; then
  echo 'STOP: มีการแก้ไฟล์ที่ยังไม่ Commit กรุณาบันทึกงานก่อน ไม่ฝืนเขียนทับ' >&2
  exit 1
fi
python3 .git/amber_v302/AMBER_V302_RELEASE/install_v302.py
python3 tools/check_static_site.py
for f in v28_*.js v302_crit_anchor.js v24_px_weapons.js v26_realtime.js; do
  node --check "$f"
done
git add index.html tools/export_pages.py v24_px_weapons.js v26_realtime.js v28_*.js v302_crit_anchor.js manifest.webmanifest icons
git diff --cached --check
if git diff --cached --quiet; then
  echo 'ไม่มีการแก้ไขใหม่ (ติดตั้ง V30.2 แล้ว)'
else
  git commit -m 'V30.2 safe V28 assets and server world boss integration'
  git push origin main
fi
echo '✅ Push สำเร็จ ตรวจ Deploy ที่ GitHub Actions'
