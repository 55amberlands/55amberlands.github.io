-- 55 AMBERLANDS V30.8 - ONE ACCOUNT, FIVE BOUND TEST PIECES (+10)
-- RUN ONLY inside the project's Supabase SQL Editor under a privileged administrator.
-- NOT an RPC; NEVER ship this SQL inside game JavaScript.
-- Exact target: character_name = 'Hareko'. Does not overwrite equipped slots.
-- Idempotent stable IDs: rerunning does not create more items.
-- All entries stored in BOTH save_data.gear and the private server equipment registry.
-- The 'ult':true and 'bound':true flags use V30.2 registry anti-transfer guard.
-- This is a TEST grant, not a normal boss drop and NOT a change to live drop probabilities.
BEGIN;
DO $v308$
DECLARE
  target_user uuid;
  saved jsonb;
  stock jsonb;
  entries jsonb;
  entry jsonb;
  eid text;
  ledger record;
BEGIN
  IF (SELECT count(*) FROM public.amber_characters WHERE character_name='Hareko')<>1 THEN
    RAISE EXCEPTION 'V308_TEST_HAREKO_UNIQUE_CHARACTER_REQUIRED';
  END IF;
  SELECT user_id,save_data INTO target_user,saved
  FROM public.amber_characters WHERE character_name='Hareko' FOR UPDATE;
  IF target_user IS NULL THEN RAISE EXCEPTION 'V308_TEST_HAREKO_NOT_FOUND';END IF;
  stock:=COALESCE(saved->'gear','[]'::jsonb);
  IF pg_catalog.jsonb_typeof(stock)<>'array' OR pg_catalog.jsonb_array_length(stock)>185
  THEN RAISE EXCEPTION 'V308_TEST_INVENTORY_LIMIT';END IF;
  entries:=pg_catalog.jsonb_build_array(
   pg_catalog.jsonb_build_object('id','v308test_hareko_fist10','slot','W','cls','หมัด','lv',80,'req',1,'rar',3,'enh',10,'name','🌈 หมัดบอสมังกรเพลิง [ทดลอง +10]','base',pg_catalog.jsonb_build_object('ATK',1000),'opts',pg_catalog.jsonb_build_array(pg_catalog.jsonb_build_array('STR',120),pg_catalog.jsonb_build_array('CRIT',6)),'boss',true,'bossDrop',true,'mythic',true,'ult',true,'bound',true,'admin_test',true),
   pg_catalog.jsonb_build_object('id','v308test_hareko_armor10','slot','S','cls','หมัด','lv',80,'req',1,'rar',3,'enh',10,'name','🌈 เสื้อบอสมังกรเพลิง [ทดลอง +10]','base',pg_catalog.jsonb_build_object('DEF',250,'HP',1100),'opts',pg_catalog.jsonb_build_array(pg_catalog.jsonb_build_array('VIT',70)),'boss',true,'bossDrop',true,'mythic',true,'ult',true,'bound',true,'admin_test',true),
   pg_catalog.jsonb_build_object('id','v308test_hareko_gloves10','slot','G','cls','หมัด','lv',80,'req',1,'rar',3,'enh',10,'name','🌈 ถุงมือบอสมังกรเพลิง [ทดลอง +10]','base',pg_catalog.jsonb_build_object('ATK',250,'DEF',85),'opts',pg_catalog.jsonb_build_array(pg_catalog.jsonb_build_array('STR',60)),'boss',true,'bossDrop',true,'mythic',true,'ult',true,'bound',true,'admin_test',true),
   pg_catalog.jsonb_build_object('id','v308test_hareko_boots10','slot','B','cls','หมัด','lv',80,'req',1,'rar',3,'enh',10,'name','🌈 รองเท้าบอสมังกรเพลิง [ทดลอง +10]','base',pg_catalog.jsonb_build_object('DEF',150,'AGI',45),'opts',pg_catalog.jsonb_build_array(pg_catalog.jsonb_build_array('DEX',65)),'boss',true,'bossDrop',true,'mythic',true,'ult',true,'bound',true,'admin_test',true),
   pg_catalog.jsonb_build_object('id','v308test_hareko_ring10','slot','R','cls',NULL,'lv',80,'req',1,'rar',3,'enh',10,'name','🌈 แหวนบอสมังกรเพลิง [ทดลอง +10]','base',pg_catalog.jsonb_build_object('HP',1500,'MP',500),'opts',pg_catalog.jsonb_build_array(pg_catalog.jsonb_build_array('CRIT',4)),'boss',true,'bossDrop',true,'mythic',true,'ult',true,'bound',true,'admin_test',true)
  );
  FOR entry IN SELECT value FROM pg_catalog.jsonb_array_elements(entries) LOOP
    eid:=entry->>'id';
    SELECT holder_user_id,location,gear_data INTO ledger
    FROM private.amber_v285_gear_registry WHERE gear_id=eid;
    IF FOUND THEN
      IF ledger.holder_user_id IS DISTINCT FROM target_user OR ledger.location<>'inventory' OR ledger.gear_data IS DISTINCT FROM entry
      THEN RAISE EXCEPTION 'V308_TEST_ID_CONFLICT_%',eid;END IF;
    ELSE
      INSERT INTO private.amber_v285_gear_registry(gear_id,location,holder_user_id,gear_data,provenance)
      VALUES(eid,'inventory',target_user,entry,'server_observed');
    END IF;
    IF NOT EXISTS(SELECT 1 FROM pg_catalog.jsonb_array_elements(stock) AS old(value) WHERE old.value->>'id'=eid) THEN
      stock:=stock||pg_catalog.jsonb_build_array(entry);
    END IF;
  END LOOP;
  UPDATE public.amber_characters SET save_data=pg_catalog.jsonb_set(saved,'{gear}',stock,true),updated_at=clock_timestamp()
  WHERE user_id=target_user;
END
$v308$;
-- Audit before COMMIT in one SQL Editor execution; statements fail together if any check fails.
SELECT gear_id,gear_data->>'name' AS name,gear_data->>'enh' AS enhancement,location,provenance
FROM private.amber_v285_gear_registry WHERE gear_id LIKE 'v308test_hareko_%' ORDER BY gear_id;
COMMIT;
