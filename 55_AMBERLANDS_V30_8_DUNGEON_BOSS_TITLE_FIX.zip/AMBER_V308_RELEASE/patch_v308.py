#!/usr/bin/env python3
"""55 AMBERLANDS V30.8 - preserve dungeon scene DOM, safe attack fallback, boss/titles panel."""
from pathlib import Path
import sys, shutil, re
r=Path.cwd()
files={n:r/n for n in ['index.html','v23_dungeon.js','v25_systems.js']}
missing=[n for n,p in files.items() if not p.is_file()]
if missing:sys.exit('STOP: repository root missing '+','.join(missing))
src={n:p.read_text('utf-8') for n,p in files.items()}
if 'v308_live_fix.js?v=308a' in src['index.html']:
    print('PASS: V30.8 already installed.');sys.exit(0)
if 'v307_scene_skill_cleanup.js' not in src['index.html']:
    sys.exit('STOP: install V30.7.1 first. No files changed.')
# Dungeon: stop rebuilding the actor sprites on every boss tick (which causes old art/title flicker).
s=src['v23_dungeon.js']
old="sp.innerHTML=live.map((p,i)=>`<div class=\"sprite amber24-dg-hero ${p.user_id===uid()?'amber24-dg-self':''}\" style=\"--order:${i}\"><img src=\"${esc(heroImg(p))}\" alt=\"${esc(p.name)}\"><small>${p.user_id===room.owner_id?'👑 ':''}${esc(p.name||'ผู้เล่น')}</small>${waiting?`<span class=\"amber24-ready ${p.ready?'yes':'no'}\">${p.ready?'✓ พร้อม':'รอพร้อม'}</span>`:''}</div>`).join('');"
if s.count(old)!=1:sys.exit('STOP: dungeon sprite source differs; no changes made (found '+str(s.count(old))+')')
new="""// V30.8: keep existing live character DOM through HP/status polling.
 // Old code rebuilt every player image each time, producing ghost art and title flashing.
 const dgKey=live.map(p=>[p.user_id,p.name||'',p.ready?'1':'0',room.owner_id===p.user_id?'1':'0',waiting?'1':'0'].join('|')).join(';');
 if(sp.dataset.amber308DgKey!==dgKey||sp.querySelectorAll(':scope > .amber24-dg-hero').length!==live.length){
  sp.innerHTML=live.map((p,i)=>`<div class="sprite amber24-dg-hero ${p.user_id===uid()?'amber24-dg-self':''}" style="--order:${i}"><img src="${esc(heroImg(p))}" alt="${esc(p.name)}"><small>${p.user_id===room.owner_id?'👑 ':''}${esc(p.name||'ผู้เล่น')}</small>${waiting?`<span class="amber24-ready ${p.ready?'yes':'no'}">${p.ready?'✓ พร้อม':'รอพร้อม'}</span>`:''}</div>`).join('');
  sp.dataset.amber308DgKey=dgKey;
 }"""
s=s.replace(old,new)
# Client skill availability matches authoritative V276 table: skills _2 and _5 are team buffs.
needle="function skills(){return SKILLS.filter(s=>!s.buff&&state.learned?.includes(s.id)&&state.mp>=s.mp)}"
replacement="function skills(){return SKILLS.filter(s=>!s.buff&&!/_(?:2|5)$/.test(String(s.id))&&state.learned?.includes(s.id)&&state.mp>=s.mp)}"
if s.count(needle)!=1:sys.exit('STOP: dungeon learned-skill filter changed; no files changed')
s=s.replace(needle,replacement)
# If a server refuses a skill, it must NEVER freeze the entire boss encounter.
old_attack="""    }else throw e}
  }
  if(!enhancedRpc)out=await rpc('attack',{p_room:id});"""
new_attack="""    }else if(sk&&/V287_DG_SKILL_NOT_LEARNED|V287_DG_SKILL_INVALID|V287_DG_SKILL_NOT_ALLOWED/i.test(String(e.message||e))){
      // The server rejected this skill; repeat ONCE with a regular server-side attack.
      // Do not grant damage on the client or suppress any other server error.
      out=await rpc('attack_v24',{p_room:id,p_skill:null});
      if(Date.now()-(window.AMBER_V308_LAST_INVALID_SKILL_NOTICE||0)>20000){
        window.AMBER_V308_LAST_INVALID_SKILL_NOTICE=Date.now();
        announce('⚠️ สกิลนี้ใช้กับบอสไม่ได้ เปลี่ยนเป็นโจมตีธรรมดาโดยเซิร์ฟเวอร์');
      }
    }else throw e}
  }
  if(!enhancedRpc)out=await rpc('attack',{p_room:id});"""
if s.count(old_attack)!=1:sys.exit('STOP: dungeon attack source changed; no files changed')
s=s.replace(old_attack,new_attack)
# A null/incomplete server payload must be visible to player; no fake damage.
s=s.replace("  if(!out||!out.room)return;","  if(!out||!out.room){announce('⚠️ เซิร์ฟเวอร์ไม่ส่งสถานะ HP บอสกลับมา กรุณาลองใหม่');return;}")
# Do not repeatedly re-render on harmless every-second heartbeat; preserve normal game logic.
assert 'dgKey=live.map' in s and 'out=await rpc(\'attack_v24\',{p_room:id,p_skill:null})' in s
# In V25, keep the server-owned boss hub; V30.8 adds a separate compact dashboard, not old fixed overlay.
index=src['index.html']
anchor='<script src="./v307_scene_skill_cleanup.js?v=307_source_truth_1"></script>'
if index.count(anchor)!=1:sys.exit('STOP: V307 script anchor mismatch; no files changed')
index=index.replace(anchor,anchor+'\n<script src="./v308_live_fix.js?v=308a"></script>')
addon=(Path(__file__).resolve().parent/'v308_live_fix.js').read_text('utf-8')
assert 'AMBER_V308_LIVE_FIX' in addon
out={'index.html':index,'v23_dungeon.js':s,'v308_live_fix.js':addon}
backup=r/'.git'/'amber-v308-backups'
backup.mkdir(parents=True,exist_ok=True)
for name in ['index.html','v23_dungeon.js']:
    p=r/name;b=backup/name
    if not b.exists():shutil.copy2(p,b)
for name,body in out.items():
    (r/name).write_text(body,'utf-8')
print('PASS: installed V30.8 dungeon HP flow, persistent sprite scene, server-verified +10 title and boss announcements')
print('PASS: untouched Supabase schema, combat/damage calculations, wallets, drops and player inventories')
