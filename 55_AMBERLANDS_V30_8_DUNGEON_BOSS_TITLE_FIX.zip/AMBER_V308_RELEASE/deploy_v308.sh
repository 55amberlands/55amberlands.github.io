#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
if [[ "$(git branch --show-current)" != main ]]; then echo 'STOP: switch to main';exit 1;fi
if [[ -n "$(git status --porcelain | grep -v '?? 55_AMBERLANDS_V30_8_.*.zip' || true)" ]];then echo 'STOP: other uncommitted files. Commit/stash first.';exit 1;fi
python3 "$(dirname "${BASH_SOURCE[0]}")/patch_v308.py"
node --check v23_dungeon.js
node --check v308_live_fix.js
git diff --check
git add index.html v23_dungeon.js v308_live_fix.js
if git diff --cached --quiet;then echo 'PASS: V30.8 already installed';exit 0;fi
git commit -m 'V30.8 dungeon real damage fallback, steady sprites and unified boss announcements'
git push origin main
echo 'PASS: V30.8 pushed; check GitHub Pages Actions before playing'
