/* V30.7 visual-only patch. Does not modify combat or Supabase. */
(()=>{'use strict';if(window.AMBER_V307)return;window.AMBER_V307=true;
const style=document.createElement('style');style.id='amber-v307-scene-skill';style.textContent=`
#skills .amber-skill-hits{display:none!important}
#skills.skills>button{height:auto!important;min-height:88px!important;max-height:128px!important;align-self:stretch!important;justify-content:center!important}
#skills.skills>button>small:not(.amber14-buff-tag){display:-webkit-box!important;-webkit-line-clamp:2!important;-webkit-box-orient:vertical!important;overflow:hidden!important;line-height:1.25!important}
#scene,#scene .partySprites,#scene #sprites,#scene .sprite{background-color:transparent!important;background-image:none!important}
#scene .sprite{box-shadow:none!important;border:0!important;outline:0!important;isolation:isolate}
#scene .sprite:before,#scene .sprite:after{background:transparent!important;box-shadow:none!important}
#scene #px24Scene{position:absolute!important;inset:0!important;width:100%!important;height:100%!important;object-fit:cover!important;object-position:center center!important;max-width:none!important;pointer-events:none!important}
#scene{background-size:cover!important;background-position:center!important;background-repeat:no-repeat!important;isolation:isolate}
#scene .px25-plate,#scene .px26-t{pointer-events:none!important}
@media(max-width:700px){#scene .sprite{max-width:90px!important}#skills.skills{grid-template-columns:repeat(2,minmax(0,1fr))!important}#skills.skills>button{min-height:92px!important;max-height:118px!important;gap:3px!important}}
`;document.head.appendChild(style);
function clean(){const host=document.getElementById('skills');if(!host)return;host.querySelectorAll('.amber-skill-hits').forEach(e=>e.remove());for(const b of host.querySelectorAll(':scope > button')){const buffs=b.querySelectorAll(':scope > .amber14-buff-tag');buffs.forEach((e,j)=>{if(j)e.remove()});}}
let scheduled=false;const obs=new MutationObserver(ms=>{if(!ms.some(m=>m.addedNodes.length))return;if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;clean()})});
const start=()=>{const host=document.getElementById('skills');if(!host)return;clean();obs.observe(host,{childList:true,subtree:true})};if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
