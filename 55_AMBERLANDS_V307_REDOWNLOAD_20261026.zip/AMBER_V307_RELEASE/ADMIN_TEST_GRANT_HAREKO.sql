-- Admin-only TEST grant for Hareko. Do not expose to browser or public RPC.
-- Intended to add 100 to each known material and each of 10 existing boss-fragment balances.
-- IMPORTANT: run only after reviewing the target character, schema and server-side grant/audit policy.
BEGIN;
UPDATE public.amber_characters
SET save_data = jsonb_set(save_data,'{mats}',
 jsonb_set(jsonb_set(coalesce(save_data->'mats','{}'::jsonb),'{gw}',
  to_jsonb(coalesce((save_data->'mats'->>'gw')::int,0)+100),true),'{ga}',
  to_jsonb(coalesce((save_data->'mats'->>'ga')::int,0)+100),true) ||
  jsonb_build_object('ore_prism',coalesce((save_data->'mats'->>'ore_prism')::int,0)+100),true),
 updated_at=now()
WHERE user_id='d212a61b-e505-4103-9771-eb7548bb8548'::uuid AND character_name='Hareko';
UPDATE public.amber_v28_fragment_bal
SET qty=qty+100
WHERE user_id='d212a61b-e505-4103-9771-eb7548bb8548'::uuid
  AND fragment_id IN ('frag_cerberus','frag_empress','frag_leviathan','frag_lich','frag_magma','frag_phoenix','frag_prism','frag_seraph','frag_solar','frag_titan');
-- REVIEW RESULTS BEFORE COMMIT:
SELECT character_name,save_data->'mats' AS materials FROM public.amber_characters
 WHERE user_id='d212a61b-e505-4103-9771-eb7548bb8548'::uuid;
SELECT fragment_id,qty FROM public.amber_v28_fragment_bal
 WHERE user_id='d212a61b-e505-4103-9771-eb7548bb8548'::uuid ORDER BY fragment_id;
-- Replace ROLLBACK with COMMIT only after checking the results and grant audit.
ROLLBACK;
