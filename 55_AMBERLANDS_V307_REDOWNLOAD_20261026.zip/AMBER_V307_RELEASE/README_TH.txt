55 AMBERLANDS V30.7: Visual patch on top of V30.6.
- Remove hit count labels in skill cards (does not alter actual hit count).
- Stabilize scene and card layout. Remove legacy sprite backgrounds.
- Does not update Supabase or award items.
- Backup index.html.v307bak and v12_patch.js.v307bak locally.

INSTALL:
1. Upload ZIP to repository root, Commit.
2. Run:
cd "$(git rev-parse --show-toplevel)" && git pull --ff-only origin main && unzip -oq 55_AMBERLANDS_V30_7_SCENE_SKILL_FIX.zip -d .git/amber_v307 && bash .git/amber_v307/AMBER_V307_RELEASE/deploy_v307.sh
