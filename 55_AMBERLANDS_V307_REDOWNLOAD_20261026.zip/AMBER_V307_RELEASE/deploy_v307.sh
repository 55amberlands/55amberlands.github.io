#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
python3 .git/amber_v307/AMBER_V307_RELEASE/install_v307.py
node --check v307_scene_skill_fix.js
node --check v12_patch.js
git add index.html v12_patch.js v307_scene_skill_fix.js
git diff --cached --check
git commit -m 'V30.7 remove repeated hit UI and stabilize scene geometry'
git push origin main
