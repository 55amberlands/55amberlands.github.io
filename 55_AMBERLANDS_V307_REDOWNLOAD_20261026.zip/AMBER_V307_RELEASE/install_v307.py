from pathlib import Path
import subprocess,sys,shutil
root=Path.cwd()
for f in ('index.html','v12_patch.js','v14_skill_fx.js','v306_responsive_layout.js'):
 if not (root/f).is_file():sys.exit('STOP missing '+f)
a=(root/'v12_patch.js').read_text();i=(root/'index.html').read_text();b=(root/'v14_skill_fx.js').read_text()
if 'v307_scene_skill_fix.js?v=307' in i:sys.exit('V30.7 already installed')
old="const value='×'+sk.hits+' ฮิต';if(hint.textContent!==value)hint.textContent=value;"
if a.count(old)!=1:sys.exit('STOP: V30.6 skill source mismatch; nothing changed')
a=a.replace(old,"hint.remove(); // V30.7: hits are combat metadata, not repeated UI labels",1)
# Avoid extra per-render skill-card metadata. V14 buff tag remains for actual buffs.
old='</body></html>'
if i.count(old)!=1:sys.exit('STOP: unexpected HTML footer')
i=i.replace(old,'<script src="./v307_scene_skill_fix.js?v=307"></script>\n'+old,1)
payload=Path(__file__).resolve().parent/'v307_scene_skill_fix.js'
if not payload.is_file():sys.exit('STOP missing payload')
for fn in ('index.html','v12_patch.js'):
 shutil.copy2(root/fn,root/(fn+'.v307bak'))
(root/'index.html').write_text(i)
(root/'v12_patch.js').write_text(a)
shutil.copy2(payload,root/'v307_scene_skill_fix.js')
print('V30.7 installed: old hit labels removed; scene geometry and legacy cards corrected. No DB touched.')
