#!/usr/bin/env python3
"""55 AMBERLANDS V30.7: fix original combat skill HUD and ghost scene sprites.
Run once at the GitHub repo root; never modifies databases or player saves.
"""
from pathlib import Path
import sys, re, shutil

root=Path.cwd()
index=root/'index.html'
f12=root/'v12_patch.js'
f14=root/'v14_skill_fx.js'
paths=(index,f12,f14)
if any(not p.is_file() for p in paths):
    sys.exit('ERROR: Run in the GitHub repository root (index.html, v12_patch.js, v14_skill_fx.js required)')
old={p:p.read_text(encoding='utf-8') for p in paths}
if './v307_scene_skill_cleanup.js?v=307_source_truth_1' in old[index]:
    print('V30.7 already installed, no files modified.')
    sys.exit(0)

# V12: stop adding a hit label after EVERY render. Hit counts in combat remain unchanged.
needle12="""const originalRenderSkills=renderSkills;
renderSkills=function(){originalRenderSkills();$('skills')?.querySelectorAll('button').forEach((b,i)=>{
 const sk=SKILLS.filter(x=>state.learned.includes(x.id))[i];if(!sk)return;
 if(sk.hits>1){const hint=document.createElement('small');hint.className='amber-skill-hits';hint.textContent='×'+sk.hits+' ฮิต';b.appendChild(hint)}
 })};"""
replace12="""const originalRenderSkills=renderSkills;
// V30.7: the compact battle bar displays ONE skill name, with no stacked hit counters.
// The multi-hit number stays on SKILLS and inside server-side combat unchanged.
renderSkills=function(){originalRenderSkills.apply(this,arguments);
 const host=$('skills'); if(host) host.querySelectorAll('.amber-skill-hits').forEach(n=>n.remove());
};"""

# V14: no repeated extra DOM chips, keep accessible skill detail information.
needle14="""const oldRenderSkills=renderSkills;
renderSkills=function(){oldRenderSkills();const learned=SKILLS.filter(s=>state.learned.includes(s.id)).slice(0,8);$('skills')?.querySelectorAll('button').forEach((button,i)=>{const sk=learned[i];if(!sk)return;button.title=information(sk);button.setAttribute('aria-label',sk.name+' '+information(sk));if(sk.buff){const tag=document.createElement('small');tag.textContent='✨ ทีม';tag.className='amber14-buff-tag';button.appendChild(tag)}})};"""
replace14="""const oldRenderSkills=renderSkills;
// V30.7: accessibility metadata only. Do NOT append more tags on each tick.
renderSkills=function(){oldRenderSkills.apply(this,arguments);
 const host=$('skills');if(!host)return;
 host.querySelectorAll('.amber14-buff-tag').forEach(n=>n.remove());
 const learned=SKILLS.filter(s=>state.learned.includes(s.id)).slice(0,8);
 host.querySelectorAll('button').forEach((button,i)=>{
  const sk=learned[i];if(!sk)return;
  const info=information(sk);button.title=info;button.setAttribute('aria-label',sk.name+' '+info);
 });
};"""

# CURRENT PRODUCTION V30.6 mobile_layout_stability still keeps the old V1 fake bot list. Real people are shown in V26 crowd.
# Root renderer owns our hero ONLY in cloud mode. Pixel V24 skinner takes over image.
needleIndex="""const __v304SpritesHTML=names.slice(0,state.party).map((n,i)=>`<div class="sprite"><img src="${image(i===0?'portrait':'friend'+(i-1))}"><small>${n}</small></div>`).join('');"""
replaceIndex="""const __v307Online=!!window.AMBER_CLOUD?.getStatus?.()?.cloudReady;
const __v307DisplayNames=__v307Online?[String(state.name||'Player')]:names.slice(0,state.party);
// Real online players are rendered by V26 crowd. NEVER create V1 fake party members here.
const __v307Blank='data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=';
const __v304SpritesHTML=__v307DisplayNames.map((n,i)=>`<div class="sprite"><img class="${__v307Online?'amber-v307-placeholder':''}" src="${__v307Online?__v307Blank:image(i===0?'portrait':'friend'+(i-1))}" alt=""><small>${String(n).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}</small></div>`).join('');"""

# Actual production V30.6 script anchor: v306_mobile_layout_stability.js.
# Previous V30.7 installer incorrectly required v306_responsive_layout.js (not on main).
anchor='<script src="./v306_mobile_layout_stability.js?v=306_mobile_stability_1"></script>'
new_anchor=anchor+'\n<script src="./v307_scene_skill_cleanup.js?v=307_source_truth_1"></script>'
for name,piece,place in [('V12 hit wrapper',needle12,old[f12]),('V14 buff wrapper',needle14,old[f14]),('old V1 scene sprite markup',needleIndex,old[index]),('V30.6 script anchor',anchor,old[index])]:
    ct=place.count(piece)
    if ct!=1:sys.exit(f'ERROR: preflight {name}: expected 1 match; got {ct}. No file changed.')
new12=old[f12].replace(needle12,replace12)
new14=old[f14].replace(needle14,replace14)
newIndex=old[index].replace(needleIndex,replaceIndex).replace(anchor,new_anchor)
newCss='''/* 55 AMBERLANDS V30.7 scene and skills guard */
(()=>{'use strict';if(window.AMBER_V307_CLEANUP)return;
window.AMBER_V307_CLEANUP=Object.freeze({version:'30.7',kind:'presentation'});
const s=document.createElement('style');s.id='amber-v307-source-guard';s.textContent=`
/* The source HTML uses transparent placeholders until Pixel V24 skins them. */
#scene #sprites .sprite>img.amber-v307-placeholder:not(.px24-hero){opacity:0!important}
#skills .amber-skill-hits,#skills .amber14-buff-tag{display:none!important}
#scene #px24Scene{image-rendering:pixelated!important;inset:0!important;max-width:100%!important}
#scene .partySprites{max-width:100%!important;min-width:0!important}
#skills.skills>button{overflow:hidden!important}
#skills.skills>button>small{max-width:100%!important;overflow-wrap:anywhere!important}
`;document.head.appendChild(s);
})();
'''
if len(newIndex)<100000 or '<script src="./v307_scene_skill_cleanup.js?v=307_source_truth_1"></script>' not in newIndex:
    sys.exit('ERROR: unexpected index size / output; no changes written')
backup=root/'.git'/'amber-v3071-backup'
backup.mkdir(exist_ok=True)
for p in paths:
    b=backup/p.name
    if not b.exists():shutil.copy2(p,b)
for p,content in [(index,newIndex),(f12,new12),(f14,new14)]:p.write_text(content,encoding='utf-8')
(root/'v307_scene_skill_cleanup.js').write_text(newCss,encoding='utf-8')
print('PASS: patched index.html, v12_patch.js, v14_skill_fx.js; added v307_scene_skill_cleanup.js')
print('PASS: old V1 fake sprites suppressed in cloud mode; skill hit counter DOM append disabled')
print('Backups:',backup)
