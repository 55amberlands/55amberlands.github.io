#!/usr/bin/env bash
set -euo pipefail
repo="$(git rev-parse --show-toplevel)"
cd "$repo"
if [ "$(git branch --show-current)" != "main" ]; then echo 'ERROR: Switch to main before applying V30.7'; exit 2; fi
for file in index.html v12_patch.js v14_skill_fx.js v307_scene_skill_cleanup.js; do
  if [ -n "$(git status --porcelain -- "$file")" ]; then
    echo "ERROR: Local uncommitted changes in $file. Commit or stash those changes first; no files modified."
    exit 2
  fi
done
root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "$root/patch_v3071.py"
node --check v12_patch.js
node --check v14_skill_fx.js
node --check v307_scene_skill_cleanup.js
python3 - <<'PY'
from pathlib import Path
s=Path('index.html').read_text(encoding='utf-8')
a=Path('v12_patch.js').read_text(encoding='utf-8')
b=Path('v14_skill_fx.js').read_text(encoding='utf-8')
assert 'const __v307Online=' in s and 'names.slice(0,state.party).map((n,i)=>`<div class="sprite"' not in s
assert s.count('v307_scene_skill_cleanup.js?v=307_source_truth_1')==1
assert "hint.className='amber-skill-hits';b.appendChild(hint)" not in a
assert "tag.className='amber14-buff-tag';button.appendChild(tag)" not in b
print('PASS: static guards and JS syntax')
PY
git diff --check
git add -- index.html v12_patch.js v14_skill_fx.js v307_scene_skill_cleanup.js
if git diff --cached --quiet; then
  echo 'V30.7.1 already installed; no new commit needed.'
else
  git commit -m "V30.7 eliminate stacked skill hits and legacy ghost players"
fi
git push origin main
printf '\nPASS: V30.7 pushed. Wait for GitHub Pages deployment before testing in browser.\n'
