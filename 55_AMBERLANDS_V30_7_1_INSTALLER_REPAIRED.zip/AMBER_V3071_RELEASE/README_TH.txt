55 AMBERLANDS V30.7.1 — Corrected GitHub installer (fixes missing v306_responsive_layout.js)

Supported base: Current main containing v306_mobile_layout_stability.js and the V30.5 UI patches.
Root cause: Previous V30.7 installer checked for non-existent v306_responsive_layout.js and used a V12 needle that did not match the live code. It exited before patching.

Install:
1. Upload 55_AMBERLANDS_V30_7_1_INSTALLER_REPAIRED.zip to GitHub using Add file -> Upload files -> Commit to main.
2. In Codespaces terminal run one line:
   cd "$(git rev-parse --show-toplevel)" && git switch main && git pull --ff-only origin main && unzip -oq 55_AMBERLANDS_V30_7_1_INSTALLER_REPAIRED.zip -d .git/amber_v3071 && bash .git/amber_v3071/AMBER_V3071_RELEASE/deploy_v3071.sh

Actions:
- Edits v12_patch.js to stop repeatedly appending the ×2 / ×3 hit labels. Combat hit count itself remains intact.
- Edits v14_skill_fx.js to stop stacking buff tags in the battle skill bar; readable skill tooltips are preserved.
- Edits the old inline renderScene in index.html so authenticated-online mode stops creating fake V1 party members. Other real players are rendered in the V26 crowd layer.
- Adds v307_scene_skill_cleanup.js for visual overflow and placeholder handling.
- Backups are stored under .git/amber-v3071-backup/ and are never deployed.
- Checks JavaScript with node --check; git commit/push only after validation.

No database changes, no SQL, no grant of boss fragments, no change to inventory/HP/MP/combat/rewards.
This installer has been syntax-checked and tested in a temporary Git repository. Confirm Android visual behavior after GitHub Pages Actions success.
