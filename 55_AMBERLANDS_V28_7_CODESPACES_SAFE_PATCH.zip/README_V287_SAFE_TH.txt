55 AMBERLANDS — V28.7 SAFE CODESPACES PATCH (สร้างจากไฟล์งานเก่าจริง)
========================================================================
อ้างอิง: GitHub main V28.5 และ Supabase V28.7 ที่ติดตั้งแล้ว (ไม่ต้องอัป V28.6 / ไม่ต้องรัน SQL)

ของที่แก้/คืน (ไฟล์ทั้งหมดอยู่ใน v287_patch/):
1. v23_dungeon.js: เพิ่มข้อความอันดับดาเมจดันเจียนจาก snapshot ของ Supabase ในข้อความช่วยเหลือเดิม (ไม่เพิ่ม/ย้าย UI หรือ CSS); ใช้ MP ที่ server ส่งกลับ ป้องกันการหักซ้ำ
2. v26_realtime.js: ใช้ ranking จริงจาก server ใน World Boss ระหว่าง AUTO และหลังจบบอส (นำโค้ดที่ผู้ช่วยเดิมเตรียมไว้ใน V28.7 กลับมา)
3. index.html: แก้เฉพาะ query version ของ URL สคริปต์ 3 จุด เพื่อบังคับให้ browser โหลด JS รุ่นใหม่; ไม่แก้ UI, CSS, Asset, ระบบ Login, game logic
4. v278_pet_authority.js: คืนไฟล์ตัวจริงจาก ZIP V27.8 ในแชทเก่า (ตรวจ Git blob SHA) ที่หน้าเว็บเรียกแต่ GitHub main ไม่มี เพื่อแก้ workflow Deploy ที่ล้ม

คำเตือน:
- ไม่เปลี่ยนสูตรดาเมจบน Supabase เพราะ private.amber_v287_roll_combat ติดตั้งแล้ว
- ไม่แตะตารางตัวละคร ไม่ลบ localStorage ไม่ลบ Payless Z/PeleZ หรือบัญชีใด
- ไม่แก้ Asset, Map, Skill sprites, CSS, Shop, Party
- ห้ามอัป ZIP V28.6 ทับไฟล์นี้ และอย่ารัน SQL เดิมซ้ำ
- ถ้ามีใครแก้ GitHub main หลังจากตรวจนี้ ตัวติดตั้งจะหยุดเมื่อ SHA ไม่ตรง ห้ามบังคับทับ

วิธีทำบนมือถือ/Chrome ใน GitHub เหมือน V27.3.3:
A) ที่ GitHub Repository 55amberlands/55amberlands.github.io → Add file → Upload files
   อัป 55_AMBERLANDS_V28_7_CODESPACES_SAFE_PATCH.zip และ Commit ZIP เข้า main เท่านั้น (ขั้นนี้ยังไม่เปลี่ยนไฟล์เกม)
B) เปิด Codespaces ของ Repo → Terminal → รันทีละบรรทัด:

   git pull --ff-only origin main
   unzip -o 55_AMBERLANDS_V28_7_CODESPACES_SAFE_PATCH.zip -d .
   python3 install_v287_safe.py --check
   python3 install_v287_safe.py --apply
   git diff --check
   git diff --stat -- index.html v23_dungeon.js v26_realtime.js v278_pet_authority.js
   git add index.html v23_dungeon.js v26_realtime.js v278_pet_authority.js
   git commit -m "V28.7 server verified dungeon and world boss rankings"
   git push origin main

C) ตรวจ GitHub Actions ทั้งสอง workflow ว่า Deploy สำเร็จ และเข้าเว็บเดิม
   https://55amberlands.github.io/?v=287_verify
   หาก workflow ยังล้ม ห้ามส่ง ZIP ซ้ำหลายรอบ ให้อ่าน error จาก GitHub Actions ก่อน

ระบบอันดับดาเมจ: ให้ 2 คนใช้บัญชีตนเอง ลงดันเจียนเดียวกัน; อันดับแต่ละคนควรตรงกับ server.damage_dealt
แมปปกติ, World Boss, CRIT, MP ต้องตรวจว่าไม่เกิด bug
หากเห็นชื่อ/ตัวละครเกมเก่า: จด URL เต็มและบัญชีที่ Login ห้ามลบแคช/localStorage จนกว่าจะตรวจว่าเป็นข้อมูลเก่า origin ไหน

การสำรอง: ตัวติดตั้งสร้าง _amber_backups/V287_... ใน Codespaces ก่อนแก้และเก็บไฟล์ก่อนหน้าทั้งหมด
GitHub integration ของ ChatGPT ไม่ได้รับสิทธิ์ push (403) ดังนั้น ZIP นี้ไม่ได้ Deploy ให้อัตโนมัติ
