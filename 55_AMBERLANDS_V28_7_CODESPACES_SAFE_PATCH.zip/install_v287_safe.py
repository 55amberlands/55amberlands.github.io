#!/usr/bin/env python3
"""55 AMBERLANDS V28.7 — safe Codespaces installer.

Runs ONLY against exact verified GitHub main V28.5 files. No SQL, user save,
assets, CSS, authentication or game formulas are modified.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

BASE_HASH = {
    'index.html': 'a960fa05863714e0b8d68d5b65658b8291b741e8',
    'v23_dungeon.js': 'fddaa3dfc7174c14c75a6b6cdf94e3e11669ae64',
    'v26_realtime.js': 'cc2433cee372fb58230a3cf007fd0af73e26ad29',
}
RESTORE = 'v278_pet_authority.js'
RESTORE_HASH = '0679a340b4aceee4033b199a3932c8e0f8dff1d4'
TARGETS = tuple(BASE_HASH) + (RESTORE,)


def git_blob(b: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()


def command(args: list[str], root: Path, required: bool = True) -> bool:
    tool = shutil.which(args[0])
    if not tool:
        if required:
            raise RuntimeError(f'Missing required tool: {args[0]}')
        return False
    out = subprocess.run(args, cwd=root, capture_output=True, text=True)
    if out.returncode:
        raise RuntimeError(f'{" ".join(args)} failed:\n{out.stdout}\n{out.stderr}')
    if out.stdout.strip(): print(out.stdout.strip())
    return True


def preflight(root: Path, payload: Path) -> list[str]:
    if not (root/'.git').exists():
        raise RuntimeError('Run from the root of your Codespaces GitHub repository (missing .git).')
    missing=[]
    for name in TARGETS:
        src = payload/name
        if not src.is_file():
            raise RuntimeError(f'ZIP is incomplete: v287_patch/{name} missing')
        if name.endswith('.js'):
            command(['node','--check',str(src.resolve())],root)
        target = root/name
        if name in BASE_HASH:
            if not target.exists():
                raise RuntimeError(f'ABORT: live {name} missing')
            found = git_blob(target.read_bytes())
            if found != BASE_HASH[name]:
                raise RuntimeError(f'ABORT: {name} is NOT inspected V28.5 baseline. Blob {found}; expected {BASE_HASH[name]}. No files changed.')
        elif target.is_file():
            existing = git_blob(target.read_bytes())
            if existing != RESTORE_HASH:
                raise RuntimeError(f'ABORT: {name} already exists but is different from original V27.8 source (SHA {existing}). Do not overwrite.')
            print(f'KEEP: {name} already present with original SHA')
        else:
            missing.append(name)
    # Reject patch that accidentally changes anything but script URL query strings.
    index_orig = (root/'index.html').read_text('utf-8')
    index_new = (payload/'index.html').read_text('utf-8')
    expected_replacements = [
      ('./v23_dungeon.js?v=23_4','./v23_dungeon.js?v=287_verified_rank'),
      ('./v26_realtime.js?v=27_3_3','./v26_realtime.js?v=287_world_rank'),
      ('./v278_pet_authority.js?v=2781','./v278_pet_authority.js?v=287_restore'),
    ]
    expected=index_orig
    for old,new in expected_replacements:
        if expected.count(old)!=1:
            raise RuntimeError(f'ABORT: unexpected index script URL {old}')
        expected=expected.replace(old,new,1)
    if index_new != expected:
        raise RuntimeError('ABORT: index.html payload has non-URL changes (possible UI or asset changes).')
    actual_pet=git_blob((payload/RESTORE).read_bytes())
    if actual_pet != RESTORE_HASH:
        raise RuntimeError(f'ABORT: restored pet file has wrong source SHA {actual_pet}')
    print('PASS: exact V28.5 hashes; asset/UI remain untouched; all JS syntax valid.')
    return missing


def install(root: Path, payload: Path) -> None:
    missing=preflight(root,payload)
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    backups = root/'_amber_backups'/('V287_'+stamp)
    backups.mkdir(parents=True,exist_ok=False)
    touched=[]
    meta={'checked_base_sha':BASE_HASH,'missing_before':missing,'changed_files':list(TARGETS),'utc':stamp}
    try:
        for name in TARGETS:
            target=root/name
            if target.exists():shutil.copy2(target,backups/name)
            touched.append(name)
            temp=target.with_name(target.name+'.V287_PARTIAL')
            try:
                shutil.copy2(payload/name,temp)
                os.replace(temp,target)
            finally: temp.unlink(missing_ok=True)
        (backups/'install_manifest.json').write_text(json.dumps(meta,indent=2,ensure_ascii=False),'utf-8')
        for js in ('v23_dungeon.js','v26_realtime.js','v278_pet_authority.js'):
            command(['node','--check',js],root)
        command(['git','diff','--check','--','index.html','v23_dungeon.js','v26_realtime.js','v278_pet_authority.js'],root)
        if (root/'tools/check_static_site.py').exists():
            command(['python3','tools/check_static_site.py'],root)
    except Exception:
        for name in touched:
            src=backups/name
            target=root/name
            if src.exists():shutil.copy2(src,target)
            elif name in missing: target.unlink(missing_ok=True)
        raise
    print('\nINSTALLED locally in Codespaces. NO commit or push has been made.')
    print('Backup:',backups.relative_to(root))
    print('Inspect: git diff -- index.html v23_dungeon.js v26_realtime.js')
    print('Then commit ONLY the four intended files, do not git add .')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--check',action='store_true',help='Verify without changing any files')
    ap.add_argument('--apply',action='store_true',help='Install verified patch and make a backup')
    args=ap.parse_args()
    if args.check==args.apply:ap.error('Choose exactly one: --check or --apply')
    root=Path.cwd().resolve()
    payload=Path(__file__).resolve().parent/'v287_patch'
    if args.check:
        missing=preflight(root,payload)
        print('DRY RUN PASS. Missing file to restore:',', '.join(missing) or 'none')
    else:install(root,payload)

if __name__=='__main__':
    try:main()
    except Exception as e:
        print('FAILED SAFELY:',e,file=sys.stderr)
        sys.exit(1)
