#!/usr/bin/env python3
"""55 AMBERLANDS V30.1.1: fix duplicated/hovering self caused by V24 skinning V25 title aura."""
from pathlib import Path
import sys

root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd().resolve()
index=root/'index.html'
integration=root/'v24_px_integration.js'
if not index.is_file() or not integration.is_file():
    raise SystemExit('STOP: repository root must have index.html and v24_px_integration.js')
a=index.read_text(encoding='utf-8')
b=integration.read_text(encoding='utf-8')
if 'v28_boss_book.js' in a or 'v308_live_fix.js' in a:
    raise SystemExit('STOP: this patch requires restored V30.1, not V30.2-V30.9')

old="const img = el.querySelector(':scope > img:not(.amber20-characterWing):not(.amber-equipped-weapon):not(.amber23-pet-sprite)'); if (!img) return;"
new="""// V30.1.1 SOURCE FIX: do not reinterpret V25 title aura or emote as a second player.
    // V25 inserts .px25-aura as the FIRST child image; it is not the hero body.
    const img = el.querySelector(':scope > img.px24-hero:not(.px25-aura):not(.px25-emote)')
      || el.querySelector(':scope > img.amber20-characterBody:not(.px25-aura):not(.px25-emote)')
      || el.querySelector(':scope > img:not(.amber20-characterWing):not(.amber-equipped-weapon):not(.amber23-pet-sprite):not(.px25-aura):not(.px25-emote)');
    if (!img) return;"""

a_old='<script src="./v24_px_integration.js?v=24_2"></script>'
a_new='<script src="./v24_px_integration.js?v=3011_v25_aura_excluded"></script>'

if old in b:
    if b.count(old)!=1:
        raise SystemExit('STOP: ambiguous V24 hero selector; no changes made')
    b_new=b.replace(old,new)
elif new in b:
    b_new=b
else:
    raise SystemExit('STOP: V24 hero renderer has unknown source; no changes made')

if a_old in a:
    if a.count(a_old)!=1:
        raise SystemExit('STOP: ambiguous V24 script tag; no changes made')
    a_new=a.replace(a_old,a_new)
elif a_new in a:
    a_new=a
else:
    raise SystemExit('STOP: V24 script tag not found in V30.1; no changes made')

if b_new==b and a_new==a:
    print('PASS: V30.1.1 already installed; nothing changed')
else:
    # Installer refuses unknown source up front, so both files are safe to patch together.
    if a_new!=a:
        index.write_text(a_new,encoding='utf-8')
    if b_new!=b:
        integration.write_text(b_new,encoding='utf-8')
    print('PASS: V30.1.1 corrected V24 hero selector and cache-busted its script')
