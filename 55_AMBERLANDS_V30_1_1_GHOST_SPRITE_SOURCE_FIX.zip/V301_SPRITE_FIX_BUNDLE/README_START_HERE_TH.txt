55 AMBERLANDS V30.1.1 — แก้ตัวละครซ้อนบนฉาก Real Time โดยรักษา V30.1 เป็นฐาน

สาเหตุ: v25_systems.js แทรกรูป title aura ชื่อ .px25-aura เข้าเป็นภาพแรกของ .sprite
แต่ v24_px_integration.js ใน skinSprites() เลือก img:first-candidate โดยไม่ตัด .px25-aura ออก
เมื่อผู้เล่นได้ฉายาที่มีออร่า จึงเปลี่ยนภาพออร่าเป็นภาพ Hero อีกตัว ทำให้เห็นสองตัวละคร

สิ่งที่แก้: ปรับ DOM selector ใน v24_px_integration.js ให้เลือกภาพตัวละครจริง
และข้าม .px25-aura/.px25-emote โดยไม่ซ่อนองค์ประกอบ UI ด้วย CSS
เปลี่ยน query string ใน index.html ป้องกันเบราว์เซอร์โหลด JS เก่าจาก cache

ไม่มีการแก้ Supabase/SQL/สกิล/ดาเมจ/ฉายา/ข้อมูลคอสตูม/สูตรเกม
ไม่มีการรวม V28 boss 10 ตัวหรือโค้ด V30.2-V30.9

วิธีติดตั้ง:
1. GitHub repo -> Add file -> Upload files -> อัปโหลด ZIP -> Commit changes
2. เปิด Codespaces Terminal แล้วรัน:
cd "$(git rev-parse --show-toplevel)" && git switch main && git pull --ff-only origin main && unzip -oq 55_AMBERLANDS_V30_1_1_GHOST_SPRITE_SOURCE_FIX.zip -d .git/amber_v3011 && bash .git/amber_v3011/V301_SPRITE_FIX_BUNDLE/deploy_v301_sprite_fix.sh
3. ไป GitHub Actions รอ Deploy success และเปิดเกมใหม่

ทดสอบที่จุดฉากแมปมีหิมะ + ใส่คอสตูมปีก + ฉายาจอมทัพเปลวเพลิง
ควรเห็นร่างผู้เล่นเพียง 1 ตัว ออร่าฉายาและปีกยังอยู่
หากยังเห็นอีกตัว อย่าสร้าง CSS ซ่อนทับเพิ่ม ให้ตรวจ DOM #sprites และ screenshot ใหม่
