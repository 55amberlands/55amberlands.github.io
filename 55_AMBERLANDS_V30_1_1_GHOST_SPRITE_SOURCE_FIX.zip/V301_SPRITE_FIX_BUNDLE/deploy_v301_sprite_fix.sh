#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
if [[ -n "$(git status --porcelain --untracked-files=no)" ]]; then
  echo 'STOP: tracked files are modified or staged; commit/stash changes first' >&2
  exit 1
fi
python3 .git/amber_v3011/V301_SPRITE_FIX_BUNDLE/install_v301_sprite_fix.py "$(pwd)"
node --check v24_px_integration.js
git diff --check -- index.html v24_px_integration.js
git add -- index.html v24_px_integration.js
if git diff --cached --quiet; then
  echo 'PASS: V30.1.1 already installed; no commit needed'
else
  git commit -m 'V30.1.1 fix ghost hero from title aura in realtime scene'
  git push origin main
  echo 'PASS: V30.1.1 pushed; check GitHub Pages Actions'
fi
