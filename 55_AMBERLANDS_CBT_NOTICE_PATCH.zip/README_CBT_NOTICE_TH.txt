55 AMBERLANDS — CBT NOTICE V1 (GITHUB PAGES)
=============================================
ไฟล์อัปเดต 3 ไฟล์เท่านั้น:
- index.html : เพิ่มการโหลด cbt_notice.js หนึ่งบรรทัดก่อน </body>
- cbt_notice.js : เพิ่มหน้าประกาศหลัง Google Login + โหลดตัวละครสำเร็จ
- assets/notice/amberlands_cbt_announcement.png : ใช้โปสเตอร์ CBT ที่ตกลงกันไว้

ไม่แก้ online_bridge.js, Supabase, SQL, ระบบต่อสู้ หรือ UI เดิม

วิธีติดตั้งใน Codespaces (ภายใน repo 55amberlands.github.io):
1. อัปโหลด ZIP นี้ไว้ที่ root ของ repository ผ่านหน้า GitHub (Add file > Upload files).
2. กลับเข้า Codespaces และเปิด Terminal
3. รัน: unzip -o 55_AMBERLANDS_CBT_NOTICE_PATCH.zip -d .
4. รัน: git add index.html cbt_notice.js assets/notice/amberlands_cbt_announcement.png
5. รัน: git commit -m "Add CBT login notice"
6. รัน: git push origin main

หากอัปโหลด ZIP ไปก่อนแล้วอย่าลืมว่าไฟล์ ZIP ไม่จำเป็นต้อง Commit เพื่อใช้งานหลังแตก

พฤติกรรม:
- เมื่อ Google Login สำเร็จและโหลดตัวละครจาก Supabase สำเร็จ -> แสดงป้าย CBT
- กากบาท (×) หรือ "ปิดเฉพาะครั้งนี้" -> ปิดป้าย เฉพาะหน้าเว็บรอบปัจจุบัน
- "ปิดถาวร (เครื่องนี้)" -> บันทึก localStorage ในเบราว์เซอร์นี้
- ไม่ซิงก์การปิดถาวรข้ามมือถือ / ข้ามเบราว์เซอร์ เพราะไม่ได้แก้ฐานข้อมูล
- หากต้องการให้แสดงป้ายอีกหลังปิดถาวร สามารถล้าง site data ของเว็บนี้

หมายเหตุ: ZIP นี้ประกอบด้วย index.html จากชุด GitHub V24.2 ที่นำขึ้นเว็บชื่อเกมตามบทสนทนา
ถ้ามีการแก้ index.html ใหม่หลังจากนั้น ควรเพิ่ม script tag เพียงบรรทัดเดียว
แทนการทับไฟล์ index.html เพื่อไม่ให้การเปลี่ยนแปลงล่าสุดสูญหาย
