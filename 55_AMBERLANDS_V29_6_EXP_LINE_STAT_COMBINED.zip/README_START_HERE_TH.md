# 55 AMBERLANDS V29.6 — แพตช์รวม V29.5 + EXP Supabase + LINE Preview

## สำคัญ
- V29.5 ยังไม่ถูกอัปใน GitHub ก่อนทำแพตช์นี้ ชุด **V29.6 รวม V29.5 ให้แล้ว** จึงไม่ต้องติดตั้ง V29.5 แยกอีก
- SQL V29.6 ติดตั้งบน Supabase จริงแล้ว (migration: `amber_v296_exp_monotonic_server_progress_and_levelup`) **ห้าม Run SQL ซ้ำโดยไม่จำเป็น**
- แพตช์ฝั่ง GitHub ยังไม่ได้ลง ผู้ใช้ต้องอัปโหลด ZIP นี้แล้วรันตัวติดตั้งใน Codespaces
- ไม่ลบตัวละคร ไม่แก้ค่าพลังต่อสู้ ไม่เปลี่ยน Asset, Sprite, แผนที่, สกิล, อุปกรณ์ หรือกระเป๋าไอเทม

## สิ่งที่แก้
1. **สเตตัส V29.5**: เมื่อกด +1 ระบบต้องรอ Supabase ยืนยันการจัดแต้มสำเร็จ แล้วอัปเดต STR/DEX/INT/VIT/AGI/LUK, ATK, DEF, HP, MP, CRIT และค่าพลังแสดงบนหน้าต่างที่เปิดอยู่ทันที โดยไม่รีโหลดเกม
2. **EXP V29.6**: ฟังก์ชัน `private.amber_v296_exp_required(level)` เป็นสูตรเดียวที่กำหนด EXP ที่ต้องใช้, `public.amber_v296_exp_progress()` คืนค่าของตัวละครที่ล็อกอินเองเท่านั้น
3. **หลอด EXP**: `v296_exp_progress.js` อ่าน EXP ที่เซิร์ฟเวอร์รับรองและค่าที่ต้องใช้จาก RPC แสดง `EXP ปัจจุบัน / EXP ที่ต้องใช้` กับเปอร์เซ็นต์ในหลอด ขณะรอการเชื่อมต่อจะขึ้น `รอเชื่อม Supabase` ไม่ใช้ตัวเลขประมาณจากเกมออฟไลน์
4. **พรีวิว LINE**: เปลี่ยน `<title>` เดิม V23.2 เพิ่ม Open Graph title/description/image และ meta description เพื่อไม่ให้ LINE ดึงชื่อ PeleZ/DEMO จากเกมต้นแบบมาแสดงก่อน

## EXP ใหม่ที่ติดตั้งบนเซิร์ฟเวอร์

| Lv. | ต้องใช้ EXP |
|---:|---:|
| 30 | 35,017 |
| 40 | 174,002 |
| 45 | 329,202 |
| 49 | 494,483 |
| 50 | 541,513 |
| 51 | 590,827 |
| 60 | 1,137,398 |
| 80 | 3,013,839 |
| 99 | 5,641,497 |

- ตรวจครบ Lv.1 ถึง Lv.99: ค่า EXP ต้องการเพิ่มต่อเนื่อง ไม่มีค่าลดลง
- EXP และเลเวลที่สะสมในตัวละครไม่ถูกลบหรือรีเซ็ต
- **ข้อสังเกต:** ข้อมูลตัวละครเก่าบางตัวมี EXP คงเหลือเกินเกณฑ์ที่จะขึ้นเลเวลตั้งแต่ก่อนแพตช์นี้ หลอดอาจแสดง 100% จนกว่าจะเกิดธุรกรรมต่อสู้/อัปเลเวลครั้งถัดไป ระบบไม่ปรับเซฟเก่าโดยอัตโนมัติเพราะอาจกระทบสเตตัส

## วิธีติดตั้งใน GitHub Codespaces — ชุดเดียว

1. ไป GitHub Repository `55amberlands/55amberlands.github.io` → **Add file → Upload files**
2. อัปโหลดไฟล์ `55_AMBERLANDS_V29_6_EXP_LINE_STAT_COMBINED.zip` แล้วกด **Commit changes**
3. เปิด **Code → Codespaces → Terminal → New Terminal** และวางคำสั่งนี้ทีเดียว:

```bash
git pull --ff-only origin main && \
unzip -o 55_AMBERLANDS_V29_6_EXP_LINE_STAT_COMBINED.zip -d . && \
python3 install_v296_safe.py --check && \
python3 install_v296_safe.py --apply && \
python3 tools/check_static_site.py && \
git diff --check && \
git add index.html v277_authority_client.js v296_exp_progress.js && \
git commit -m "V29.6 server EXP progress, live stats and LINE preview" && \
git push origin main
```

*ไม่ต้องรัน SQL เพิ่ม!* ถ้าขึ้น `STOP` ให้ส่งข้อความ/ภาพ Terminal เพื่อแก้ตามเวอร์ชันปัจจุบัน **อย่าใช้ `git reset --hard` หรือ `git push --force`**

## ตรวจหลังติดตั้ง
- เข้าหน้าตัวละคร กด STR +1 หรือ VIT +1 ค่าพลังในกรอบล่างต้องเปลี่ยนทันทีหลัง Supabase ตอบกลับ
- เปิด EXP: จะเห็นค่า `EXP ปัจจุบัน / ที่ต้องใช้` ที่ตรงกับ RPC; Lv.49 ต้องใช้ 494,483, Lv.50 ต้องใช้ 541,513, Lv.51 ต้องใช้ 590,827
- ทดลองส่งลิงก์ **ใหม่** `https://55amberlands.github.io/?share=296` ใน LINE เพื่อหลีกเลี่ยงแคชพรีวิวลิงก์เก่า (LINE อาจยังใช้แคชอยู่ระยะหนึ่ง)
- การเปลี่ยนเมตาแท็กไม่เปลี่ยนตัวละครที่ล็อกอินและไม่เปลี่ยนเว็บกลับเป็น V23.2

## หมายเหตุการรักษาความปลอดภัย
- API `amber_v296_exp_progress` ใช้ `auth.uid()` และให้ execute เฉพาะผู้ใช้ authenticated
- ตัวเลข EXP ที่ต้องการถูกกำหนดจากฟังก์ชัน SQL; JavaScript ไม่ได้รับสิทธิ์ส่งค่า EXP ที่ต้องการหรืออนุมัติการอัปเลเวล
- สำรองนิยามฟังก์ชันโจมตีเดิมบน `private.amber_v296_function_backup` ก่อนติดตั้งเซิร์ฟเวอร์
- ตัวติดตั้งสำรอง `index.html` และ `v277_authority_client.js` ใน `.amber_backups/v296_*` ก่อนแก้
