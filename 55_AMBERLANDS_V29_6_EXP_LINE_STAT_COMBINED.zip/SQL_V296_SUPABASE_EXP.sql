-- 55 AMBERLANDS V29.6
-- Server-authoritative, monotonically increasing EXP curve and read-only player EXP RPC.
-- Install once on the existing Supabase project before the V29.6 frontend goes live.
-- Does NOT reset level, experience, stats, money, inventory, or rebirth data.
BEGIN;

CREATE TABLE IF NOT EXISTS private.amber_v296_function_backup (
  signature text PRIMARY KEY,
  definition text NOT NULL,
  backed_up_at timestamptz NOT NULL DEFAULT pg_catalog.clock_timestamp()
);
REVOKE ALL ON private.amber_v296_function_backup FROM PUBLIC, anon, authenticated;
INSERT INTO private.amber_v296_function_backup(signature,definition)
SELECT 'public.amber_v277_attack(text,text)',pg_catalog.pg_get_functiondef(p.oid)
FROM pg_catalog.pg_proc p JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace
WHERE n.nspname='public' AND p.proname='amber_v277_attack'
ON CONFLICT(signature) DO NOTHING;

CREATE OR REPLACE FUNCTION private.amber_v296_exp_required(p_level integer)
RETURNS bigint LANGUAGE sql IMMUTABLE STRICT SET search_path TO ''
AS $exp$
 SELECT CASE WHEN p_level=100 THEN 0::bigint
   WHEN p_level BETWEEN 1 AND 99 THEN (
      pg_catalog.round(50*pg_catalog.power(p_level::numeric,1.85)
         + pg_catalog.power(greatest(0,p_level-10)::numeric,2)*20)
      + 1100 * pg_catalog.power(greatest(0,p_level-30)::numeric,2)
   )::bigint
   ELSE NULL::bigint END;
$exp$;
REVOKE ALL ON FUNCTION private.amber_v296_exp_required(integer) FROM PUBLIC,anon,authenticated;

-- Only authenticated players may view their own level, EXP and authoritative requirement.
CREATE OR REPLACE FUNCTION public.amber_v296_exp_progress()
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO ''
AS $progress$
DECLARE
  me uuid:=(SELECT auth.uid());
  snapshot jsonb;
  lvl integer;
  gained bigint;
  requirement bigint;
BEGIN
  IF me IS NULL THEN RAISE EXCEPTION 'V296_SIGN_IN_REQUIRED'; END IF;
  SELECT save_data INTO snapshot FROM public.amber_characters WHERE user_id=me;
  IF snapshot IS NULL THEN RAISE EXCEPTION 'V296_CHARACTER_NOT_FOUND'; END IF;
  lvl:=COALESCE((snapshot->>'lv')::integer,1);
  gained:=COALESCE((snapshot->>'xp')::bigint,0);
  IF lvl NOT BETWEEN 1 AND 100 OR gained NOT BETWEEN 0 AND 2000000000 THEN
    RAISE EXCEPTION 'V296_INVALID_CHARACTER_EXP';
  END IF;
  requirement:=private.amber_v296_exp_required(lvl);
  RETURN pg_catalog.jsonb_build_object(
    'ok',true,'level',lvl,'xp',gained,'required',requirement,
    'remaining',CASE WHEN lvl=100 THEN 0 ELSE greatest(0,requirement-gained) END,
    'percent',CASE WHEN lvl=100 THEN 100
              ELSE pg_catalog.round(100*least(requirement,gained)::numeric/requirement,2) END,
    'max_level',100,'curve_version',296);
END $progress$;
REVOKE ALL ON FUNCTION public.amber_v296_exp_progress() FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.amber_v296_exp_progress() TO authenticated;

-- Existing normal-map server attack applies XP and level-ups. Patch only the two
-- formula calls, retaining locks, reward multipliers, drops, and all combat logic.
DO $patch$
DECLARE f oid; body text; original text; replacement text; occ integer;
BEGIN
 SELECT p.oid INTO f FROM pg_catalog.pg_proc p
 JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace
 WHERE n.nspname='public' AND p.proname='amber_v277_attack'
 AND p.prokind='f';
 IF f IS NULL THEN RAISE EXCEPTION 'V296_ATTACK_FUNCTION_NOT_FOUND'; END IF;
 body:=pg_catalog.pg_get_functiondef(f);
 original:='round(50*power(lv::numeric,1.85)+power(GREATEST(0,lv-10)::numeric,2)*20)::bigint';
 replacement:='private.amber_v296_exp_required(lv)';
 occ:=(pg_catalog.length(body)-pg_catalog.length(pg_catalog.replace(body,original,'')))
   / pg_catalog.length(original);
 IF pg_catalog.strpos(body,replacement)>0 AND occ=0 THEN
    NULL; -- migration already applied, safe no-op
 ELSIF occ=2 THEN
    body:=pg_catalog.replace(body,original,replacement);
    EXECUTE body;
 ELSE
    RAISE EXCEPTION 'V296_ATTACK_XP_FORMULA_CHANGED, expected 2 old occurrences got %',occ;
 END IF;
END $patch$;

-- Stop if the curve ever drops at a later level (transaction rolls back).
DO $monotonic$
DECLARE bad_levels integer;
BEGIN
 SELECT count(*) INTO bad_levels FROM (
   SELECT lvl,private.amber_v296_exp_required(lvl) target,
     pg_catalog.lag(private.amber_v296_exp_required(lvl)) OVER (ORDER BY lvl) prev
   FROM pg_catalog.generate_series(1,99) AS lvl
 ) q WHERE prev IS NOT NULL AND target<=prev;
 IF bad_levels<>0 THEN RAISE EXCEPTION 'V296_EXP_CURVE_NOT_STRICTLY_INCREASING'; END IF;
END $monotonic$;
COMMIT;
NOTIFY pgrst, 'reload schema';
