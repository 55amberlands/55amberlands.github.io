#!/usr/bin/env python3
"""55 AMBERLANDS V29.6: safe joint upgrade (V29.5 live stats + XP display + LINE OG).

Front-end upgrade only. The matching server XP SQL is installed separately by the
assistant before the user deploys. Never edits a character save or overwrites assets.
"""
import argparse
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys
from datetime import datetime, timezone

EXPECTED = {
 'index.html':'c57375f8f91943270b2f00bdf23c8fad41c4ef1c',
 'v277_authority_client.js':'b07022023a5f81e03d4bbbb39d30da77d7fc155a',
}
JS_OLD = "window.upStat=async function v277Stat(st){try{await economy('allocate_stat',{stat:st});statRows();}catch{}}"
JS_NEW = """// V29.5: stat allocation is confirmed by Supabase BEFORE updating displayed values.
// The V12 extended combat panel is outside render(); refresh it in-place so the
// modal and its scroll position stay open on mobile. Never locally mint stat points.
window.upStat=async function v295LiveStat(st){
 if(!['STR','DEX','INT','VIT','AGI','LUK'].includes(st))return;
 try{
   const receipt=await economy('allocate_stat',{stat:st});
   if(!receipt?.ok || !receipt?.save)throw Error('STAT_NOT_CONFIRMED');
   statRows();
   window.AMBER_V12?.updateExtended?.();
   window.AMBER_V12?.statStrip?.();
   // The modal's original summary line is not part of render()/statRows().
   // Replace just its numeric text; preserve the points button and its scroll.
   const summary=document.getElementById('statrows')?.previousElementSibling;
   if(summary?.tagName==='P' && summary.textContent.includes('พลังต่อสู้')){
     const power=Math.round((Number(state.stats?.STR)||0)*8+(Number(state.stats?.DEX)||0)*3+(Number(state.lv)||1)*20);
     for(const node of summary.childNodes){
       if(node.nodeType===3 && node.textContent.includes('พลังต่อสู้'))
         node.textContent=node.textContent.replace(/(พลังต่อสู้\\s*)[0-9,]+/u,(_,prefix)=>prefix+power.toLocaleString('th-TH'));
     }
   }
 }catch(err){console.warn('[V29.5 live stat refresh]',err);}
};"""

TITLE_OLD='<title>55 AMBERLANDS V23.2 · Online MMORPG</title>'
TITLE_NEW='<title>55 AMBERLANDS — MMORPG ออนไลน์ Pixel Art</title>'
OPEN_GRAPH='\n<meta name="description" content="55 AMBERLANDS เกม MMORPG ออนไลน์ 2D Pixel Art เล่นกับเพื่อน ลงดันเจียน ต่อสู้บอส สะสมอุปกรณ์ และซื้อขายในตลาดผู้เล่น">\n<meta property="og:type" content="website">\n<meta property="og:site_name" content="55 AMBERLANDS">\n<meta property="og:title" content="55 AMBERLANDS | MMORPG ออนไลน์ 2D Pixel Art">\n<meta property="og:description" content="เล่น 55 AMBERLANDS ออนไลน์กับเพื่อน สำรวจ 10 แผนที่ ต่อสู้กับบอส ลงดันเจียน และแลกเปลี่ยนไอเทมในตลาด">\n<meta property="og:url" content="https://55amberlands.github.io/">\n<meta property="og:image" content="https://55amberlands.github.io/assets/notice/amberlands_cbt_announcement.png">\n<meta property="og:image:alt" content="55 AMBERLANDS เกม MMORPG ออนไลน์">\n<meta name="twitter:card" content="summary_large_image">\n<meta name="twitter:title" content="55 AMBERLANDS | MMORPG ออนไลน์ 2D Pixel Art">\n<meta name="twitter:description" content="10 แผนที่ บอส ดันเจียน ตลาดซื้อขาย และเล่นกับเพื่อนออนไลน์">\n'
OLD_V277='./v277_authority_client.js?v=293_auto_skill'
NEW_V277='./v277_authority_client.js?v=296_stat_refresh'
OLD_BRIDGE='<script src="./v294_world_map_boss_bridge.js?v=294_server_combat"></script>'
NEW_EXP_SCRIPT='<script src="./v296_exp_progress.js?v=296_server_exp"></script>'

def sha_blob(data:bytes)->str:
 return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def require_once(text,needle,filename):
 count=text.count(needle)
 if count!=1: raise RuntimeError(f'STOP: {filename}: expected 1 occurrence of {needle[:80]!r}, found {count}')

def make_patch(filename,source):
 txt=source.decode('utf-8')
 if filename=='v277_authority_client.js':
  require_once(txt,JS_OLD,filename)
  if JS_NEW in txt: raise RuntimeError('STOP: live-stat patch already present')
  return txt.replace(JS_OLD,JS_NEW).encode('utf-8')
 if filename=='index.html':
  for anchor in (TITLE_OLD, OLD_V277, OLD_BRIDGE): require_once(txt,anchor,filename)
  if 'og:title' in txt or NEW_EXP_SCRIPT in txt:
   raise RuntimeError('STOP: Open Graph or V29.6 XP script already present; do not duplicate')
  txt=txt.replace(TITLE_OLD,TITLE_NEW+OPEN_GRAPH)
  txt=txt.replace(OLD_V277,NEW_V277)
  txt=txt.replace(OLD_BRIDGE,OLD_BRIDGE+'\n'+NEW_EXP_SCRIPT)
  return txt.encode('utf-8')
 raise RuntimeError('STOP: unsupported file '+filename)

def js_check(name,source):
 node=shutil.which('node')
 if not node:
  print('WARN: Node.js unavailable, lexical checks only for',name)
  return
 check=subprocess.run([node,'--check','-'],input=source,capture_output=True)
 if check.returncode:
  raise RuntimeError('STOP: JavaScript '+name+' syntax failure: '+check.stderr.decode('utf-8','replace')[:500])

def main():
 ap=argparse.ArgumentParser(description='55 AMBERLANDS V29.6 safe combined patch')
 mode=ap.add_mutually_exclusive_group(required=True)
 mode.add_argument('--check',action='store_true')
 mode.add_argument('--apply',action='store_true')
 args=ap.parse_args()
 repo=Path.cwd()
 patchfile=Path(__file__).with_name('v296_exp_progress.js')
 if not patchfile.is_file():
  raise RuntimeError('STOP: missing v296_exp_progress.js; extract the complete ZIP first')
 exp_js=patchfile.read_bytes()
 if b'amber_v296_exp_progress' not in exp_js or b'requirements=new Map()' not in exp_js:
  raise RuntimeError('STOP: EXP script is not the expected implementation')
 js_check('v296_exp_progress.js',exp_js)
 patched={}
 for name,expected in EXPECTED.items():
  f=repo/name
  if not f.is_file(): raise RuntimeError('STOP: '+name+' missing; run from root of GitHub Codespaces repo')
  old=f.read_bytes()
  actual=sha_blob(old)
  if actual!=expected:
   raise RuntimeError('STOP: unexpected '+name+' SHA: '+actual+' (expected '+expected+'). Do not force overwrite; send Terminal screenshot.')
  new=make_patch(name,old)
  if name.endswith('.js'):js_check(name,new)
  patched[name]=(old,new)
  print('PASS: source',name,'SHA',actual[:12],'and patch anchors')
 if not (repo/'assets/notice/amberlands_cbt_announcement.png').is_file():
  print('WARN: Open Graph image is not in this local checkout; verify assets/notice/amberlands_cbt_announcement.png before deploying')
 print('PASS: V29.5 live stats + V29.6 server EXP UI + LINE OG ready; no player save affected')
 if args.check:
  print('CHECK complete, files unmodified')
  return
 backup=repo/'.amber_backups'/('v296_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
 backup.mkdir(parents=True,exist_ok=False)
 for name,(old,new) in patched.items():
  dest=backup/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(old)
 changed=[]
 try:
  for name,(old,new) in patched.items():
   dest=repo/name
   tmp=repo/(name+'.v296.tmp')
   tmp.write_bytes(new)
   os.chmod(tmp,dest.stat().st_mode)
   os.replace(tmp,dest)
   changed.append(name)
  # The new XP script is already present after unzip and will be committed below.
 except Exception:
  for name in changed:(repo/name).write_bytes(patched[name][0])
  raise
 print('PASS: V29.6 installed; originals backed up at',backup)
 print('NEXT: python3 tools/check_static_site.py && git diff --check')

if __name__=='__main__':
 try: main()
 except Exception as e:
  print(str(e),file=sys.stderr)
  sys.exit(1)
