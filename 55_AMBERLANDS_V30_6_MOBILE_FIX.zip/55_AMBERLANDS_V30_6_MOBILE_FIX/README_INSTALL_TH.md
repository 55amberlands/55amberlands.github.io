# 55 AMBERLANDS — V30.6 Mobile Layout & Stable Renderer

อิงไฟล์จริงจาก GitHub `55amberlands/55amberlands.github.io` (`main`, V30.5 commit `747c363850b0011776728b5dd51fc36cbace270f` วันที่ 26/10/2026) และโค้ดเก่าใน `index.html`, `v23_1_mobile_menu.js`, `v24_px_integration.js`, `v28_battle_hud.js`, `v28_skill_vfx.js`, `v303_unified_ui_cards.js`, `v304_stability_title.js`, `v305_visual_fix.js`.

**จุดแก้:** หยุดการแย่ง layout ของ `display:contents` กับ Flex, จำกัดขนาดและ clip ฉาก Realtime, จัดช่องสกิล 2 คอลัมน์มือถือพร้อม icon+ชื่อแนวนอน, บังคับ skill-tree ใน modal เป็นแถว, แก้ quick HUD/ปุ่มยาไม่ยื่นนอกขอบ, ใช้ `bar()` แบบแก้ text/width เดิมแทนการลบแล้วสร้าง HP/MP/EXP ใหม่ทุกครั้ง, เก็บ DOM ของสกิลจนกว่ารายการสกิลที่เรียนเปลี่ยนจริง, และติดตามความสูงเมนูเปิด/ปิดโดยไม่แก้ state ของปุ่ม.

**ไม่แก้:** Supabase, SQL, `amber_characters`, รายได้, inventory, สูตรดาเมจ/EXP, ค่า HP/MP, skill cooldown, FX assets, ตัวละครจริง หรือการ Login. ทั้งหมดเป็น client presentation override เท่านั้น.

## กฎ Transform และสัดส่วน (สำคัญ)

- **ห้ามใช้ `transform:scale(.7)` หรือ `zoom` กับ `.layout`, `.middle`, `.panel`, `#skills`, `#scene`, `.nav`** เพื่อยัดหน้าเว็บให้พอดีจอ เพราะ CSS transform เปลี่ยนเฉพาะภาพที่วาด แต่ไม่ได้ลดพื้นที่ layout ที่เบราว์เซอร์จัดสรรจริง จึงเกิดขอบที่เกย/พื้นที่กดไม่ตรง/สกิลกระพริบได้
- ใน V30.6 จำกัดแค่ปุ่มการ์ดสกิลและตัว Quick HUD ด้วย `transform:none!important` เพื่อหยุดการชนกันของ transform รุ่นเก่า แล้วใช้ `minmax(0,1fr)`, `min-width:0`, `width:100%`, `overflow-x:hidden` และ `box-sizing:border-box` แก้ที่สัดส่วนจริง
- **ไม่ยกเลิก transform ของ Animation ตัวละคร, ฉายา, sprite, เอฟเฟกต์อาวุธ และสกิล** เพราะจะทำให้ท่าทาง/แสงหายหรือผิดตำแหน่ง
- ข้อบังคับตรวจผล: ขนาดหน้าจอแนวตั้ง 320/360/390/430 CSS px ต้องไม่เกิด scroll ด้านข้าง หรือปุ่มสกิลแคบเป็นแท่ง; ไม่ควรแก้ด้วยซูมเบราว์เซอร์

## วิธีลงผ่าน GitHub Codespaces

1. เปิด Codespace ที่มีไฟล์ `index.html` เวอร์ชัน V30.5 อยู่ โค้ดเกมหลักในโฟลเดอร์ปัจจุบัน.
2. อัปโหลด ZIP เข้า Codespaces Explorer แล้วเปิด Terminal ในโฟลเดอร์ Repository และรัน:

```bash
unzip -o 55_AMBERLANDS_V30_6_MOBILE_FIX.zip -d .amber-v306-installer
python3 .amber-v306-installer/55_AMBERLANDS_V30_6_MOBILE_FIX/apply_v306.py --repo .
node --check v306_mobile_layout_stability.js
git diff --check
git status --short
git add index.html v306_mobile_layout_stability.js
git commit -m "V30.6 fix mobile skill layout and HUD flicker"
git push origin main
```

3. เปิด `https://55amberlands.github.io/?v=306` หลัง GitHub Pages deploy เสร็จ กด Reload แบบล้าง Cache หากยังแสดงเวอร์ชันเก่า (`?v=306` เปลี่ยน URL แต่ไม่รับประกันล้าง cache ของ service worker).
4. ทดสอบมือถือแนวตั้ง: ฉากไม่ล้นขอบ, สกิลไม่เรียงเป็นคอลัมน์ผอม, scroll ถึงท้ายแต่ละหน้า, พับ/กางเมนู, AUTO ตี 30 ครั้งแล้ว icon สกิล/หลอดเลือดไม่กระพริบผิดปกติ, ใช้ยา HP/MP เห็นค่าสอดคล้อง Supabase, เข้าและออกดันเจียน/บอสโลก, รีเฟรชกลับมาตัวละครเดิม.
5. ถ้าเห็น **ภาพตัวละครกล่องสีดำฝังอยู่ใน asset จริง** (ไม่ใช่หน้าจอเกมเก่า) แพตช์นี้จะจัดขนาดแต่ไม่สามารถตัดสีพื้นของรูปออกได้ ต้องตรวจไฟล์ asset/frame ที่ให้ภาพนั้นโดยเฉพาะ แพตช์นี้ไม่แอบซ่อนตัวละครเพื่อกลบอาการ.

## การย้อนกลับ

ใช้คำสั่งต่อไปนี้ **เฉพาะถ้าคอมมิต V30.6 เป็นคอมมิตล่าสุดและไม่เคยแก้งานอื่นเพิ่มหลังลง**:

```bash
git revert HEAD
git push origin main
```

หรือเปิด `index.html` ลบบรรทัด `<script src="./v306_mobile_layout_stability.js?v=306_mobile_stability_1"></script>` แล้ว commit/push (โค้ดเกมหลักไม่ถูกแตะ).

**ข้อจำกัดการยืนยัน:** `node --check` ยืนยันไวยากรณ์ JS เท่านั้น ยังไม่ใช่ผลทดสอบ end-to-end ใน Chrome มือถือจริง. GitHub connector ปัจจุบันตอบ 403 `Resource not accessible by integration` เมื่อพยายามสร้าง backup branch จึงยังไม่ได้ push จาก ChatGPT โดยตรง.
