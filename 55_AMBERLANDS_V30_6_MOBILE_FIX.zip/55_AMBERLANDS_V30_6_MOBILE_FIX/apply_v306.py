#!/usr/bin/env python3
"""55 AMBERLANDS V30.6: safe, idempotent deployment into Codespaces checkout.
Presentation-only. Never interacts with Supabase, SQL or user saves.
"""
import argparse, hashlib, shutil, subprocess, sys
from pathlib import Path

OLD_TAG = '<script src="./v305_visual_fix.js?v=305_layout_fixed_1"></script>'
NEW_TAG = '<script src="./v306_mobile_layout_stability.js?v=306_mobile_stability_1"></script>'

def main():
    parser = argparse.ArgumentParser(description="Apply V30.6 responsive game/skill/HUD patch")
    parser.add_argument('--repo', default='.', help='root directory containing index.html')
    parser.add_argument('--check', action='store_true', help='verify syntax/patch state without changing files')
    args = parser.parse_args()
    root = Path(args.repo).resolve()
    src = Path(__file__).resolve().parent / 'v306_mobile_layout_stability.js'
    index = root / 'index.html'
    dst = root / src.name
    if not index.is_file():
        sys.exit('ERROR: ไม่พบ index.html ในโฟลเดอร์เกม (ใช้ --repo /path/to/repo)')
    if not src.is_file():
        sys.exit('ERROR: ไม่พบ v306_mobile_layout_stability.js ใน ZIP')
    original = index.read_text(encoding='utf-8')
    if original.count(NEW_TAG) > 1:
        sys.exit('ERROR: พบ v306 script มากกว่า 1 จุด ต้องตรวจ index.html ก่อน')
    if OLD_TAG not in original and NEW_TAG not in original:
        sys.exit('ERROR: ไม่พบ V30.5 script tag ที่คาดไว้ — หยุดเพื่อไม่ทับเวอร์ชันอื่น')
    if original.count(OLD_TAG) != 1:
        sys.exit('ERROR: V30.5 script tag ไม่ตรง 1 จุด — หยุดแก้ไฟล์')
    node = shutil.which('node')
    if node:
        ck = subprocess.run([node, '--check', str(src)], capture_output=True, text=True)
        if ck.returncode:
            sys.exit('ERROR: JavaScript syntax check failed:\n' + ck.stderr)
    else:
        print('WARN: ไม่มี Node.js จึงข้าม JavaScript syntax check')
    target = original if NEW_TAG in original else original.replace(OLD_TAG, OLD_TAG + '\n' + NEW_TAG, 1)
    assert target.count(NEW_TAG) == 1
    print('Repository:', root)
    print('Index change:', 'already installed' if target == original else 'add one V30.6 <script> after V30.5')
    print('JS bytes:', src.stat().st_size)
    if args.check:
        print('PASS: dry verification; no files changed')
        return
    if target != original:
        backup_dir = root / '.amber-v306-local-backup'
        backup_dir.mkdir(exist_ok=True)
        digest = hashlib.sha256(original.encode('utf-8')).hexdigest()[:12]
        backup = backup_dir / ('index.' + digest + '.html.bak')
        if not backup.exists():
            shutil.copy2(index, backup)
        index.write_text(target, encoding='utf-8')
        print('Backup:', backup)
    if not dst.is_file() or dst.read_bytes() != src.read_bytes():
        shutil.copy2(src, dst)
    print('PASS: applied. Next: git diff --check && git add index.html v306_mobile_layout_stability.js && git commit ... && git push')

if __name__ == '__main__':
    main()
