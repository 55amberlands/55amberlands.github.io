-- 55 AMBERLANDS V27.3.3 | SAFE BOSS COMBAT SNAPSHOT
-- Run ONLY after V27.3 server SQL. No deletion, no data reset, no change to reward functions.
-- The world-boss damage is computed by PostgreSQL using equipped gear and
-- allocated STR/DEX/INT/VIT/AGI/LUK according to existing V9/V12 formulas.
-- Important security limitation: the underlying character save is still
-- client-editable while strict_saves is OFF. This patch blocks client-passed
-- damage and freezes a validated snapshot, but cannot certify item provenance.

BEGIN;

-- Snapshot players before production beta schema/function changes. Never touch
-- the existing 2026-10-25 backup; this captures newer characters too.
CREATE TABLE IF NOT EXISTS private.amber_characters_backup_20261025_v2733 AS
SELECT * FROM public.amber_characters;
ALTER TABLE private.amber_characters_backup_20261025_v2733 ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE private.amber_characters_backup_20261025_v2733 FROM PUBLIC,anon,authenticated;

ALTER TABLE public.amber_v273_fighters
  ADD COLUMN IF NOT EXISTS atk_snapshot integer NOT NULL DEFAULT 155,
  ADD COLUMN IF NOT EXISTS def_snapshot integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS crit_snapshot numeric(6,5) NOT NULL DEFAULT 0.07,
  ADD COLUMN IF NOT EXISTS accuracy_snapshot numeric(6,5) NOT NULL DEFAULT 0.81,
  ADD COLUMN IF NOT EXISTS skill_power_snapshot numeric(6,3) NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS skill_mp_snapshot integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS equip_count_snapshot integer NOT NULL DEFAULT 0;

-- Strict scalar parser: numeric JSON/text only, clamped to an explicit cap.
CREATE OR REPLACE FUNCTION private.amber_v2733_int(p_json jsonb, p_default integer, p_max integer)
RETURNS integer LANGUAGE plpgsql IMMUTABLE SET search_path = '' AS $$
DECLARE s text; x bigint;
BEGIN
 IF p_json IS NULL OR jsonb_typeof(p_json) NOT IN ('number','string') THEN RETURN p_default; END IF;
 s := p_json #>> '{}';
 IF s IS NULL OR s !~ '^[0-9]{1,9}$' THEN RETURN p_default; END IF;
 x := s::bigint;
 RETURN least(greatest(x,0),p_max)::integer;
END $$;
REVOKE ALL ON FUNCTION private.amber_v2733_int(jsonb,integer,integer) FROM PUBLIC,anon,authenticated;

CREATE OR REPLACE FUNCTION private.amber_v2733_profile(p_save jsonb)
RETURNS jsonb LANGUAGE plpgsql STABLE SET search_path = '' AS $$
DECLARE
 lvl integer; job text; stats jsonb; added jsonb; g jsonb; gear jsonb;
 bonus jsonb := '{}'::jsonb;
 sl text; item_id text; k text; item_val jsonb; opt jsonb; optkey text;
 val numeric; scale numeric; item_lv integer; req_lv integer; enh integer;
 b_str numeric; b_dex numeric; b_int numeric; b_vit numeric;
 b_agi numeric; b_luk numeric; b_atk numeric; b_def numeric; b_hp numeric; b_mp numeric; b_crit numeric;
 ds numeric; dd numeric; di numeric; dv numeric; da numeric; dl numeric;
 s_str numeric; s_dex numeric; s_int numeric; s_vit numeric; s_agi numeric; s_luk numeric;
 e_str numeric; e_dex numeric; e_int numeric; e_vit numeric; e_agi numeric; e_luk numeric;
 raw_extra numeric; level_extra numeric; factor numeric;
 gear_count integer := 0; base_obj jsonb; opts jsonb;
 sid text; parts text[]; i integer; need_stat numeric; stat_for_skill numeric;
 best_skill numeric := 1; best_mp integer := 0;
 total_atk integer; total_def integer; total_hp integer; total_mp integer;
 total_crit numeric; total_accuracy numeric;
BEGIN
 IF p_save IS NULL OR jsonb_typeof(p_save) <> 'object' THEN
   RAISE EXCEPTION 'v2733_character_save_missing';
 END IF;
 lvl := private.amber_v2733_int(p_save->'lv',1,100);
 job := coalesce(p_save->>'job','นักผจญภัย');
 IF job NOT IN ('ดาบ','หมัด','ธนู','จอมเวท','นักผจญภัย') THEN job := 'นักผจญภัย'; END IF;
 stats := CASE WHEN jsonb_typeof(p_save->'stats')='object' THEN p_save->'stats' ELSE '{}'::jsonb END;
 added := CASE WHEN jsonb_typeof(p_save->'_ad')='object' THEN p_save->'_ad' ELSE '{}'::jsonb END;
 gear := CASE WHEN jsonb_typeof(p_save->'gear')='array' THEN p_save->'gear' ELSE '[]'::jsonb END;

 -- Only an actual equipped item ID contributes: inventory-only items are ignored.
 FOREACH sl IN ARRAY ARRAY['W','S','G','B','R'] LOOP
   item_id := p_save->'eq'->>sl;
   IF item_id IS NULL OR length(item_id)>80 THEN CONTINUE; END IF;
   g := NULL;
   SELECT it.elem INTO g
   FROM jsonb_array_elements(gear) AS it(elem)
   WHERE it.elem->>'id'=item_id AND it.elem->>'slot'=sl LIMIT 1;
   IF g IS NULL OR jsonb_typeof(g)<>'object' THEN CONTINUE; END IF;
   IF g->>'cls' IS NOT NULL AND g->>'cls' <> job THEN CONTINUE; END IF;
   item_lv := private.amber_v2733_int(g->'lv',1,100);
   req_lv := private.amber_v2733_int(g->'req',1,100);
   IF req_lv > lvl THEN CONTINUE; END IF;
   -- Keep the game's upgrade multiplier exactly: 1 + 0.12 * enhancement.
   enh := private.amber_v2733_int(g->'enh',0,10);
   scale := 1 + enh * 0.12;
   gear_count := gear_count + 1;
   base_obj := CASE WHEN jsonb_typeof(g->'base')='object' THEN g->'base' ELSE '{}'::jsonb END;
   opts := CASE WHEN jsonb_typeof(g->'opts')='array' THEN g->'opts' ELSE '[]'::jsonb END;
   FOR k,item_val IN SELECT key,value FROM jsonb_each(base_obj) LOOP
     IF k NOT IN ('STR','DEX','INT','VIT','AGI','LUK','ATK','DEF','HP','MP','CRIT') THEN CONTINUE; END IF;
     val := private.amber_v2733_int(item_val,0,
       CASE WHEN k='CRIT' THEN 30 ELSE least(10000,200+item_lv*60) END);
     bonus := jsonb_set(bonus,ARRAY[k],to_jsonb(coalesce((bonus->>k)::numeric,0)+val*scale),true);
   END LOOP;
   FOR opt IN SELECT value FROM jsonb_array_elements(opts) LIMIT 4 LOOP
     IF jsonb_typeof(opt)<>'array' OR jsonb_array_length(opt)<2 THEN CONTINUE; END IF;
     optkey := opt->>0;
     IF optkey NOT IN ('STR','DEX','INT','VIT','AGI','LUK','ATK','DEF','HP','MP','CRIT') THEN CONTINUE; END IF;
     val := private.amber_v2733_int(opt->1,0,
       CASE WHEN optkey='CRIT' THEN 30 ELSE least(10000,200+item_lv*60) END);
     bonus := jsonb_set(bonus,ARRAY[optkey],to_jsonb(coalesce((bonus->>optkey)::numeric,0)+val*scale),true);
   END LOOP;
 END LOOP;
 b_str:=coalesce((bonus->>'STR')::numeric,0);b_dex:=coalesce((bonus->>'DEX')::numeric,0);
 b_int:=coalesce((bonus->>'INT')::numeric,0);b_vit:=coalesce((bonus->>'VIT')::numeric,0);
 b_agi:=coalesce((bonus->>'AGI')::numeric,0);b_luk:=coalesce((bonus->>'LUK')::numeric,0);
 b_atk:=coalesce((bonus->>'ATK')::numeric,0);b_def:=coalesce((bonus->>'DEF')::numeric,0);
 b_hp:=coalesce((bonus->>'HP')::numeric,0);b_mp:=coalesce((bonus->>'MP')::numeric,0);
 b_crit:=coalesce((bonus->>'CRIT')::numeric,0);
 -- Reproduce V9 ap(): STR is boosted by ATK/1.45 and by half class focus stat.
 dd:=round(b_dex);di:=round(b_int);dv:=round(b_vit+b_def/0.65);
 da:=round(b_agi);dl:=round(b_luk+b_crit*10);
 ds:=round(b_str+b_atk/1.45 + CASE job WHEN 'ธนู' THEN b_dex*.5 WHEN 'จอมเวท' THEN b_int*.5 WHEN 'หมัด' THEN b_agi*.5 ELSE 0 END);

 s_str:=private.amber_v2733_int(stats->'STR',15,5000);
 s_dex:=private.amber_v2733_int(stats->'DEX',12,5000);
 s_int:=private.amber_v2733_int(stats->'INT',5,5000);
 s_vit:=private.amber_v2733_int(stats->'VIT',10,5000);
 s_agi:=private.amber_v2733_int(stats->'AGI',8,5000);
 s_luk:=private.amber_v2733_int(stats->'LUK',5,5000);

 -- Cloud saves may include already-applied equipment bonuses and the V9
 -- '_ad' marker. Subtract them only if they match the recalculated gear.
 IF jsonb_typeof(p_save->'_ad')='object'
    AND abs(private.amber_v2733_int(added->'STR',0,50000)-ds)<=1
    AND abs(private.amber_v2733_int(added->'DEX',0,50000)-dd)<=1
    AND abs(private.amber_v2733_int(added->'INT',0,50000)-di)<=1
    AND abs(private.amber_v2733_int(added->'VIT',0,50000)-dv)<=1
    AND abs(private.amber_v2733_int(added->'AGI',0,50000)-da)<=1
    AND abs(private.amber_v2733_int(added->'LUK',0,50000)-dl)<=1
 THEN
    s_str:=greatest(15,s_str-ds);s_dex:=greatest(12,s_dex-dd);
    s_int:=greatest(5,s_int-di);s_vit:=greatest(10,s_vit-dv);
    s_agi:=greatest(8,s_agi-da);s_luk:=greatest(5,s_luk-dl);
 END IF;

 -- Reject impossible invested points without changing the player's save.
 s_str:=greatest(15,s_str);s_dex:=greatest(12,s_dex);
 s_int:=greatest(5,s_int);s_vit:=greatest(10,s_vit);
 s_agi:=greatest(8,s_agi);s_luk:=greatest(5,s_luk);
 raw_extra := (s_str-15)+(s_dex-12)+(s_int-5)+(s_vit-10)+(s_agi-8)+(s_luk-5);
 level_extra := (lvl-1)*5;
 IF raw_extra>level_extra AND raw_extra>0 THEN
   factor:=level_extra/raw_extra;
   s_str:=15+floor((s_str-15)*factor);s_dex:=12+floor((s_dex-12)*factor);
   s_int:=5+floor((s_int-5)*factor);s_vit:=10+floor((s_vit-10)*factor);
   s_agi:=8+floor((s_agi-8)*factor);s_luk:=5+floor((s_luk-5)*factor);
 END IF;
 e_str:=s_str+ds;e_dex:=s_dex+dd;e_int:=s_int+di;
 e_vit:=s_vit+dv;e_agi:=s_agi+da;e_luk:=s_luk+dl;

 -- V12 combat().atk uses effective stats (with equipped V9 bonuses).
 total_atk := greatest(1,least(15000,round(12+lvl*2.8+e_str*1.45+
   CASE job WHEN 'ดาบ' THEN e_str*.42 WHEN 'หมัด' THEN e_agi*.96
   WHEN 'ธนู' THEN e_dex*1.03 WHEN 'จอมเวท' THEN e_int*1.08 ELSE 0 END)::integer));
 total_def := greatest(0,least(20000,round(lvl*.45+e_vit*.65)::integer));
 total_crit := least(.48,greatest(0,.07+e_luk*.0024));
 total_accuracy := least(.985,greatest(.2,.81+e_dex*.0027));
 total_hp := greatest(1,least(100000,round(250+(lvl-1)*48 + b_hp + greatest(0,(e_vit-10)*8))::integer));
 total_mp := greatest(1,least(100000,round(120+(lvl-1)*17+e_int*2-10+b_mp+greatest(0,(e_int-5)*3))::integer));

 -- One eligible, already-learned offensive skill, selected SERVER-SIDE.
 IF jsonb_typeof(p_save->'learned')='array' THEN
   FOR sid IN SELECT value FROM jsonb_array_elements_text(p_save->'learned') AS q(value) LIMIT 120 LOOP
     parts:=regexp_match(sid,'^(.+)_(POWER|DEX|INT)_([0-9])$');
     IF parts IS NULL OR parts[1]<>job THEN CONTINUE; END IF;
     i:=parts[3]::integer;
     IF i IN (2,5) OR lvl<(CASE WHEN i=0 THEN 1 ELSE i*10-3 END) THEN CONTINUE; END IF;
     need_stat:=5+i*7;
     stat_for_skill:=CASE parts[2] WHEN 'POWER' THEN e_str WHEN 'DEX' THEN e_dex ELSE e_int END;
     IF stat_for_skill<need_stat THEN CONTINUE; END IF;
     IF best_skill < 1.2+i*.21 THEN
       best_skill:=1.2+i*.21;best_mp:=6+i*4;
     END IF;
   END LOOP;
 END IF;
 RETURN jsonb_build_object('lv',lvl,'atk',total_atk,'def',total_def,
  'crit',round(total_crit,5),'accuracy',round(total_accuracy,5),
  'hp',total_hp,'mp',total_mp,'skill_power',round(best_skill,3),
  'skill_mp',best_mp,'equipment_count',gear_count,'source','server_equipped_save_snapshot');
END $$;
REVOKE ALL ON FUNCTION private.amber_v2733_profile(jsonb) FROM PUBLIC,anon,authenticated;

create or replace function public.amber_v273_status(p_event_key text default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare
  u uuid := auth.uid(); s jsonb; k text; e public.amber_v273_events%rowtype;
  f public.amber_v273_fighters%rowtype; top_rows jsonb;
begin
  if u is null then return jsonb_build_object('ok',false,'reason','login_required'); end if;
  s := private.amber_v273_slot(); k := coalesce(p_event_key,s->>'key');
  if k !~ '^20[0-9]{2}-[0-9]{2}-[0-9]{2}T(00|03|06|09|12|15|18|21)$' then
    return jsonb_build_object('ok',false,'reason','invalid_event');
  end if;
  select * into e from public.amber_v273_events where event_key=k;
  select * into f from public.amber_v273_fighters where event_key=k and user_id=u;
  select coalesce(jsonb_agg(jsonb_build_object('name',r.nickname,'damage',r.damage,'rank',r.rn)), '[]'::jsonb)
  into top_rows from (
    select nickname,damage,row_number() over(order by damage desc, joined_at, user_id) as rn
    from public.amber_v273_fighters where event_key=k and damage>0
    order by damage desc,joined_at,user_id limit 10
  ) r;
  return jsonb_build_object('ok',true,'event_key',k,'open',(s->>'key')=k and (s->>'open')::boolean,
    'next_slot_hour_bkk',(floor(extract(hour from (now() at time zone 'Asia/Bangkok'))/3)::int*3 + 3)%24,
    'boss_max_hp',coalesce(e.max_hp,14000),'boss_hp',coalesce(e.hp,14000),
    'defeated',e.defeated_at is not null,
    'joined',f.user_id is not null,'my_damage',coalesce(f.damage,0),
    'my_attacks',coalesce(f.attacks,0),'my_hp',f.hp,'my_max_hp',f.max_hp,
    'my_mp',f.mp,'my_max_mp',f.max_mp,'hp_pots',f.hp_pots,'mp_pots',f.mp_pots,
    'my_atk',f.atk_snapshot,'my_def',f.def_snapshot,'my_skill_multiplier',f.skill_power_snapshot,
    'my_equipped_count',f.equip_count_snapshot,
    'ranking',top_rows,
    'claimed',exists(select 1 from public.amber_ac_claims q where q.user_id=u and q.kind='worldboss_v273' and q.period=k),
    'server_time',now());
end $$;

-- Join keeps the exact deployed RPC name and params, but snapshots server-read gear.
CREATE OR REPLACE FUNCTION public.amber_v273_join()
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE
  u uuid := auth.uid(); s jsonb; k text; e public.amber_v273_events%ROWTYPE;
  c jsonb; prof jsonb; lvl int; mn text; hp_pots int; mp_pots int;
BEGIN
  IF u IS NULL THEN RETURN jsonb_build_object('ok',false,'reason','login_required'); END IF;
  s := private.amber_v273_slot();
  IF NOT (s->>'open')::boolean THEN RETURN jsonb_build_object('ok',false,'reason','event_closed'); END IF;
  k := s->>'key';
  SELECT save_data INTO c FROM public.amber_characters WHERE user_id=u;
  IF c IS NULL THEN RETURN jsonb_build_object('ok',false,'reason','character_missing'); END IF;
  prof := private.amber_v2733_profile(c);
  lvl := (prof->>'lv')::int;
  mn := left(coalesce(nullif(c->>'name',''),'ผู้เล่น'),24);
  hp_pots := private.amber_v2733_int(c->'potHP',0,9999);
  mp_pots := private.amber_v2733_int(c->'potMP',0,9999);
  INSERT INTO public.amber_v273_events(event_key,starts_at,closes_at,max_hp,hp)
  VALUES(k,(s->>'starts_at')::timestamptz,(s->>'closes_at')::timestamptz,14000,14000)
  ON CONFLICT(event_key) DO NOTHING;
  SELECT * INTO e FROM public.amber_v273_events WHERE event_key=k FOR UPDATE;
  IF e.defeated_at IS NOT NULL THEN RETURN jsonb_build_object('ok',false,'reason','boss_already_defeated'); END IF;
  INSERT INTO public.amber_v273_fighters(event_key,user_id,nickname,level_snapshot,max_hp,hp,max_mp,mp,hp_pots,mp_pots,
    atk_snapshot,def_snapshot,crit_snapshot,accuracy_snapshot,skill_power_snapshot,skill_mp_snapshot,equip_count_snapshot)
  VALUES(k,u,mn,lvl,(prof->>'hp')::integer,(prof->>'hp')::integer,
    (prof->>'mp')::integer,(prof->>'mp')::integer,hp_pots,mp_pots,
    (prof->>'atk')::integer,(prof->>'def')::integer,(prof->>'crit')::numeric,
    (prof->>'accuracy')::numeric,(prof->>'skill_power')::numeric,
    (prof->>'skill_mp')::integer,(prof->>'equipment_count')::integer)
  ON CONFLICT(event_key,user_id) DO NOTHING;
  RETURN public.amber_v273_status(k);
END $$;

create or replace function public.amber_v273_attack(p_skill boolean default false, p_auto_potion boolean default true)
returns jsonb language plpgsql security definer set search_path='' as $$
declare
  u uuid := auth.uid(); s jsonb; k text; e public.amber_v273_events%rowtype;
  f public.amber_v273_fighters%rowtype; c jsonb; attack_damage int := 0;
  incoming int := 0; now_time timestamptz := clock_timestamp();
  allow_skill boolean := false; hp_used boolean := false; mp_used boolean := false;
  old_stock int;
begin
  if u is null then return jsonb_build_object('ok',false,'reason','login_required'); end if;
  s := private.amber_v273_slot(); k := s->>'key';
  -- Serialize global boss updates. Cooldown enforced on the server for all devices.
  select * into e from public.amber_v273_events where event_key=k for update;
  if e.event_key is null then return jsonb_build_object('ok',false,'reason','event_not_joined'); end if;
  select * into f from public.amber_v273_fighters where event_key=k and user_id=u for update;
  if f.user_id is null then return jsonb_build_object('ok',false,'reason','player_not_joined'); end if;
  if e.defeated_at is not null or not (s->>'open')::boolean then
    return jsonb_build_object('ok',true,'event_key',k,'defeated',e.defeated_at is not null,
      'boss_hp',e.hp,'boss_max_hp',e.max_hp,'my_hp',f.hp,'my_max_hp',f.max_hp,
      'my_mp',f.mp,'my_max_mp',f.max_mp,'my_damage',f.damage,'my_attacks',f.attacks,
      'hp_pots',f.hp_pots,'mp_pots',f.mp_pots,'hit_damage',0,'incoming_damage',0,'ended',true);
  end if;
  if f.last_attack is not null and now_time-f.last_attack < interval '850 milliseconds' then
    return jsonb_build_object('ok',false,'reason','cooldown');
  end if;
  if f.hp <= 0 then return jsonb_build_object('ok',false,'reason','player_defeated','my_hp',0); end if;
  -- V27.3.3: PostgreSQL calculates each hit from the equipped V9/V12
  -- combat snapshot stored on join. The client cannot submit ATK or damage.
  -- Server-sided hit / crit rolls. Cooldown, ranking and global boss HP are unchanged.
  IF random() > greatest(.2,least(.985,f.accuracy_snapshot)) THEN
    attack_damage := 0;
    allow_skill := false;
  ELSE
    allow_skill := coalesce(p_skill,false) and f.skill_power_snapshot > 1
      and f.skill_mp_snapshot > 0 and f.mp >= f.skill_mp_snapshot and
      (f.last_skill is null or now_time-f.last_skill >= interval '4 seconds');
    attack_damage := round(f.atk_snapshot * (0.92 + (f.attacks % 9)*.02) *
      CASE WHEN allow_skill THEN f.skill_power_snapshot ELSE 1 END)::integer;
    IF random() < greatest(0,least(.48,f.crit_snapshot)) THEN
      attack_damage := round(attack_damage*1.8)::integer;
    END IF;
    attack_damage := least(greatest(1,attack_damage),e.hp::integer);
  END IF;
  incoming := greatest(1,8 + (f.attacks % 7) - floor(f.def_snapshot/100.0)::integer);
  f.mp := f.mp - CASE WHEN allow_skill THEN f.skill_mp_snapshot ELSE 0 END;
  f.hp := greatest(0, f.hp - incoming);
  if allow_skill then f.last_skill := now_time; end if;
  if coalesce(p_auto_potion,false) and (f.hp <= f.max_hp*45/100 or f.mp <= f.max_mp/100*20) then
    -- Row lock and DB decrement ensure only genuinely stocked potions work.
    select save_data into c from public.amber_characters where user_id=u for update;
    if f.hp <= f.max_hp*45/100 and f.hp_pots>0 and (c->>'potHP') ~ '^[0-9]{1,6}$' then
      old_stock := (c->>'potHP')::int;
      if old_stock>0 then
        c := jsonb_set(c,'{potHP}',to_jsonb(old_stock-1),true);
        f.hp_pots := f.hp_pots-1;
        f.hp := least(f.max_hp,f.hp+ceil(f.max_hp*.45)::int);
        hp_used := true;
      end if;
    end if;
    if f.mp <= f.max_mp*20/100 and f.mp_pots>0 and (c->>'potMP') ~ '^[0-9]{1,6}$' then
      old_stock := (c->>'potMP')::int;
      if old_stock>0 then
        c := jsonb_set(c,'{potMP}',to_jsonb(old_stock-1),true);
        f.mp_pots := f.mp_pots-1;
        f.mp := least(f.max_mp,f.mp+ceil(f.max_mp*.5)::int);
        mp_used := true;
      end if;
    end if;
    if hp_used or mp_used then
      update public.amber_characters set save_data=c,updated_at=now_time where user_id=u;
    end if;
  end if;
  -- Attacks exchange damage even if this server hit also knocks the player out.
  update public.amber_v273_events set hp=greatest(0,e.hp-attack_damage),
      defeated_at=case when e.hp<=attack_damage then now_time else defeated_at end
    where event_key=k;
  update public.amber_v273_fighters set
    damage=f.damage+attack_damage, attacks=f.attacks+1,
    hp=f.hp,mp=f.mp,last_attack=now_time,last_skill=f.last_skill,
    hp_pots=f.hp_pots,mp_pots=f.mp_pots
    where event_key=k and user_id=u;
  return jsonb_build_object('ok',true,'event_key',k,'boss_max_hp',e.max_hp,
    'boss_hp',greatest(0,e.hp-attack_damage),'defeated',e.hp<=attack_damage,
    'my_hp',f.hp,'my_max_hp',f.max_hp,'my_mp',f.mp,'my_max_mp',f.max_mp,
    'my_damage',f.damage+attack_damage,'my_attacks',f.attacks+1,
    'my_atk',f.atk_snapshot,'my_def',f.def_snapshot,
    'hit_damage',attack_damage,'incoming_damage',incoming,
    'used_skill',allow_skill,'used_hp_pot',hp_used,'used_mp_pot',mp_used,
    'hp_pots',f.hp_pots,'mp_pots',f.mp_pots);
end $$;

COMMIT;

-- Read-only verification, run separately after installation:
-- SELECT pg_get_function_identity_arguments(p.oid),p.proname FROM pg_proc p
-- JOIN pg_namespace n ON n.oid=p.pronamespace
-- WHERE n.nspname='public' AND p.proname IN ('amber_v273_join','amber_v273_attack');
