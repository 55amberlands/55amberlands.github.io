#!/usr/bin/env python3
"""Safe install of V27.3.3 World Boss party layout, with two guarded baselines."""
from pathlib import Path
import hashlib,json,shutil,subprocess,tempfile,os
here=Path(__file__).resolve().parent
project=here.parent
m=json.loads((here/'manifest.json').read_text(encoding='utf-8'))
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
if not (project/'index.html').is_file():
    raise SystemExit('STOP: ZIP ต้องแตกในโฟลเดอร์หลักเดียวกับ index.html')
for name,expected in m['payload_hashes'].items():
    if sha(here/name)!=expected:
        raise SystemExit('STOP: ZIP payload ผิด hash: '+name)
dst=project/m['game_file']
current=sha(dst)
if current in (m['payload_hashes']['files/v26_realtime.js'], m['payload_hashes']['files/v26_realtime_from_v2732.js']):
    print('OK: V27.3.3 UI already installed; no files overwritten.')
    raise SystemExit(0)
base=next((b for b in m['supported_bases'] if b['sha256']==current),None)
if not base:
    raise SystemExit('STOP: ไม่ตรงกับ V27.3.1 / V27.3.2 ที่ตรวจแล้ว (SHA='+str(current)+'). ห้ามเขียนทับ')
src=here/base['payload']
subprocess.run(['node','--check',str(src)],check=True)
backup=Path(tempfile.mkdtemp(prefix='amber_before_v2733_',dir=str(project.parent)))
shutil.copy2(dst,backup/m['game_file'])
tmp=dst.with_suffix('.v2733_tmp')
try:
    shutil.copy2(src,tmp)
    os.replace(tmp,dst)
    if sha(dst)!=sha(src):raise RuntimeError('Installed file hash mismatch')
    subprocess.run(['node','--check',str(dst)],check=True)
except Exception as exc:
    if tmp.exists(): tmp.unlink()
    shutil.copy2(backup/m['game_file'],dst)
    raise SystemExit('ERROR: Reverted to '+base['version']+' because: '+str(exc))
print('SUCCESS: V27.3.3 installed over '+base['version']+'.')
print('Changed exactly one game file: v26_realtime.js')
print('Backup folder:',backup)
print('NEXT: Apply SQL/55_AMBERLANDS_V27_3_3_SERVER_COMBAT.sql in Supabase SQL Editor.')
print('Test on Codespaces Port 8000 BEFORE git push.')
