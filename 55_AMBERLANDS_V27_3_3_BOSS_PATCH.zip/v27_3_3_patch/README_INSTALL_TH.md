# 55 AMBERLANDS V27.3.3 — World Boss Party + Actual Equipment Damage

**ติดตั้งต่อจาก V27.3.1 หรือ V27.3.2** ใน Codespaces เดิม ไม่ต้องลง SQL V27.3 เก่าใหม่ ไม่ต้องลบ V27.1–V27.3 หรือเปลี่ยนฐานข้อมูลเซฟเดิม

## แก้จริง
1. แถวปาร์ตี้ในห้องซ้อมและห้องบอสจริงเป็นพื้นที่ scroll **ไม่ซ่อนครึ่งบน** ของตัวละคร เปิดดูทุกแถวได้โดยเลื่อนในพื้นที่ปาร์ตี้; ลดความสูงรูปบอสบนมือถือเพียงเล็กน้อย
2. ตัวละครของผู้เล่นเองไม่หายระหว่างสู้จากการหมดเวลา presence 14 วินาที
3. RPC `amber_v273_join` อ่าน **สถานะและอุปกรณ์ที่สวมจริงจากเซฟของบัญชี** ตั้งแต่เข้าร่วม แล้วคำนวณสูตร **V9 + V12** บน PostgreSQL: Lv, STR/DEX/INT/AGI, โบนัส base/opts, ตีบวก x(1+0.12×enh), สกิลที่เรียนไว้, CRIT, HIT, DEF, HP, MP. เก็บ snapshot คงที่ตลอดรอบสู้ และโชว์ ATK ที่เซิร์ฟเวอร์คำนวณในแถบล่าง
4. RPC `amber_v273_attack` ใช้ ATK snapshot; **ไม่รับ ATK/damage/rank จากมือถือ**, cooldown คงเดิม; เปลี่ยนชื่อหรืออาวุธระหว่างรอบจะไม่มีผลจนเข้ารอบบอสถัดไป
5. **ไม่แก้** สูตรรางวัล, ข้อมูลเช็กอิน, SQL strict flags, Market, ปาร์ตี้เกมหลัก, แมป หรือไอเทมผู้เล่น

## คำเตือนเรื่อง Anti-Cheat
เซิร์ฟเวอร์คำนวณดาเมจจากข้อมูล save ที่อยู่ใน DB พร้อมตรวจ ID อุปกรณ์/ช่องสวม/อาชีพ/ระดับและขอบเขตค่าสเตตัส แต่ **เกมหลักยังให้มือถือบันทึกเซฟได้** จึงยังไม่สามารถรับรองที่มาของอาวุธ/ค่าสถานะได้ 100%. ต้องมีระบบ item provenance ฝั่ง server และ strict saves ที่ทดสอบแยกก่อนจึงจะเป็น authoritative เต็มระบบ. ห้ามเปิด strict_saves ระหว่างขั้นตอนนี้.

## ติดตั้ง
1. อัปโหลด `55_AMBERLANDS_V27_3_3_BOSS_PATCH.zip` ผ่าน GitHub > Add file > Upload files > Commit changes
2. กลับ Codespaces เดิมรัน:

```bash
git fetch origin
git show origin/main:55_AMBERLANDS_V27_3_3_BOSS_PATCH.zip > 55_AMBERLANDS_V27_3_3_BOSS_PATCH.zip
unzip -o 55_AMBERLANDS_V27_3_3_BOSS_PATCH.zip
python3 v27_3_3_patch/install.py
```

3. **หลังขึ้น SUCCESS** เปิด SQL ภายใน ZIP: `v27_3_3_patch/SQL/55_AMBERLANDS_V27_3_3_SERVER_COMBAT.sql` แล้วคัดลอกไป **Supabase > SQL Editor > New query > Run** (อย่าใช้คำสั่ง SQL เก่า V27.3 ซ้ำ)
4. ทดสอบเกมที่ Codespaces Port 8000: หน้าบอสซ้อม > ปาร์ตี้ทุกแถวต้องครบและเลื่อนได้ > Auto toggle ยังใช้ได้ > ห้องบอสจริงรอบถัดไป ATK / HIT จาก server และ damage ตามอาชีพ+อุปกรณ์; เช็กเซฟตัวละครหลังรีเฟรช
5. ถ้าผ่านจึงนำ JS ขึ้นเว็บจริง:

```bash
node --check v26_realtime.js && git add v26_realtime.js && git diff --cached --check && git commit -m 'V27.3.3 Fix boss party and equipment damage' && git fetch origin && git merge --no-edit origin/main && git push origin main
```

ถ้าขึ้น Merge Conflict หรือคำสั่งติดตั้งแจ้ง STOP **อย่าฝืนเขียนทับ / force push**; ส่งภาพ Error มาแทน

## สำรองข้อมูล
ตัวติดตั้งจะสำรองไฟล์ JavaScript เดิมไว้นอกโฟลเดอร์ Git อัตโนมัติ. SQL สร้างตารางสำรองตัวละครใหม่ใน private ที่เปิด RLS และปิดสิทธิ์ผู้เล่นทั่วไป (เพราะมีผู้เล่นใหม่เพิ่มจากชุดสำรองเก่า) จากนั้นใช้ `ALTER TABLE ADD COLUMN IF NOT EXISTS` / `CREATE OR REPLACE FUNCTION` ไม่ลบ/รีเซ็ตตัวละครหรือรางวัลเดิม และไม่แก้ประวัติการล่าบอสที่ผ่านมา.
