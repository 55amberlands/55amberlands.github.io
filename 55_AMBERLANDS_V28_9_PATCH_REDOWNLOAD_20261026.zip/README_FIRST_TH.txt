55 AMBERLANDS V28.9 — Pet Food, Hunger, Dungeon MISS, Rebirth Server Power
BASE: GitHub V28.7 deployed on main (must match exact SHA; installer stops if different)
SCOPE: 5 browser files; creates 2 secured RPCs + updates existing combat/rebirth functions.
DOES NOT touch assets, layout, maps, other game logic, or delete/reset any player data.

Balance each Rebirth (up to 10):
 ATK +500, DEF +200, max HP +1500, max MP +400, CRIT +0.5%, accuracy +0.5%, EXP +10% (existing),
 fresh stat points 20 + 50*rebirth (new rebirths), new skill points +8 on rebirth.
 Already reborn players get permanent combat/HP/MP bonuses without rebirthing again.
 Existing unspent stat/skill points are not retroactively added; future rebirth uses increased allocation.
 Note: attack damage still depends on boss armor/defense. MISS is a legitimate server roll.

FIRST: SQL V28.9 WAS ALREADY INSTALLED DIRECTLY IN YOUR SUPABASE ON 2026-10-26. DO NOT RUN IT AGAIN.
 Included SQL is only for backup/reference.
 The SQL is atomic for the function replacements; it does NOT update/save any player row during installation.
 DO NOT run if SQL shows signature mismatch; contact developer instead.

THEN: upload this ZIP to GitHub repo root using Add file > Upload files > Commit.
 Open Codespaces terminal, paste these commands:

 set -e
 git pull --ff-only origin main
 unzip -o 55_AMBERLANDS_V28_9_PATCH_REDOWNLOAD_20261026.zip -d .
 python3 install_v289_safe.py --check
 python3 install_v289_safe.py --apply
 python3 tools/check_static_site.py
 git diff --check
 git add index.html v23_pet_shop.js v25_systems.js v12_patch.js v23_dungeon.js
 git commit -m "V28.9 pet bulk food hunger dungeon MISS rebirth bonuses"
 git push origin main

If scripts say STOP: DO NOT override. Do not clear browser cache/localStorage or overwrite game data.

TEST ONLINE (after SQL+GitHub deploy):
 1. Buy food x10; Supabase coins -800 exactly, item qty increases by 10.
 2. Activate dog: hunger updates around 1% every 2 min (0.5% per minute); no client guesses.
 3. Dungeon: a miss shows MISS instead of damage 0, server damage ranking unchanged.
 4. Rebirth UI bonus per rank and real server damage boost should match.
 5. User/characters inventory preserved. No SQL reset or bulk character updates.

IMPORTANT: ZIP CONTAINS THE CLIENT PET SOURCE AND THE INSTALLER. The installer modifies the four other existing JS/HTML files in-place after strict SHA verification, so they are not separate zip entries.
