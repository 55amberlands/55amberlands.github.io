#!/usr/bin/env python3
"""Patch V28.7 deployed game in-place, refusing unexpected GitHub source blobs."""
from pathlib import Path
import subprocess,sys,re,shutil,datetime
root=Path.cwd(); source=Path(__file__).resolve().parent/'v289_patch'
required={'index.html':'d24d1f05ff4fd25580eb34a74d1e4ace70bc17e5',
'v23_pet_shop.js':'a632a87a4205c6b82b36ba8818c2ca2f5ff64a97',
'v25_systems.js':'c307ff88a93ba669deab371d0a0989f3b9d29a31',
'v12_patch.js':'37f9fa0af7fb6e7827ef059dec506b5b02c48c8c',
'v23_dungeon.js':'06359ded285f0b6611625c3f58f6634697c24c3e'}
if '--check' not in sys.argv and '--apply' not in sys.argv:sys.exit('Use --check or --apply')
for fn,sha in required.items():
 path=root/fn
 if not path.is_file():sys.exit('STOP: missing '+fn)
 h=subprocess.check_output(['git','hash-object',str(path)],text=True).strip()
 if h!=sha:sys.exit(f'STOP: {fn} differs from tested V28.7 base (SHA={h}); do not force overwrite')
if not (source/'v23_pet_shop.js').is_file():sys.exit('STOP: missing patch source')

def sub_once(s,old,new,fn):
 if s.count(old)!=1:raise ValueError(f'STOP: {fn} unexpected occurrence count for {old[:65]!r}: {s.count(old)}')
 return s.replace(old,new)

files={fn:(root/fn).read_text(encoding='utf8') for fn in required}
files['v23_pet_shop.js']=(source/'v23_pet_shop.js').read_text(encoding='utf8')
# Existing character stat display uses server-owned equipment stats; mirror permanent rebirth only.
s=files['v12_patch.js']
for old,new in [('+gearAtk+12*rb','+gearAtk+500*rb'),('+gearDef+8*rb','+gearDef+200*rb'),
                ('bound(.81+dex*.0027,.2,.985)','bound(.81+dex*.0027+rb*.005,.2,.985)'),
                ('bound(.07+luk*.0024+gearCrit/100,0,.80)','bound(.07+luk*.0024+gearCrit/100+rb*.005,0,.80)')]:s=sub_once(s,old,new,'v12_patch.js')
files['v12_patch.js']=s
# Existing hub visuals are untouched; update descriptions and passive bonuses.
s=files['v25_systems.js']
s=sub_once(s,"if (v.rebirth) { add('ATK', v.rebirth * 12); add('DEF', v.rebirth * 8); add('HP', v.rebirth * 150); add('MP', v.rebirth * 40); }", "if (v.rebirth) { add('ATK', v.rebirth * 500); add('DEF', v.rebirth * 200); add('HP', v.rebirth * 1500); add('MP', v.rebirth * 400); }",'v25_systems.js')
s=sub_once(s,'ATK+12 DEF+8 HP+150 MP+40 และ EXP+10%', 'ATK+500 DEF+200 HP+1500 MP+400 และ EXP+10%', 'v25_systems.js')
s=sub_once(s,'ATK +12 · DEF +8 · HP +150 · MP +40 · EXP +10%', 'ATK +500 · DEF +200 · HP +1500 · MP +400 · EXP +10%', 'v25_systems.js')
s=sub_once(s,'v.rebirth * 12} · DEF +${v.rebirth * 8} · HP +${v.rebirth * 150}', 'v.rebirth * 500} · DEF +${v.rebirth * 200} · HP +${v.rebirth * 1500}', 'v25_systems.js')
files['v25_systems.js']=s
# Server's out.hit false means MISS, not mysteriously zero damage.
s=files['v23_dungeon.js']
s=sub_once(s,'popDamage(out.damage); // show numeric damage for skills AND basic hits',"popDamage(out.hit===false?'MISS':out.damage); // server-confirmed miss, no fake damage",'v23_dungeon.js')
s=sub_once(s,"d.textContent='-'+fmt(n);sc.appendChild(d);", "d.textContent=n==='MISS'?'MISS':'-'+fmt(n);sc.appendChild(d);",'v23_dungeon.js')
files['v23_dungeon.js']=s
# URL version pins only: no HTML layout, styles or other game content changed.
s=files['index.html']
for file in ['v23_pet_shop.js','v25_systems.js','v12_patch.js','v23_dungeon.js']:
 rx=r'('+re.escape(file)+r'\?v=)[^"\']+'
 s,n=re.subn(rx,r'\g<1>289_pet_rebirth',s)
 if n!=1:raise ValueError(f'STOP: index.html expected one script tag for {file}: {n}')
files['index.html']=s
# client JS parse check before writing *anything*.
import tempfile
with tempfile.TemporaryDirectory() as td:
 for fn in files:
  if fn.endswith('.js'):
   f=Path(td)/fn;f.write_text(files[fn],encoding='utf8')
   subprocess.run(['node','--check',str(f)],check=True)
print('PASS: base SHA for 5 production files, patch substitutions and JS parser')
if '--apply' not in sys.argv:
 print('PASS: check-only; no changes made');sys.exit(0)
backup=root/('.v289_backup_'+datetime.datetime.utcnow().strftime('%Y%m%d_%H%M%S'))
backup.mkdir()
for fn in required:shutil.copy2(root/fn,backup/fn)
for fn,contents in files.items():(root/fn).write_text(contents,encoding='utf8')
print('PASS: updated',', '.join(files))
print('BACKUP:',backup)
print('NOTE: V28.9 SQL was already installed in Supabase; do not run SQL again.')
