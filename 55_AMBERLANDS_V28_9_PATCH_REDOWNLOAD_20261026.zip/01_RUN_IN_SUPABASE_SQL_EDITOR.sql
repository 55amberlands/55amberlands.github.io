-- 55 AMBERLANDS V28.9: pet food/hunger + shared combat hit chance + rebirth bonuses
-- First deploy: SQL editor run ONCE. SQL functions only; no player rows explicitly modified.
BEGIN;
DO $v289_install$
DECLARE oid_found oid; code text;
BEGIN
  -- private.amber_v285_combat_stats
  SELECT p.oid INTO oid_found FROM pg_catalog.pg_proc p JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='private' AND p.proname='amber_v285_combat_stats' AND p.prokind='f';
  IF oid_found IS NULL THEN RAISE EXCEPTION 'V289_MISSING_FUNCTION: %', 'private.amber_v285_combat_stats'; END IF;
  code:=pg_catalog.pg_get_functiondef(oid_found);
  IF position($v289_0_0$12+lv*2.8+strn*1.45+focus+atk_bonus+least(10,greatest(0,coalesce((p_save#>>'{v25,rebirth}')::int,0)))*500$v289_0_0$ IN code)>0 THEN
    NULL; -- already installed (check replacement FIRST: original can be prefix)
  ELSIF (length(code)-length(replace(code,$v289_0_0$12+lv*2.8+strn*1.45+focus+atk_bonus$v289_0_0$,'')))/length($v289_0_0$12+lv*2.8+strn*1.45+focus+atk_bonus$v289_0_0$) = 1 THEN
    code:=replace(code,$v289_0_0$12+lv*2.8+strn*1.45+focus+atk_bonus$v289_0_0$,$v289_0_0$12+lv*2.8+strn*1.45+focus+atk_bonus+least(10,greatest(0,coalesce((p_save#>>'{v25,rebirth}')::int,0)))*500$v289_0_0$);
  ELSE
    RAISE EXCEPTION 'V289_UNEXPECTED_SQL_SIGNATURE: private.amber_v285_combat_stats substitution 1';
  END IF;
  IF position($v289_0_1$lv*.45+vit*.65+def_bonus+least(10,greatest(0,coalesce((p_save#>>'{v25,rebirth}')::int,0)))*200$v289_0_1$ IN code)>0 THEN
    NULL; -- already installed (check replacement FIRST: original can be prefix)
  ELSIF (length(code)-length(replace(code,$v289_0_1$lv*.45+vit*.65+def_bonus$v289_0_1$,'')))/length($v289_0_1$lv*.45+vit*.65+def_bonus$v289_0_1$) = 1 THEN
    code:=replace(code,$v289_0_1$lv*.45+vit*.65+def_bonus$v289_0_1$,$v289_0_1$lv*.45+vit*.65+def_bonus+least(10,greatest(0,coalesce((p_save#>>'{v25,rebirth}')::int,0)))*200$v289_0_1$);
  ELSE
    RAISE EXCEPTION 'V289_UNEXPECTED_SQL_SIGNATURE: private.amber_v285_combat_stats substitution 2';
  END IF;
  IF position($v289_0_2$0.07+luk*.0024+crit_bonus/100+least(10,greatest(0,coalesce((p_save#>>'{v25,rebirth}')::int,0)))*.005$v289_0_2$ IN code)>0 THEN
    NULL; -- already installed (check replacement FIRST: original can be prefix)
  ELSIF (length(code)-length(replace(code,$v289_0_2$0.07+luk*.0024+crit_bonus/100$v289_0_2$,'')))/length($v289_0_2$0.07+luk*.0024+crit_bonus/100$v289_0_2$) = 1 THEN
    code:=replace(code,$v289_0_2$0.07+luk*.0024+crit_bonus/100$v289_0_2$,$v289_0_2$0.07+luk*.0024+crit_bonus/100+least(10,greatest(0,coalesce((p_save#>>'{v25,rebirth}')::int,0)))*.005$v289_0_2$);
  ELSE
    RAISE EXCEPTION 'V289_UNEXPECTED_SQL_SIGNATURE: private.amber_v285_combat_stats substitution 3';
  END IF;
  IF position($v289_0_3$0.81+dex*.0027+least(10,greatest(0,coalesce((p_save#>>'{v25,rebirth}')::int,0)))*.005$v289_0_3$ IN code)>0 THEN
    NULL; -- already installed (check replacement FIRST: original can be prefix)
  ELSIF (length(code)-length(replace(code,$v289_0_3$0.81+dex*.0027$v289_0_3$,'')))/length($v289_0_3$0.81+dex*.0027$v289_0_3$) = 1 THEN
    code:=replace(code,$v289_0_3$0.81+dex*.0027$v289_0_3$,$v289_0_3$0.81+dex*.0027+least(10,greatest(0,coalesce((p_save#>>'{v25,rebirth}')::int,0)))*.005$v289_0_3$);
  ELSE
    RAISE EXCEPTION 'V289_UNEXPECTED_SQL_SIGNATURE: private.amber_v285_combat_stats substitution 4';
  END IF;
  EXECUTE code;
  -- public.amber_v282_rebirth
  SELECT p.oid INTO oid_found FROM pg_catalog.pg_proc p JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public' AND p.proname='amber_v282_rebirth' AND p.prokind='f';
  IF oid_found IS NULL THEN RAISE EXCEPTION 'V289_MISSING_FUNCTION: %', 'public.amber_v282_rebirth'; END IF;
  code:=pg_catalog.pg_get_functiondef(oid_found);
  IF position($v289_1_0$20+rb*50$v289_1_0$ IN code)>0 THEN
    NULL; -- already installed (check replacement FIRST: original can be prefix)
  ELSIF (length(code)-length(replace(code,$v289_1_0$20+rb*10$v289_1_0$,'')))/length($v289_1_0$20+rb*10$v289_1_0$) = 2 THEN
    code:=replace(code,$v289_1_0$20+rb*10$v289_1_0$,$v289_1_0$20+rb*50$v289_1_0$);
  ELSE
    RAISE EXCEPTION 'V289_UNEXPECTED_SQL_SIGNATURE: public.amber_v282_rebirth substitution 1';
  END IF;
  IF position($v289_1_1$old_sp+8$v289_1_1$ IN code)>0 THEN
    NULL; -- already installed (check replacement FIRST: original can be prefix)
  ELSIF (length(code)-length(replace(code,$v289_1_1$old_sp+3$v289_1_1$,'')))/length($v289_1_1$old_sp+3$v289_1_1$) = 2 THEN
    code:=replace(code,$v289_1_1$old_sp+3$v289_1_1$,$v289_1_1$old_sp+8$v289_1_1$);
  ELSE
    RAISE EXCEPTION 'V289_UNEXPECTED_SQL_SIGNATURE: public.amber_v282_rebirth substitution 2';
  END IF;
  IF position($v289_1_2$250+rb*1500$v289_1_2$ IN code)>0 THEN
    NULL; -- already installed (check replacement FIRST: original can be prefix)
  ELSIF (length(code)-length(replace(code,$v289_1_2$250+rb*150$v289_1_2$,'')))/length($v289_1_2$250+rb*150$v289_1_2$) = 1 THEN
    code:=replace(code,$v289_1_2$250+rb*150$v289_1_2$,$v289_1_2$250+rb*1500$v289_1_2$);
  ELSE
    RAISE EXCEPTION 'V289_UNEXPECTED_SQL_SIGNATURE: public.amber_v282_rebirth substitution 3';
  END IF;
  IF position($v289_1_3$120+rb*400$v289_1_3$ IN code)>0 THEN
    NULL; -- already installed (check replacement FIRST: original can be prefix)
  ELSIF (length(code)-length(replace(code,$v289_1_3$120+rb*40$v289_1_3$,'')))/length($v289_1_3$120+rb*40$v289_1_3$) = 1 THEN
    code:=replace(code,$v289_1_3$120+rb*40$v289_1_3$,$v289_1_3$120+rb*400$v289_1_3$);
  ELSE
    RAISE EXCEPTION 'V289_UNEXPECTED_SQL_SIGNATURE: public.amber_v282_rebirth substitution 4';
  END IF;
  EXECUTE code;
  -- public.amber_v283_auto_attack
  SELECT p.oid INTO oid_found FROM pg_catalog.pg_proc p JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public' AND p.proname='amber_v283_auto_attack' AND p.prokind='f';
  IF oid_found IS NULL THEN RAISE EXCEPTION 'V289_MISSING_FUNCTION: %', 'public.amber_v283_auto_attack'; END IF;
  code:=pg_catalog.pg_get_functiondef(oid_found);
  IF position($v289_2_0$rb*1500$v289_2_0$ IN code)>0 THEN
    NULL; -- already installed (check replacement FIRST: original can be prefix)
  ELSIF (length(code)-length(replace(code,$v289_2_0$rb*150$v289_2_0$,'')))/length($v289_2_0$rb*150$v289_2_0$) = 1 THEN
    code:=replace(code,$v289_2_0$rb*150$v289_2_0$,$v289_2_0$rb*1500$v289_2_0$);
  ELSE
    RAISE EXCEPTION 'V289_UNEXPECTED_SQL_SIGNATURE: public.amber_v283_auto_attack substitution 1';
  END IF;
  IF position($v289_2_1$rb*400$v289_2_1$ IN code)>0 THEN
    NULL; -- already installed (check replacement FIRST: original can be prefix)
  ELSIF (length(code)-length(replace(code,$v289_2_1$rb*40$v289_2_1$,'')))/length($v289_2_1$rb*40$v289_2_1$) = 1 THEN
    code:=replace(code,$v289_2_1$rb*40$v289_2_1$,$v289_2_1$rb*400$v289_2_1$);
  ELSE
    RAISE EXCEPTION 'V289_UNEXPECTED_SQL_SIGNATURE: public.amber_v283_auto_attack substitution 2';
  END IF;
  EXECUTE code;
  -- public.amber_v278_pet_regen
  SELECT p.oid INTO oid_found FROM pg_catalog.pg_proc p JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public' AND p.proname='amber_v278_pet_regen' AND p.prokind='f';
  IF oid_found IS NULL THEN RAISE EXCEPTION 'V289_MISSING_FUNCTION: %', 'public.amber_v278_pet_regen'; END IF;
  code:=pg_catalog.pg_get_functiondef(oid_found);
  IF position($v289_3_0$maxhp:=250+(lv-1)*48+least(10,greatest(0,coalesce((s#>>'{v25,rebirth}')::int,0)))*1500;maxmp:=120+(lv-1)*17+int_stat*2-10+least(10,greatest(0,coalesce((s#>>'{v25,rebirth}')::int,0)))*400;$v289_3_0$ IN code)>0 THEN
    NULL; -- already installed (check replacement FIRST: original can be prefix)
  ELSIF (length(code)-length(replace(code,$v289_3_0$maxhp:=250+(lv-1)*48;maxmp:=120+(lv-1)*17+int_stat*2-10;$v289_3_0$,'')))/length($v289_3_0$maxhp:=250+(lv-1)*48;maxmp:=120+(lv-1)*17+int_stat*2-10;$v289_3_0$) = 1 THEN
    code:=replace(code,$v289_3_0$maxhp:=250+(lv-1)*48;maxmp:=120+(lv-1)*17+int_stat*2-10;$v289_3_0$,$v289_3_0$maxhp:=250+(lv-1)*48+least(10,greatest(0,coalesce((s#>>'{v25,rebirth}')::int,0)))*1500;maxmp:=120+(lv-1)*17+int_stat*2-10+least(10,greatest(0,coalesce((s#>>'{v25,rebirth}')::int,0)))*400;$v289_3_0$);
  ELSE
    RAISE EXCEPTION 'V289_UNEXPECTED_SQL_SIGNATURE: public.amber_v278_pet_regen substitution 1';
  END IF;
  EXECUTE code;
  -- private.amber_v287_roll_combat
  SELECT p.oid INTO oid_found FROM pg_catalog.pg_proc p JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='private' AND p.proname='amber_v287_roll_combat' AND p.prokind='f';
  IF oid_found IS NULL THEN RAISE EXCEPTION 'V289_MISSING_FUNCTION: %', 'private.amber_v287_roll_combat'; END IF;
  code:=pg_catalog.pg_get_functiondef(oid_found);
  IF position($v289_4_0$GREATEST(.90,LEAST(.99,p_accuracy-GREATEST(0,p_enemy_lv-p_player_lv)*.01))$v289_4_0$ IN code)>0 THEN
    NULL; -- already installed (check replacement FIRST: original can be prefix)
  ELSIF (length(code)-length(replace(code,$v289_4_0$GREATEST(.18,LEAST(.99,p_accuracy-GREATEST(0,p_enemy_lv-p_player_lv)*.075))$v289_4_0$,'')))/length($v289_4_0$GREATEST(.18,LEAST(.99,p_accuracy-GREATEST(0,p_enemy_lv-p_player_lv)*.075))$v289_4_0$) = 1 THEN
    code:=replace(code,$v289_4_0$GREATEST(.18,LEAST(.99,p_accuracy-GREATEST(0,p_enemy_lv-p_player_lv)*.075))$v289_4_0$,$v289_4_0$GREATEST(.90,LEAST(.99,p_accuracy-GREATEST(0,p_enemy_lv-p_player_lv)*.01))$v289_4_0$);
  ELSE
    RAISE EXCEPTION 'V289_UNEXPECTED_SQL_SIGNATURE: private.amber_v287_roll_combat substitution 1';
  END IF;
  EXECUTE code;
  -- private.amber_dg_max_health
  SELECT p.oid INTO oid_found FROM pg_catalog.pg_proc p JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='private' AND p.proname='amber_dg_max_health' AND p.prokind='f';
  IF oid_found IS NULL THEN RAISE EXCEPTION 'V289_MISSING_FUNCTION: %', 'private.amber_dg_max_health'; END IF;
  code:=pg_catalog.pg_get_functiondef(oid_found);
  IF position($v289_5_0$+ greatest(0,coalesce((save_data->'stats'->>'VIT')::integer,10)-10)*8 + least(10,greatest(0,coalesce((save_data#>>'{v25,rebirth}')::int,0)))*1500)::integer))$v289_5_0$ IN code)>0 THEN
    NULL; -- already installed (check replacement FIRST: original can be prefix)
  ELSIF (length(code)-length(replace(code,$v289_5_0$+ greatest(0,coalesce((save_data->'stats'->>'VIT')::integer,10)-10)*8)::integer))$v289_5_0$,'')))/length($v289_5_0$+ greatest(0,coalesce((save_data->'stats'->>'VIT')::integer,10)-10)*8)::integer))$v289_5_0$) = 1 THEN
    code:=replace(code,$v289_5_0$+ greatest(0,coalesce((save_data->'stats'->>'VIT')::integer,10)-10)*8)::integer))$v289_5_0$,$v289_5_0$+ greatest(0,coalesce((save_data->'stats'->>'VIT')::integer,10)-10)*8 + least(10,greatest(0,coalesce((save_data#>>'{v25,rebirth}')::int,0)))*1500)::integer))$v289_5_0$);
  ELSE
    RAISE EXCEPTION 'V289_UNEXPECTED_SQL_SIGNATURE: private.amber_dg_max_health substitution 1';
  END IF;
  EXECUTE code;
END $v289_install$;

-- Atomic server-verified food bulk purchase (max 50, server calculates gem cost).
CREATE OR REPLACE FUNCTION public.amber_v289_buy_pet_food(p_qty integer)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO '' AS $pet_food$
DECLARE
  u uuid := (SELECT auth.uid()); s jsonb; p jsonb; items jsonb;
  gems bigint; spend bigint; ix int; qty_old int; val jsonb; owned boolean;
BEGIN
  IF u IS NULL THEN RAISE EXCEPTION 'V289_LOGIN_REQUIRED'; END IF;
  IF p_qty IS NULL OR p_qty<1 OR p_qty>50 THEN RAISE EXCEPTION 'V289_BAD_QUANTITY'; END IF;
  IF NOT EXISTS(SELECT 1 FROM private.amber_v277_bootstrap WHERE user_id=u) THEN
    PERFORM public.amber_v277_bootstrap();
  END IF;
  SELECT save_data INTO s FROM public.amber_characters WHERE user_id=u FOR UPDATE;
  IF s IS NULL OR pg_catalog.jsonb_typeof(s)<>'object' THEN RAISE EXCEPTION 'V289_NO_CHARACTER'; END IF;
  p:=COALESCE(s->'pet23','{}'::jsonb);
  IF pg_catalog.jsonb_typeof(p)<>'object' THEN RAISE EXCEPTION 'V289_PET_STATE_INVALID'; END IF;
  items:=COALESCE(p->'items','[]'::jsonb);
  IF pg_catalog.jsonb_typeof(items)<>'array' OR pg_catalog.jsonb_array_length(items)>150 THEN RAISE EXCEPTION 'V289_PET_ITEMS_INVALID'; END IF;
  gems:=COALESCE((s->>'gems')::bigint,0);
  spend:=p_qty::bigint*80;
  IF gems<spend OR gems>2000000000 THEN RAISE EXCEPTION 'V289_GEMS_INSUFFICIENT'; END IF;
  SELECT ord::integer,value INTO ix,val FROM pg_catalog.jsonb_array_elements(items) WITH ORDINALITY e(value,ord)
    WHERE value->>'sku'='food' LIMIT 1;
  IF ix IS NULL THEN
    IF pg_catalog.jsonb_array_length(items)>=150 THEN RAISE EXCEPTION 'V289_PET_BAG_FULL'; END IF;
    items:=items||pg_catalog.jsonb_build_array(pg_catalog.jsonb_build_object('id','pet_'||replace(gen_random_uuid()::text,'-',''),'sku','food','qty',p_qty));
  ELSE
    qty_old:=COALESCE((val->>'qty')::int,0);
    IF qty_old<1 OR qty_old>999949 THEN RAISE EXCEPTION 'V289_FOOD_STACK_INVALID'; END IF;
    items:=pg_catalog.jsonb_set(items,ARRAY[(ix-1)::text,'qty'],pg_catalog.to_jsonb(qty_old+p_qty),false);
  END IF;
  p:=pg_catalog.jsonb_set(p,'{items}',items,true);
  s:=pg_catalog.jsonb_set(pg_catalog.jsonb_set(s,'{pet23}',p,true),'{gems}',pg_catalog.to_jsonb(gems-spend),true);
  UPDATE public.amber_characters SET save_data=s,updated_at=clock_timestamp() WHERE user_id=u;
  UPDATE private.amber_v276_player_state SET gems=(s->>'gems')::bigint,version=version+1,updated_at=clock_timestamp() WHERE user_id=u;
  RETURN pg_catalog.jsonb_build_object('ok',true,'save',s,'qty',p_qty,'cost',spend);
END $pet_food$;

-- Read-only hunger state; uses server clock, verifies current authenticated account.
CREATE OR REPLACE FUNCTION public.amber_v289_pet_status()
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO '' AS $pet_status$
DECLARE u uuid:=(SELECT auth.uid()); p jsonb; nowms bigint; lastms bigint; hunger numeric; active boolean;
BEGIN
  IF u IS NULL THEN RAISE EXCEPTION 'V289_LOGIN_REQUIRED'; END IF;
  SELECT save_data->'pet23' INTO p FROM public.amber_characters WHERE user_id=u;
  IF p IS NULL OR pg_catalog.jsonb_typeof(p)<>'object' THEN p:='{}'::jsonb; END IF;
  nowms:=(extract(epoch FROM transaction_timestamp())*1000)::bigint;
  lastms:=greatest(0,least(nowms,coalesce((p->>'lastAt')::bigint,nowms)));
  hunger:=greatest(0,least(100,coalesce((p->>'hunger')::numeric,100)));
  active:=coalesce((p->>'active')::boolean,false) AND coalesce((p->>'owned')::boolean,false);
  IF active THEN hunger:=greatest(0,hunger-(nowms-lastms)::numeric/120000); END IF;
  IF hunger<=0 THEN active:=false; END IF;
  p:=pg_catalog.jsonb_set(pg_catalog.jsonb_set(p,'{hunger}',pg_catalog.to_jsonb(hunger),true),'{active}',pg_catalog.to_jsonb(active),true);
  RETURN pg_catalog.jsonb_build_object('ok',true,'pet',p);
END $pet_status$;

REVOKE ALL ON FUNCTION public.amber_v289_buy_pet_food(integer) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.amber_v289_buy_pet_food(integer) TO authenticated;
REVOKE ALL ON FUNCTION public.amber_v289_pet_status() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.amber_v289_pet_status() TO authenticated;
COMMIT;
NOTIFY pgrst, 'reload schema';
-- Verification (no account data exposed)
SELECT p.proname AS rpc_present FROM pg_catalog.pg_proc p JOIN pg_catalog.pg_namespace n ON n.oid=p.pronamespace
WHERE n.nspname='public' AND p.proname IN ('amber_v289_buy_pet_food','amber_v289_pet_status') ORDER BY p.proname;
