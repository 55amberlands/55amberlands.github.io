55 AMBERLANDS — เพิ่มล็อกอินแบบจำเครื่อง (DEVICE / GUEST)
==================================================
ทำงานกับโปรเจกต์บน GitHub 55amberlands/55amberlands.github.io

โครงสร้างแพตช์นี้
- device_login.js : เพิ่มปุ่ม "เข้าเกมด้วยเครื่องนี้" บนหน้าล็อกอินเดิมเท่านั้น
- install_device_login.py : ตัวติดตั้งเพิ่ม 1 บรรทัดโหลดสคริปต์ใน index.html

ไม่แก้ online_bridge.js, Supabase SQL, ดรอป, EXP, สกิล, UI ในเกม,
Google Login, เซฟตัวละคร, ดันเจี้ยน หรือ CBT ประกาศ

ขั้นตอนติดตั้งใน GitHub Codespaces หลังอัปโหลด ZIP ไปยัง Repository
1. git pull origin main
2. unzip -o 55_AMBERLANDS_DEVICE_LOGIN_ADDON.zip device_login.js install_device_login.py
3. python3 install_device_login.py
4. git diff -- index.html
5. git add index.html device_login.js
6. git commit -m "Add device sign-in option"
7. git push origin main

ต้องเปิดบน Supabase Dashboard ด้วยตนเอง:
Authentication → Settings / Sign In / Providers (ชื่อเมนูอาจแตกต่าง)
→ Allow anonymous sign-ins = ON
โดยไม่ต้องแก้ SQL ก่อน แต่ต้องตรวจสิทธิ์ RLS / RPC ของเกมด้วย

ข้อจำกัดสำคัญ:
- ผู้เล่น Guest จะมี user_id ใหม่และตัวละครใหม่แยกจาก Google
- Supabase session จะอยู่ในเบราว์เซอร์เครื่องนั้นจนกว่าจะ sign out,
  ล้างข้อมูลเว็บไซต์, เปลี่ยนเบราว์เซอร์ หรือสูญเสีย session
- การใช้มือถือเดียวกันแต่คนละเบราว์เซอร์ไม่ได้เป็นบัญชีเดียวกัน
- ไม่รับประกันการกู้บัญชี Guest หากล้างข้อมูลแล้ว
- ถ้าจะย้าย Guest ไป Google ต้องออกแบบ "Link Identity" อย่างปลอดภัยในอนาคต
  ห้ามใช้ signInWithOAuth ปกติจาก Guest เพราะอาจสร้างบัญชีคนละ user_id
- ต้องตรวจ RLS; anonymous sign-ins ได้ role authenticated
- ควรเปิด Turnstile/CAPTCHA ป้องกันบอทสร้างบัญชี Guest รัว ๆ
- หากผู้เล่นล็อกอิน Google อยู่ ระบบเข้าตัวละคร Google ตามปกติ

ทดสอบด้วยบราวเซอร์ที่ยังไม่มีบัญชี Google ติดอยู่ หรือโหมดไม่ระบุตัวตน
และอย่าใช้โหมดไม่ระบุตัวตนสำหรับ Guest ตัวจริง เพราะ session จะหายเมื่อปิด

rollback: ใน Codespaces ลบบรรทัด <script src="./device_login.js?v=1"></script>
ออกจาก index.html แล้ว commit/push อีกครั้ง
