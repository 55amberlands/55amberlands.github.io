#!/usr/bin/env python3
"""Install an additive device-auth script into the current GitHub game.

Does not replace online_bridge.js, CBT notice, gameplay JS or any SQL.
Idempotent and fails closed if the original online auth script is absent.
"""
from pathlib import Path
import re
import sys

index = Path('index.html')
addon = Path('device_login.js')
if not index.is_file() or not addon.is_file():
    sys.exit('ERROR: ต้องรันในโฟลเดอร์เกมที่มี index.html และ device_login.js')
src = index.read_text(encoding='utf-8')
if re.search(r'<script\b[^>]*\bsrc=["\'][^"\']*device_login\.js',src):
    print('OK: มีบรรทัดโหลด device_login.js แล้ว ไม่ได้เพิ่มซ้ำ')
    sys.exit(0)
# Include directly after original online bridge: no changes to its script, auth logic or UI.
pattern = re.compile(r'(<script\b[^>]*\bsrc=["\'][^"\']*online_bridge\.js(?:\?[^"\']*)?["\'][^>]*>\s*</script>)',re.I)
if len(pattern.findall(src)) != 1:
    sys.exit('ERROR: ไม่พบบรรทัด online_bridge.js แบบที่คาดไว้ หรือพบซ้ำ — หยุด ไม่แก้ไฟล์เกม')
new=pattern.sub(lambda m: m.group(1)+'\n<script src="./device_login.js?v=1"></script>',src,count=1)
index.write_text(new,encoding='utf-8')
print('OK: เพิ่ม script device_login.js หลัง online_bridge.js เพียง 1 บรรทัด')
print('NEXT: ตรวจการแก้ไขด้วย git diff -- index.html')
