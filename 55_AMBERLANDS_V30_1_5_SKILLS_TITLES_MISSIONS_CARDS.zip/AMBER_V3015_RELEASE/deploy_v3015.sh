#!/usr/bin/env bash
# Deploy from Codespaces only. Never force-push and never modify Supabase.
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
EXPECTED='f65a1622bcc669dd824aaea51b402c80424fcc82'
BACKUP_BRANCH='backup-v3014-before-v3015-20261027'

if [[ "$(git branch --show-current)" != 'main' ]]; then
  if ! git diff --quiet || ! git diff --cached --quiet; then
    echo 'STOP: unsaved tracked changes; stash/commit first';exit 2
  fi
  git switch main
fi
git fetch origin main
git pull --ff-only origin main
if ! git diff --cached --quiet; then echo 'STOP: staged files already exist';exit 3;fi
if ! git diff --quiet -- index.html v25_systems.js; then
  echo 'STOP: index.html or v25_systems.js has local changes';exit 3
fi
if [[ -e v3015_stable_skills.js && "$(grep -c 'AMBER V30.1.5' v3015_stable_skills.js || true)" == 0 ]]; then
  echo 'STOP: conflicting v3015_stable_skills.js exists';exit 3
fi
BASE="$(git rev-parse HEAD)"
if [[ "$BASE" != "$EXPECTED" ]]; then
  if grep -q 'AMBER_V3015_SERVER_CARDS_TITLES_MISSIONS' v25_systems.js; then
    echo "PASS: V30.1.5 is already installed on $(git rev-parse --short HEAD)";exit 0
  fi
  echo "STOP: main changed from V30.1.4; expected ${EXPECTED:0:12}, got ${BASE:0:12}";exit 4
fi
# Backup the exact V30.1.4 commit on server before any patch is committed.
git push origin "${BASE}:refs/heads/${BACKUP_BRANCH}"

HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cp -f "$HERE/v3015_stable_skills.js" ./v3015_stable_skills.js
python3 "$HERE/patch_v3015.py"
node --check v25_systems.js
node --check v3015_stable_skills.js
git diff --check -- index.html v25_systems.js
test "$(grep -c 'v3015_stable_skills.js' index.html)" = 1
test "$(grep -c 'AMBER_V3015_SERVER_CARDS_TITLES_MISSIONS' v25_systems.js)" = 1
# Stage exactly the three patch targets, never stage ZIPs or unrelated files.
git add -- index.html v25_systems.js v3015_stable_skills.js
git commit -m 'V30.1.5 stable skills server titles mission claims verified cards'
git push origin main
echo 'PASS: V30.1.5 pushed to MAIN; V30.1.4 safely backed up.'
