-- 55 AMBERLANDS V23.4 — INDEPENDENT DUNGEON COOLDOWNS
-- PATCH: install AFTER V23.3 SQL. Does not reset cooldowns or modify drops/rewards.
begin;

-- V23.4: migrate shared cooldown row to (user_id, dungeon) without deleting timers.
-- The last completed run determines the dungeon for the legacy row.
-- Keep existing room, player, gear, reward, and inventory rows intact.
alter table public.amber_dungeon_cooldowns
  add column if not exists dungeon text;

with legacy as (
 select c.user_id,
   (select r.dungeon
    from public.amber_dungeon_members m
    join public.amber_dungeon_rooms r on r.id=m.room_id
    where m.user_id=c.user_id and m.accepted and r.status='finished' and r.finished_at is not null
    order by abs(extract(epoch from (c.next_at-(r.finished_at+interval '4 hours')))),r.finished_at desc
    limit 1) inferred
 from public.amber_dungeon_cooldowns c where c.dungeon is null
)
update public.amber_dungeon_cooldowns c
 set dungeon=coalesce(l.inferred,'dragon')
from legacy l where c.user_id=l.user_id and c.dungeon is null;

alter table public.amber_dungeon_cooldowns alter column dungeon set not null;
do $$begin
 if not exists (select 1 from pg_constraint where conrelid='public.amber_dungeon_cooldowns'::regclass
   and conname='amber_dungeon_cooldowns_dungeon_check') then
   alter table public.amber_dungeon_cooldowns add constraint amber_dungeon_cooldowns_dungeon_check
     check(dungeon in ('dragon','ice'));
 end if;
 if not exists (select 1 from pg_constraint where conrelid='public.amber_dungeon_cooldowns'::regclass
   and contype='p' and pg_get_constraintdef(oid) like '%(user_id, dungeon)%') then
   alter table public.amber_dungeon_cooldowns drop constraint if exists amber_dungeon_cooldowns_pkey;
   alter table public.amber_dungeon_cooldowns add constraint amber_dungeon_cooldowns_pkey
     primary key(user_id,dungeon);
 end if;
end$$;

-- Legacy one-argument helper retained for other older code. V23.4 uses two arguments.
create or replace function private.amber_dg_wait(p_user uuid)
returns bigint language sql stable security definer set search_path = '' as $$
 select greatest(0,ceil(extract(epoch from (
   coalesce((select max(next_at) from public.amber_dungeon_cooldowns where user_id=p_user),now())-now())))::bigint);
$$;
create or replace function private.amber_dg_wait(p_user uuid,p_dungeon text)
returns bigint language sql stable security definer set search_path = '' as $$
 select greatest(0,ceil(extract(epoch from (
   coalesce((select next_at from public.amber_dungeon_cooldowns
     where user_id=p_user and dungeon=p_dungeon),now())-now())))::bigint);
$$;
-- Player-owned status RPC: useful before selecting the next dungeon.
create or replace function private.amber_dg_cooldowns_state()
returns jsonb language sql stable security definer set search_path = '' as $$
 select jsonb_build_object(
  'dragon',jsonb_build_object('next_at',
    (select next_at from public.amber_dungeon_cooldowns where user_id=auth.uid() and dungeon='dragon'),
    'seconds',private.amber_dg_wait(auth.uid(),'dragon')),
  'ice',jsonb_build_object('next_at',
    (select next_at from public.amber_dungeon_cooldowns where user_id=auth.uid() and dungeon='ice'),
    'seconds',private.amber_dg_wait(auth.uid(),'ice')))
 where auth.uid() is not null;
$$;
create or replace function public.amber_dungeon_cooldowns_state()
returns jsonb language sql security invoker set search_path='' as $$
 select private.amber_dg_cooldowns_state();
$$;
create or replace function private.amber_dg_create(p_dungeon text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare u uuid:=auth.uid(); r uuid;
begin
 if u is null then raise exception 'Google Login required'; end if;
 if p_dungeon not in ('dragon','ice') then raise exception 'Unknown dungeon'; end if;
 if coalesce(private.amber_dg_level(u),0)<50 then raise exception 'Lv.50+ required'; end if;
 if private.amber_dg_wait(u,p_dungeon)>0 then raise exception 'Dungeon cooldown active'; end if;
 if exists(select 1 from public.amber_dungeon_members m join public.amber_dungeon_rooms x on x.id=m.room_id where m.user_id=u and x.status in ('waiting','active') and x.created_at>now()-interval '45 minutes') then
    raise exception 'You already have an active dungeon lobby';end if;
 insert into public.amber_dungeon_rooms(owner_id,dungeon) values(u,p_dungeon) returning id into r;
 insert into public.amber_dungeon_members(room_id,user_id,accepted,ready)values(r,u,true,false);
 return r;
end$$;

create or replace function private.amber_dg_invite(p_room uuid,p_friend uuid)
returns boolean language plpgsql security definer set search_path = '' as $$
declare u uuid:=auth.uid(); n integer; v_dungeon text;
begin
 if u is null or p_friend is null or p_friend=u then raise exception 'Invalid invitation';end if;
 select dungeon into v_dungeon from public.amber_dungeon_rooms where id=p_room and owner_id=u and status='waiting' for update;
 if not found then raise exception 'Only leader can invite to waiting room';end if;
 if coalesce(private.amber_dg_level(p_friend),0)<50 then raise exception 'Member must be Lv.50+';end if;
 if private.amber_dg_wait(p_friend,v_dungeon)>0 then raise exception 'Friend is on cooldown';end if;
 select count(*) into n from public.amber_dungeon_members where room_id=p_room;
 if n>=6 then raise exception 'Room full (6 players)';end if;
 insert into public.amber_dungeon_members(room_id,user_id) values(p_room,p_friend) on conflict do nothing;
 return true;
end$$;

create or replace function private.amber_dg_answer(p_room uuid,p_accept boolean)
returns boolean language plpgsql security definer set search_path = '' as $$
declare u uuid:=auth.uid(); status_ text; v_dungeon text;
begin
 if u is null then raise exception 'Login required';end if;
 select status,dungeon into status_,v_dungeon from public.amber_dungeon_rooms where id=p_room for update;
 if status_ is distinct from 'waiting' then raise exception 'Room is no longer waiting';end if;
 if not exists(select 1 from public.amber_dungeon_members where room_id=p_room and user_id=u) then raise exception 'Not invited';end if;
 if coalesce(private.amber_dg_level(u),0)<50 or private.amber_dg_wait(u,v_dungeon)>0 then raise exception 'Level or cooldown restriction';end if;
 if not p_accept then delete from public.amber_dungeon_members where room_id=p_room and user_id=u and u <> (select owner_id from public.amber_dungeon_rooms where id=p_room);
 else update public.amber_dungeon_members set accepted=true,ready=false where room_id=p_room and user_id=u;end if;
 return true;
end$$;

create or replace function private.amber_dg_start(p_room uuid)
returns boolean language plpgsql security definer set search_path = '' as $$
declare r public.amber_dungeon_rooms%rowtype; c integer; avg_level numeric; hp bigint;
begin
 select * into r from public.amber_dungeon_rooms where id=p_room for update;
 if r.id is null or r.owner_id<>auth.uid() or r.status<>'waiting' then raise exception 'Only room leader can start';end if;
 select count(*),avg(private.amber_dg_level(user_id)) into c,avg_level from public.amber_dungeon_members where room_id=p_room and accepted;
 if c<1 or c>6 then raise exception 'Invalid party size';end if;
 if exists(select 1 from public.amber_dungeon_members where room_id=p_room and (not accepted or not ready)) then raise exception 'All invited players must accept and be ready (remove declined users)';end if;
 if exists(select 1 from public.amber_dungeon_members where room_id=p_room and private.amber_dg_wait(user_id,r.dungeon)>0) then raise exception 'A party member is on cooldown';end if;
 hp=round((case when r.dungeon='dragon' then 180000 else 200000 end)*(1+greatest(0,avg_level-50)/130)*(greatest(1,c)/4.0));
 update public.amber_dungeon_rooms set status='active',boss_index=1,boss_hp=hp,boss_max=hp,started_at=now() where id=p_room;
 return true;
end$$;

create or replace function private.amber_dg_snapshot(p_room uuid)
returns jsonb language plpgsql stable security definer set search_path = '' as $$
declare r public.amber_dungeon_rooms%rowtype; members jsonb;
begin
 select * into r from public.amber_dungeon_rooms where id=p_room;
 if r.id is null or auth.uid() is null or not exists(
  select 1 from public.amber_dungeon_members where room_id=p_room and user_id=auth.uid())
 then raise exception 'Room not found or forbidden';end if;
 select coalesce(jsonb_agg(jsonb_build_object(
  'user_id',m.user_id,'name',coalesce(p.display_name,'ผู้เล่น'),
  'accepted',m.accepted,'ready',m.ready,'level',private.amber_dg_level(m.user_id),
  'dg_hp',m.dg_hp,'dg_max_hp',m.dg_max_hp,
  'dg_hit_at',m.dg_hit_at,'dg_last_damage',m.dg_last_damage,
  'dg_death_at',m.dg_death_at) order by m.joined_at),'[]'::jsonb)
 into members from public.amber_dungeon_members m
 left join public.amber_profiles p on p.user_id=m.user_id where m.room_id=p_room;
 return jsonb_build_object('id',r.id,'owner_id',r.owner_id,'dungeon',r.dungeon,
  'status',r.status,'boss_index',r.boss_index,'boss_hp',r.boss_hp,
  'boss_max',r.boss_max,'started_at',r.started_at,'finished_at',r.finished_at,
  'members',members,'cooldown',private.amber_dg_wait(auth.uid(),r.dungeon),
  'cooldown_next_at',(select next_at from public.amber_dungeon_cooldowns where user_id=auth.uid() and dungeon=r.dungeon),
  'boss_last_hit',r.boss_last_hit);
end$$;

create or replace function private.amber_dg_attack_v24(p_room uuid,p_skill text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare r public.amber_dungeon_rooms%rowtype; u uuid:=auth.uid(); player public.amber_dungeon_members%rowtype;
 lvl integer; stats jsonb; str int; dex int; inte int; damage int; next_boss bigint; avg_level numeric; c integer;
 profile jsonb; pet jsonb; skill_idx int; multiplier numeric := 1; valid_skill boolean := false; pet_atk boolean := false;
begin
 select * into r from public.amber_dungeon_rooms where id=p_room for update;
 if r.status<>'active' then raise exception 'Dungeon not active';end if;
 select * into player from public.amber_dungeon_members where room_id=p_room and user_id=u and accepted=true and ready=true for update;
 if player.user_id is null then raise exception 'Not ready member';end if;
 if coalesce(player.dg_hp,0)<=0 then raise exception 'Player is downed in dungeon';end if;
 if player.last_attack is not null and now()-player.last_attack<interval '1100 milliseconds' then raise exception 'Attack on cooldown';end if;
 select least(100,greatest(1,coalesce((save_data->>'lv')::integer,1))),coalesce(save_data->'stats','{}'::jsonb),save_data into lvl,stats,profile from public.amber_characters where user_id=u;
 if lvl<50 then raise exception 'Lv.50 required';end if;
 str=least(3000,greatest(0,coalesce((stats->>'STR')::integer,0)));
 dex=least(3000,greatest(0,coalesce((stats->>'DEX')::integer,0)));
 inte=least(3000,greatest(0,coalesce((stats->>'INT')::integer,0)));
 -- Only a learned attack skill of the actual character class can affect boss damage.
 if p_skill is not null and length(p_skill)<=70 and p_skill ~ '^(ดาบ|หมัด|ธนู|จอมเวท)_(POWER|DEX|INT)_[0-9]$' and
    coalesce(profile->'learned','[]'::jsonb) ? p_skill and
    split_part(p_skill,'_',1) = coalesce(profile->>'job','') then
   skill_idx=split_part(p_skill,'_',3)::integer;
   if skill_idx not in (2,5) then
     valid_skill=true;multiplier=multiplier*(1.10 + skill_idx*.035);
   end if;
 end if;
 -- Bounded pet effect; checked against this character's cloud save.
 pet=coalesce(profile->'pet23','{}'::jsonb);
 if coalesce((pet->>'owned')::boolean,false)
    and coalesce((pet->>'active')::boolean,false)
    and coalesce((pet->>'hunger')::numeric,0)>0
    and coalesce(pet->'skills','[]'::jsonb) ? 'attack'
    and coalesce(pet->'unlocked','[]'::jsonb) ? 'attack'
    and coalesce((pet->'effects'->>'attack')::numeric,0)>extract(epoch from now())*1000 then
    pet_atk=true;multiplier=multiplier*1.30;
 end if;
 damage=least(2350,greatest(130,round(
  least(1200,greatest(130,(130+lvl*3.2+greatest(str,dex,inte)*1.35)*(.85+random()*.3)))
   * least(1.95,multiplier))::integer));
 update public.amber_dungeon_members set last_attack=now() where room_id=p_room and user_id=u;
 if r.boss_hp>damage then
  update public.amber_dungeon_rooms set boss_hp=boss_hp-damage where id=p_room;
 else
  if r.boss_index<3 then
    select count(*),avg(private.amber_dg_level(user_id)) into c,avg_level from public.amber_dungeon_members where room_id=p_room and accepted;
    next_boss=round((case when r.dungeon='dragon' then (array[180000,320000,580000])[r.boss_index+1]
                                                else (array[200000,360000,650000])[r.boss_index+1] end)
                      *(1+greatest(0,avg_level-50)/130)*(greatest(1,c)/4.0));
    update public.amber_dungeon_rooms set boss_index=boss_index+1,boss_hp=next_boss,boss_max=next_boss where id=p_room;
  else
    update public.amber_dungeon_rooms set boss_index=3,boss_hp=0,status='finished',finished_at=now() where id=p_room;
    insert into public.amber_dungeon_cooldowns(user_id,dungeon,next_at)
     select user_id,r.dungeon,now()+interval '4 hours' from public.amber_dungeon_members where room_id=p_room and accepted
     on conflict(user_id,dungeon) do update set next_at=excluded.next_at;
    -- Drop math per player per finished run: 5% boss weapon, of which 0.10% absolute best roll;
    -- independent 5% upgrade stones, 4–5 units. Server decides all results.
    insert into public.amber_dungeon_rewards(room_id,user_id,reward)
    select p_room,user_id,jsonb_build_object(
      'weapon',case when rnd < .05 then true else false end,
      'best',case when rnd < .001 then true else false end,
      'weapon_class', (array['ดาบ','หมัด','ธนู','จอมเวท'])[1+floor(random()*4)::integer],
      'stones',case when random()<.05 then 4+floor(random()*2)::integer else 0 end,
      'stone_kind',case when random()<.5 then 'gw' else 'ga' end)
    from (select user_id,random() as rnd from public.amber_dungeon_members where room_id=p_room and accepted) t
    on conflict(room_id,user_id) do nothing;
  end if;
 end if;
 return jsonb_build_object('damage',damage,'room',private.amber_dg_snapshot(p_room), 'skill_applied',valid_skill,'pet_attack_applied',pet_atk);
end$$;

create or replace function private.amber_dg_attack(p_room uuid)
returns jsonb language sql security definer set search_path = '' as $$
 select private.amber_dg_attack_v24(p_room,null);
$$;

-- Restore only the permission surface needed for authenticated dungeon play.
revoke all on function public.amber_dungeon_cooldowns_state() from public,anon;
revoke all on function private.amber_dg_cooldowns_state() from public,anon;
revoke all on function private.amber_dg_wait(uuid,text) from public,anon;
revoke all on function private.amber_dg_wait(uuid) from public,anon;
revoke all on function private.amber_dg_create(text) from public,anon;
revoke all on function private.amber_dg_invite(uuid,uuid) from public,anon;
revoke all on function private.amber_dg_answer(uuid,boolean) from public,anon;
revoke all on function private.amber_dg_start(uuid) from public,anon;
revoke all on function private.amber_dg_snapshot(uuid) from public,anon;
revoke all on function private.amber_dg_attack_v24(uuid,text) from public,anon;
revoke all on function private.amber_dg_attack(uuid) from public,anon;
grant usage on schema private to authenticated;
grant execute on function public.amber_dungeon_cooldowns_state() to authenticated;
grant execute on function private.amber_dg_cooldowns_state() to authenticated;
grant execute on function private.amber_dg_wait(uuid,text) to authenticated;
grant execute on function private.amber_dg_wait(uuid) to authenticated;
grant execute on function private.amber_dg_create(text) to authenticated;
grant execute on function private.amber_dg_invite(uuid,uuid) to authenticated;
grant execute on function private.amber_dg_answer(uuid,boolean) to authenticated;
grant execute on function private.amber_dg_start(uuid) to authenticated;
grant execute on function private.amber_dg_snapshot(uuid) to authenticated;
grant execute on function private.amber_dg_attack_v24(uuid,text) to authenticated;
grant execute on function private.amber_dg_attack(uuid) to authenticated;
notify pgrst,'reload schema';

commit;
