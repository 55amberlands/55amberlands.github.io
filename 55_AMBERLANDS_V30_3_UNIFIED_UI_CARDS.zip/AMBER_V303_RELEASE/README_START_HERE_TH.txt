55 AMBERLANDS V30.3 — UI UNIFICATION & VERIFIED CARDS

Required: live repository already at V30.2; V30.1 login gate remains active.
Purpose: stop old V25 floating boss ticker; embed V27.3 world boss as a tab in V28 boss hub;
move emote UI upward when the mobile bottom nav expands; hide notifications and emoji above modal/inventory;
read monster-card thresholds only from Supabase verified server kill receipts.

IMPORTANT: Monster cards are kill-count milestones (25/100/400/1500 normal monsters), not random
inventory drops. The server may have 10,000+ receipts, but individual monster counts depend on account.
The old boss-card local progress is disabled for authenticated players until a verified boss receipt
bridge is added. V30.3 does not grant gear, stat points, wallet, or cards directly.

No SQL required. Existing RPC: amber_v291_verified_cards() is already installed.
No changes are made to Supabase data, battle damage, equipment, market, HP/MP, or any save tables.
The card UI is verified, but existing card-derived combat bonuses are not verified as server-calculated
in this release — a separate combat audit is required before claiming those buffs change real damage.

Upload the ZIP unchanged through GitHub Add file → Upload files → Commit changes.
Then in Codespaces Terminal:
cd "$(git rev-parse --show-toplevel)" && git switch main && git pull --ff-only origin main && unzip -oq 55_AMBERLANDS_V30_3_UNIFIED_UI_CARDS.zip -d .git/amber_v303 && bash .git/amber_v303/AMBER_V303_RELEASE/deploy_v303.sh

Test: login, show event tab cards, open inventory (no fixed overlay), expand mobile menu
(emote button clears nav), open World Boss hub and choose legacy tab, test both old and new fights.
No world-boss encounters or receipts were created by producing this package.
