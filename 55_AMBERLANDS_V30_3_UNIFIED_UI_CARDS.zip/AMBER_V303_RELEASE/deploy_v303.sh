#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
if [[ "$(git branch --show-current)" != "main" ]]; then echo 'STOP: checkout main first' >&2; exit 1; fi
if [[ -n "$(git status --porcelain --untracked-files=no)" ]]; then echo 'STOP: uncommitted tracked changes; refusing overwrite' >&2; exit 1; fi
python3 .git/amber_v303/AMBER_V303_RELEASE/install_v303.py
python3 tools/check_static_site.py
for f in v25_systems.js v28_boss_book.js v303_unified_ui_cards.js; do node --check "$f"; done
git add index.html v25_systems.js v28_boss_book.js v303_unified_ui_cards.js
git diff --cached --check
if git diff --cached --quiet; then echo 'V30.3 already installed'; else
  git commit -m 'V30.3 unify boss UI and server-verified monster card progress'
  git push origin main
fi
echo 'PASS: pushed V30.3. Wait for GitHub Pages workflow success before refreshing.'
