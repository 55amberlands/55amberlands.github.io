#!/usr/bin/env python3
"""Apply narrowly scoped V30.3 changes on a clean V30.2 repo checkout.
No SQL and no modifications to persistent Supabase data.
"""
from pathlib import Path
import shutil,sys
root=Path.cwd(); src=Path(__file__).resolve().parent
required=['index.html','v25_systems.js','v28_boss_book.js','v303_unified_ui_cards.js']
if not (root/'v302_crit_anchor.js').exists() or not (root/'v28_boss_book.js').exists():
    sys.exit('ERROR: ต้องติดตั้ง V30.2 ก่อน กรุณาอย่านำ V28 กลับมาทับเกม')
files={n:(root/n).read_text(encoding='utf-8') for n in ['index.html','v25_systems.js','v28_boss_book.js']}
idx=files['index.html'];v25=files['v25_systems.js'];hub=files['v28_boss_book.js']
if 'v303_unified_ui_cards.js?v=303' in idx:
    print('V30.3 is already installed.');sys.exit(0)
if not all(x in idx for x in ['v302_crit_anchor.js','v28_boss_book.js','v300_authoritative_vitals_ui.js']):
    sys.exit('ERROR: this is not the expected V30.2 index.html')
def substitute(s,old,new,label):
    n=s.count(old)
    if n!=1:sys.exit(f'ERROR: {label} incompatible ({n}) — NO files changed')
    return s.replace(old,new,1)
# Read ONLY server-receipt-backed counts in online mode. Legacy values are
# permitted for a local offline preview, never as authenticated card progress.
v25=substitute(v25,'const cardTier = (name, boss) => { const k = V().ck[name] | 0,',
  'const cardTier = (name, boss) => { const k = window.AMBER_V303_CARDS?.count?.(name,boss) ?? (V().ck[name] | 0),', 'verified card tier')
v25=substitute(v25,'const t = cardTier(m.name, m.boss), k = V().ck[m.name] | 0,',
  'const t = cardTier(m.name, m.boss), k = window.AMBER_V303_CARDS?.count?.(m.name,m.boss) ?? (V().ck[m.name] | 0),', 'verified card count')
v25=substitute(v25,"if (st && st.kills > k && name && !rd) {",
  "if (st && st.kills > k && name && !rd && !(window.AMBER_CLOUD?.getStatus?.()?.cloudReady)) {",'disable local card awards online')
v25=substitute(v25,"if (m) { const before = cardTier(m.name, true);", 
  "if (m && !(window.AMBER_CLOUD?.getStatus?.()?.cloudReady)) { const before = cardTier(m.name, true);", 'disable local boss card awards online')
v25=substitute(v25,"if (curTab === 'checkin' && window.AMBER_V27) await window.AMBER_V27.syncState(true);",
  "if (curTab === 'checkin' && window.AMBER_V27) await window.AMBER_V27.syncState(true);\n  if (curTab === 'cards') await window.AMBER_V303_CARDS?.refresh?.(true);",'refresh card before showing tab')
# Expose the legacy boss room within the newer world-boss hub as an explicit tab,
# instead of having two separate floating entry points.
hub=substitute(hub,"['exchange', '⚡ แลกอาวุธตำนาน']].map", "['exchange', '⚡ แลกอาวุธตำนาน'], ['legacy', '👑 บอสเดิม']].map", 'boss hub tab')
legacy_page='''function pageLegacy(){
  const w=winOpen(),v=window.AMBER_V25?.V?.()||{};
  const next=w.open?'กำลังเปิดรอบบอส':('รอบถัดไป '+(w.next?new Date(w.next).toLocaleTimeString('th-TH',{hour:'2-digit',minute:'2-digit'}):'—'));
  return `<div class="px28h-note"><b>👑 ห้องบอสโลกเดิม V27.3</b><br>คงค่ารางวัลและสิทธิ์เดิมจาก Supabase ไว้โดยไม่รวมยอด HP กับบอสใหม่ทั้ง 10 ตัว<br>สถานะ: <b>${esc(next)}</b> · รับรางวัลผ่านเซิร์ฟเวอร์เท่านั้น</div>
  <div class="px28h-w"><b>จ้าวมังกรเพลิง (ระบบเดิม)</b><br><small>อยู่ในหน้าบอสโลกเดียวกันแล้ว ไม่มีกล่องบอสเก่าลอยทับหน้าเกม</small>
  <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:12px">
   <button data-h28legacygo="1" class="px28h-btn" ${w.open&&ready()?'':'disabled'}>⚔️ เข้าสู้บอสเดิม</button>
   <button data-h28legacypractice="1" class="px28h-btn alt">🧪 ซ้อมบอสเดิม</button>
   <button data-h28legacyclaim="1" class="px28h-btn alt">🏅 ตรวจรับรางวัลเดิม</button>
  </div></div>`;
}
'''
hub=substitute(hub,'function render() { const b =',legacy_page+'function render() { const b =','legacy room page')
hub=substitute(hub,"TAB === 'exchange' ? pageExchange() : pageSelect()", "TAB === 'exchange' ? pageExchange() : TAB === 'legacy' ? pageLegacy() : pageSelect()", 'legacy page render')
hub=substitute(hub,"'[data-h28tab],[data-h28go],[data-h28prac],[data-h28ex]'", "'[data-h28tab],[data-h28go],[data-h28prac],[data-h28ex],[data-h28legacygo],[data-h28legacypractice],[data-h28legacyclaim]'", 'legacy event selector')
hub=substitute(hub, '  if (t.dataset.h28prac) {', '''  if(t.dataset.h28legacygo){closeModal();window.AMBER_V26?.openArena?.(false,{_hub:1});return;}
  if(t.dataset.h28legacypractice){closeModal();window.AMBER_V26?.openArena?.(true,{_hub:1});return;}
  if(t.dataset.h28legacyclaim){await window.AMBER_V273?.claimLast?.();return;}
  if (t.dataset.h28prac) {''', 'legacy boss entry routing')
idx=substitute(idx,'<script src="./v302_crit_anchor.js?v=302"></script>', '<script src="./v302_crit_anchor.js?v=302"></script>\n<script src="./v303_unified_ui_cards.js?v=303_unified"></script>', 'new UI file after V302')
# Disable caches of the two modified scripts, even for browsers retaining V30.2 JS.
for fn in ['v25_systems.js','v28_boss_book.js']:
  import re
  matches=list(re.finditer(r'\./'+re.escape(fn)+r'\?v=[^"\s<>]+',idx))
  if len(matches)!=1:sys.exit(f'ERROR: unexpected HTML script reference for {fn} ({len(matches)})')
  idx=idx[:matches[0].start()]+'./'+fn+'?v=303_verified_unified'+idx[matches[0].end():]
backup=root/'.amber_v303_backups'
backup.mkdir(exist_ok=True)
for f in files:
  b=backup/f;b.parent.mkdir(parents=True,exist_ok=True)
  if not b.exists():b.write_text(files[f],encoding='utf-8')
(root/'index.html').write_text(idx,encoding='utf-8')
(root/'v25_systems.js').write_text(v25,encoding='utf-8')
(root/'v28_boss_book.js').write_text(hub,encoding='utf-8')
shutil.copy2(src/'payload/v303_unified_ui_cards.js',root/'v303_unified_ui_cards.js')
print('PASS V30.3: V25 server-verified cards, old world boss in V28 hub, no old overlay, emote spacing')
