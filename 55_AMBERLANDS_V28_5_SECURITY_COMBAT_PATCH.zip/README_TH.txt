55 AMBERLANDS V28.5 SECURITY + EQUIPPED COMBAT CLIENT PATCH

ติดตั้งส่วน Supabase ไปแล้ว: ทะเบียนเจ้าของอุปกรณ์ / ป้องกันรหัสซ้ำข้ามตลาดและกระเป๋า / ID รางวัลดันเจียน / คำนวณ ATK DEF CRIT ของอุปกรณ์สวมใส่และบัฟโล่จากเซิร์ฟเวอร์

ส่วนเว็บยังไม่อัปโหลด ต้องใส่ 2 ไฟล์นี้:
index.html
v12_patch.js

คำสั่ง Codespaces หลังอัปโหลด ZIP ลง repository ผ่าน GitHub และ Commit แล้ว:
git pull --ff-only origin main
unzip -o 55_AMBERLANDS_V28_5_SECURITY_COMBAT_PATCH.zip index.html v12_patch.js
node --check v12_patch.js
git add index.html v12_patch.js
git commit -m "V28.5 server owned gear combat UI"
git push origin main

V28.5 ใช้สูตร:
พลังโจมตีพื้นฐานจากเลเวล/STR และสเตตัสอาชีพตาม V12 เดิม
บวก ATK ของอุปกรณ์ที่เป็นเจ้าของจริงพร้อมสวมใส่ถูกช่อง อาชีพ และเลเวล
ค่า ATK/DEF จาก base × (1 + 0.10 × enhancement) + ออปชั่น ATK/DEF แบบบวกตรง
CRIT จาก LUK + ออปชั่น CRIT ของอุปกรณ์ และจำกัดไม่เกิน 80%
DEF ฝั่งมอนคืนผลดาเมจเป็นของ Supabase และ Pet Shield ลดดาเมจเข้า 25% เมื่อบัฟยังมีสิทธิ์

สำคัญ: ไม่ควรอัปเดต client เก่าทับ index.html ฉบับ V28.4 เพราะจะทำให้ระบบอื่นย้อนเวอร์ชัน
ข้อมูลเดิมในทะเบียนเป็น legacy_unverified: ระบุว่าเห็นจากเซฟที่เคยมี ไม่ใช่ใบรับรองความถูกต้องย้อนหลัง
V28.5 ไม่ได้ย้ายระบบ PvP, Dungeon damage, Guild War, บัฟการ์ด/ฉายาทั้งหมดไปสูตรเดียวกัน

ทดสอบหลัง Push: UI ATK จากอุปกรณ์เปลี่ยน, โจมตีแล้วดาเมจขึ้น, ตีบวกแล้วค่าสถานะเปลี่ยนหลังรีเฟรช,
ขาย/ย้ายของไปตลาดแล้วอุปกรณ์ไม่ซ้ำ, ใช้บัญชีอื่นไม่เห็นอุปกรณ์ของ Hareko.
