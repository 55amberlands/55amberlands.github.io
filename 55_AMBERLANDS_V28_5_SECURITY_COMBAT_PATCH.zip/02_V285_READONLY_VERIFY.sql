-- 55 AMBERLANDS V28.5 READ ONLY, Safe to run in Supabase SQL Editor
SELECT (SELECT COUNT(*) FROM private.amber_v285_gear_registry) AS gear_registry_entries,
 (SELECT COUNT(*) FROM private.amber_v285_gear_registry WHERE location='inventory') AS held,
 (SELECT COUNT(*) FROM private.amber_v285_gear_registry WHERE location='market') AS listed,
 (SELECT COUNT(*) FROM pg_trigger WHERE tgname LIKE 'amber_v285_%' AND tgenabled='O') AS enabled_guards,
 (SELECT COUNT(*) FROM public.amber_characters) AS existing_characters,
 (SELECT COUNT(*) FROM public.amber_dungeon_rewards WHERE claimed_at IS NULL) AS pending_dungeon_rewards,
 (SELECT POSITION('V285_SERVER_EQUIPMENT_POWER' IN pg_get_functiondef('public.amber_v277_attack(text,text)'::regprocedure))>0) AS combat_uses_server_gear,
 (SELECT POSITION('gen_random_uuid()' IN pg_get_functiondef('private.amber_dg_claim(uuid)'::regprocedure))>0) AS boss_drop_ids_unique,
 has_table_privilege('authenticated','private.amber_v285_gear_registry','UPDATE') AS player_can_change_registry,
 has_table_privilege('authenticated','public.amber_characters','UPDATE') AS player_can_change_save;
