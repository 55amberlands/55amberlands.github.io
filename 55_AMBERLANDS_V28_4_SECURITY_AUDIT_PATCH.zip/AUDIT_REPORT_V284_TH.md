# 55 AMBERLANDS — รายงานสแกนระบบเกมและ Supabase V28.4
**วันที่ตรวจ:** 26 ตุลาคม 2026 (เวลาไทย)  
**โค้ดต้นทาง:** `55amberlands/55amberlands.github.io`, สาขา `main` หลัง V28.3  
**ฐานข้อมูล:** Supabase `55-amberlands` — โปรเจกต์ `rfijdwnzuhvlkfptyoiy`  
**ขอบเขต:** ไฟล์ JavaScript 33 ตัว, โค้ดอินไลน์ใน `index.html` 6 บล็อก, ตาราง/RLS/Trigger, สิทธิ์ RPC, ธุรกรรมตัวอย่างใน transaction rollback  
**ขีดจำกัด:** การสแกน static + SQL และการจำลองบางธุรกรรม ไม่ใช่การทดสอบบอส/PvP/ตลาดทุกสถานการณ์แบบ End-to-End บนผู้เล่นจริง จึงไม่กล่าวว่าปลอดภัยหรือไร้บั๊ก 100%

## 1. สิ่งที่แก้ลง Supabase จริงแล้ว (ไม่มี SQL ให้ผู้ใช้รันเพิ่ม)

| หัวข้อ | การเปลี่ยนแปลง | ผลตรวจ |
|---|---|---|
| P0 — Direct character write | ถอน `INSERT, UPDATE, DELETE` ของ `authenticated/anon` บน `public.amber_characters` | ยืนยันว่าผู้เล่นแก้แถวเซฟตรงไม่ได้ ส่วน `SELECT` ดูแถวตนเองยังเปิดผ่าน RLS |
| P0 — Full-save RPC | ถอน `EXECUTE` `public.amber_save_guarded(jsonb,bigint)` จาก client | ยืนยัน client เรียกไม่ได้; V28.3 ใช้ `amber_v277_visual_save` สำหรับ settings |
| P1 — คะแนนจัดอันดับ | ถอน `INSERT,UPDATE,DELETE` บน `public.amber_scores` ของผู้เล่น | ป้องกันคะแนนตรงจากมือถือ แต่คะแนนใหม่ต้องมี writer ฝั่ง server ในอนาคต |
| P1 — NPC Bulk Sell | เพิ่ม `public.amber_v284_bulk_sell(p_items jsonb)` แบบธุรกรรมเดียว | ทดสอบขายไอเทมหลายชนิดและรายการผิดพลาดทำ rollback ทั้งรายการ ผ่าน |
| Login/Authorization | RPC bulk ใช้ `auth.uid()` และตรวจเจ้าของผ่าน helper server; anon ไม่มี EXECUTE | ผ่าน |

**ผลตรวจฐานข้อมูลหลังเปลี่ยน:** มีตัวละคร 21 ราย, แผนที่ 10, มอนสเตอร์ 48 (บอส 10), สกิล 120, `private.amber_v276_item_instances` มี 0 แถว, `global_strict=false`, บัญชีที่ลงทะเบียน `amber_v277_bootstrap` 1 ราย ณ เวลาตรวจ ข้อมูลอาจเปลี่ยนได้เมื่อมีผู้เล่นเข้าเกมเพิ่ม

**สำคัญ:** ยังเก็บ item/Gold/EXP ใน `amber_characters.save_data` (JSON) เป็นหลักแม้จะตรวจและแก้ผ่าน server RPC และฐาน item-instance ใหม่ยังไม่ได้เป็นแหล่งข้อมูลจริง จึงยังต้องย้าย provenance/ledger ให้สมบูรณ์ ไม่ควรกล่าวว่าเป็น MMORPG Server-Authoritative ครบทุกระบบแล้ว

## 2. สิ่งที่แก้เป็นแพตช์ V28.4 — ต้องอัปโหลด GitHub อีกครั้ง

| ไฟล์ | ปัญหาที่ตรวจพบ | วิธีแก้ |
|---|---|---|
| `v23_bulksell.js` | ขายหลายชนิดแล้ว `state.bag`, `state.gear`, `state.gold` ถูกแก้ในมือถือเท่านั้น เซิร์ฟเวอร์ไม่ได้เพิ่มเงินหรือหักของ | ส่ง `kind/key/quantity` ไป `amber_v284_bulk_sell` แล้วรับข้อมูลเซฟใหม่จาก RPC; ถ้ารายการใดผิด ยกเลิกทั้งก้อน |
| `v20_itemshop_costumes.js` | `setup()` เขียน `state.gems=99999` ฝั่ง browser ทำยอดคอยล์ในจอไม่ตรง Supabase | ไม่สร้างยอดคอยล์ในเครื่องอีก; ยอดต้องมาจาก server; เพิ่ม fallback ซื้อ/สวม/ถอด/ใช้ไอเทมผ่าน RPC โดยตรง |
| `index.html` | ปุ่ม `resetGame()` ยังเปลี่ยนเลเวล/ของกลับเริ่มต้นในเครื่องแม้เป็นตัวละคร Google ทำให้ผู้ใช้เข้าใจว่าเซฟจริงถูกลบ | ห้ามใช้ปุ่ม reset ฝั่งเบราว์เซอร์เมื่อ Google/Supabase login อยู่ (โหมดออฟไลน์เดิมไม่เปลี่ยน); bust cache script 2 ตัว |

**ยังไม่ได้ Push ขึ้น GitHub:** ไฟล์ V28.4 ที่แก้เสร็จพร้อม ZIP ต้องอัปโหลดผ่าน GitHub Codespaces โดยผู้ใช้ (สิทธิ์เขียน Repository ของ connector ถูกปฏิเสธมาก่อน)

## 3. ตารางสแกนระบบเกมทุกหมวด

สัญลักษณ์: ✅ มี server RPC หรือ auth ที่ตรวจสอบได้; ◐ มีบางส่วนบนเซิร์ฟเวอร์แต่ยังไม่ครบ; ❌ ยังพึ่ง browser เป็นแหล่งจริง; ⏳ ต้องทดสอบต่อ

| ระบบ | สถานะจากโค้ดและ DB | ปัญหาหรือเงื่อนไขคงค้าง |
|---|---|---|
| สมัคร/ล็อกอิน Google | ✅ Supabase Auth | ต้องทดสอบสร้างตัวละครใหม่ End-to-End หลังถอนสิทธิ์ direct write แต่ `amber_create_character` เป็น SECURITY DEFINER และยัง EXECUTE ได้ |
| สร้างตัวละครและค่าสถานะเริ่มต้น | ✅ `amber_create_character` | ตรวจความสอดคล้อง starter gems: server เริ่ม 0 แต่ข้อความร้านเดิมเคยบอกได้ 99,999 ทดลอง; V28.4 แก้ข้อความให้ตรงยอดจริง ไม่แจกเพิ่มเอง |
| เซฟข้อมูลตัวละคร | ✅/◐ RPC economy/combat/visual | ปิด full-save จาก browser แล้ว; localStorage ยังคงมีค่า UI ออฟไลน์ ไม่ใช่เซฟที่เชื่อถือได้ |
| ค่าตัวละคร/เพิ่มสเตตัส | ✅ `amber_v277_economy` | มีการคำนวณบัฟย่อยใน JavaScript ที่เซิร์ฟเวอร์ยังไม่รองรับทั้งหมด |
| เปลี่ยนอาชีพ Lv.10 | ✅ RPC economy | สูตรสิทธิ์อาชีพอยู่ใน server; ต้องยืนยัน UI ทดสอบครบ 4 อาชีพ |
| เรียนสกิล 120 | ✅ บันทึกสิทธิ์เรียนผ่าน server | สกิลบัฟ, AoE, จำนวนฮิต, เอฟเฟกต์บางท่า ยัง render/คำนวณใน JS และอาจไม่ตรง server damage |
| Auto Skill 6 ช่อง | ✅ `amber_v283_auto_skill_slots` | เฉพาะสกิลโจมตีในช่องที่ถูกใช้งาน; Auto Buff ยังไม่ครบ |
| Auto Battle มอนทั่วไป | ✅ `amber_v277_attack` / `amber_v283_auto_attack` | ตรวจ cooldown server 750ms; แต่ยังไม่มี server ตำแหน่งตัวละคร/ระยะโจมตี/monster spawn และ anti-bot ครบ |
| 38 มอนธรรมดา | ✅ server monster registry และ damage/loot | เลข HP/EXP/Gold จาก server ต้องตรวจบาลานซ์กับ UI ทุกแผนที่ ไม่เพียงแค่มี 48 แถว |
| 10 บอสประจำแผนที่ | ◐ มี registry และแยก RPC | RPC โจมตีปกติปฏิเสธ `is_boss=true`; ต้องยืนยันเส้นทางโจมตี, ฆ่า, ดรอปบอสต่อแผนที่จริงทุกตัว |
| แผนที่ 10 | ◐ ตาราง server + visual chooseMap RPC | ตรวจ level gate ได้ แต่ไม่มี authoritative x/y, zone movement/spawn/leash สำหรับทุกผู้เล่น |
| EXP / Lv.100 | ✅ server คิด EXP และเลเวลใน normal combat | ต้องเทียบสูตรเก่าทั้งหมด; โบนัสรีเบิร์ท/ปีก server อยู่แล้ว แต่ card/set bonus ยังมีความไม่ตรงกัน |
| ดรอปไอเทมทั่วไป | ✅ server มอบผ่าน RPC แล้ว | ดรอปมอนทั่วไปยังใช้ subset ของไอเทม; `item_instances` ใหม่ไม่ได้เป็นแหล่ง canonical |
| ร้านยา HP/MP | ✅ server ราคาและจำนวน | ต้องทดสอบทุก UI รวมปุ่มเก่าที่เรียก `usePotion` async; V28.3 แก้เส้นทางหลักแล้ว |
| Auto Potion | ✅ V28.3 ธุรกรรมโจมตี/ยาอะตอม | สูตร maxHP/MP ฝั่ง server กับ bonus gear/card ใน UI อาจยังไม่ตรงเมื่อของแรงหรือเกิดใหม่ |
| ร้าน NPC/ซื้ออุปกรณ์ | ✅ economy RPC | ตรวจไอเทมทุกระดับและทุกอาชีพแบบ UI เพิ่มเติม |
| ตีบวก +0 ถึง +10 | ✅ server สุ่มและหักหิน/Gold | ต้องเทียบสูตรอัตราสำเร็จและอุปกรณ์ทุก slot กับเกมต้นฉบับ |
| สวม/ถอด/ขายไอเทมเดี่ยว | ✅ inventory / NPC sell RPC | server ตรวจเจ้าของ/จำนวน; ต้องเพิ่มล็อก `boss/mythic` ทุกเส้นทาง NPC ตาม policy ที่ผู้สร้างต้องการ |
| ขายของ NPC หลายชนิด | ✅ SQL V28.4 / ⏳ UI V28.4 | **ต้องอัปโหลด 3 ไฟล์** ในแพตช์ก่อนจึงใช้งานจริงบนเว็บ |
| ตลาดผู้เล่น | ✅ server RPC post/buy/cancel/claim | ตลาดที่เปิดค้างขณะผู้เล่นเก่ายังใช้ local client อาจต้องรีเฟรชความสอดคล้อง; ตรวจซื้อพร้อมกันหลายคนเพิ่ม |
| รับเงินตลาดอัตโนมัติ | ◐ `amber_market_claim` server | ฝั่ง browser เช็ก receipt/claim เฉพาะเมื่อมีหน้าเว็บทำงาน ไม่มี server cron รับเงินตอนออฟไลน์ |
| Item Shop / คอยล์ | ✅ RPC buy_shop / equip_wing / consume_shop | V28.4 ลบยอดคอยล์สมมุติฝั่ง JS, แต่ยังต้องออกแบบโปรโมชันเติมคอยล์ด้วย server-issued entitlement |
| ปีก EXP ×2/×3 | ✅ server ตรวจ owned, expiry และ multiplier ใน normal combat | ต้องเทียบผลในดันเจียน/บอส และผลเมื่อหมดอายุกับการแสดง UI |
| สัตว์เลี้ยง, อาหาร, DUO | ✅ `amber_v278_pet` / regen | server ยืนยันการซื้อ/ใช้/slot/cooldown/hunger; การ render ขยับยัง JS ตามปกติ |
| Pet ATK +30% | ✅ server ตรวจบัฟใน normal attack | ยังต้องยืนยันใน Dungeon/World Boss |
| Pet Regen | ✅ server RPC | ต้องดูการชนคิวกับ AUTO และสุขภาพสูงสุดเมื่อมีบัฟอุปกรณ์ |
| Pet Shield ลด 25% | ❌ **พบช่องว่าง** | `amber_v277_attack` ยังไม่มีการตรวจบัฟ shield ตอนรับดาเมจ; UI แสดงคำอธิบายแต่ผล server ไม่ครบ |
| ดันเจียน 3 บอส/Ready/Cooldown | ◐ RPC dungeon มีอยู่ประมาณ 15 ฟังก์ชัน | การต่อสู้และรางวัลใช้ server; Auto Dungeon ยังไม่ครบวงจร เข้าห้อง/รอคน/รีสตาร์ต/เปิดหีบไม่ได้อัตโนมัติทั้งหมด |
| บอสโลกช่วงเวลา | ✅/◐ `amber_v273_*` + V26 | โหมดจริงใช้ RPC server, โหมดซ้อมจำลองใน browser; ตรวจช่วงเวลา/รางวัลกับหลายบัญชีเพิ่ม |
| เควสต์รายวัน (ฆ่า/สกิล/ตีบวก/เรด) | ✅ `amber_v279_*` + event receipts | ต้องมีหลักฐานใหม่บน Supabase; สถิติเดิมในมือถืออาจไม่ถูกนับย้อนหลัง |
| เช็กอิน/ของรางวัลรายวัน | ✅ `amber_ac_checkin` และ server claims | ต้องทดสอบข้ามเที่ยงคืน Bangkok และเคสรีเฟรชทันที |
| ระบบรีเบิร์ท | ✅ `amber_v282_rebirth` | server เปลี่ยน Lv/EXP/stats, เก็บของ/เงิน; โบนัสการ์ด/ชุดใน client ยังต้องเทียบกับ server |
| การ์ดมอนสเตอร์และโบนัสค่าสเตตัส | ❌/◐ `v25_systems.js` นับ card `v.ck` และเพิ่ม bonus ฝั่ง JS | ไม่มีหลักฐานว่าบัฟจากการ์ดถูกคำนวณโดย server normal combat; ต้องย้าย counter, unlock, stats |
| ฉายาและโบนัสชุดบอส | ❌/◐ หน้าจอ client สรุปชุด, title, card buffs | บาง title/bonus เป็น local-only จึงไม่ควรถือว่าเพิ่ม damage จริงบน server |
| ปาร์ตี้ 7 คน / EXP share | ❌/◐ UI เดิมมี BOT/จำนวนสมาชิกจำลอง | มี presence/realtime ของผู้เล่นจริง แต่ party/EXP share ไม่มี server party ledger ครบตามสเปก |
| Guild/Chat | ◐ guild tables + RLS | guild member `UPDATE` ฝั่งผู้เล่นยังต้องตรวจ role/guild_id, หลีกเลี่ยง client-generated privileges; แนะนำแยก RPC guild authoritative |
| Guild War / PvP | ❌ ยังไม่พบวงจร server-authoritative ครบ | ต้องออกแบบ server combat, matching, zone และ reward ledger ก่อนให้รางวัลจริง |
| Referral เชิญเพื่อน | ◐ refs/deems tables + trigger | ยังอนุญาตบาง REST writes ตาม RLS เดิม ต้องทดสอบ fake/ineligible referrals, double claim, กันฟาร์มโค้ด |
| อันดับประจำสัปดาห์ | ◐ อ่านได้ แต่ผู้เล่นเขียนตรงถูกปิด V28.4 | ต้องเพิ่ม server event writer มิฉะนั้นคะแนนจากเกมใหม่ไม่ไหลเข้า leaderboard |
| ผู้เล่นออนไลน์ / Realtime | ✅/◐ Supabase Realtime/Presence | ใช้แสดงสถานะและ sprite; ข้อมูล broadcast เช่นตำแหน่ง/ATK ไม่ใช่ server combat authoritative |
| UI, pixel-art, เอฟเฟกต์, เสียง | ✅ ใช้ JavaScript client ตามปกติ | ไม่จำเป็นต้องย้ายการวาดกราฟิกไป Postgres; สิ่งที่ต้องย้ายคือผลลัพธ์ที่มีมูลค่ากับกติกาเกม |

## 4. จัดลำดับความเสี่ยงที่ยังเหลือ

### P0 — ห้ามประกาศว่ากันโกงครบแล้ว
1. สิทธิ์ตรงของ `amber_characters` และ whole-save RPC **ปิดแล้วจริงใน V28.4** แต่ legacy `save_data` ที่มีมาจากเกมเก่ายังไม่ได้ตรวจ provenance ย้อนหลังทุกไอเทม/เงินทั้งหมด; `private.amber_v276_item_instances` ยัง 0 แถว
2. Server combat ไม่มีเซิร์ฟเวอร์ติดตามตำแหน่ง/ระยะโจมตี/monster spawn ที่เชื่อถือได้ ผู้เล่นอาจส่งคำสั่งโจมตีได้ตามช่วงเวลาที่ RPC อนุญาตจากที่ใดก็ได้ใน map
3. การ์ด/บัฟชุดบอส/บัฟบางชนิดยังคำนวณจากข้อมูล local และไม่รับรองผลโดย Supabase ทุกจุด
4. ปาร์ตี้/Guild War/PvP และการแจก loot บอสทุกทางเดินยังไม่ผ่านการทดสอบครบ

### P1 — แก้ Server RPC ได้ในรอบถัดไป
- ตรวจ Pet Shield 25% และโบนัส DEF/HP/MP ทั้งชุดให้ server คำนวณเหมือนคำอธิบายในเกม
- ออกแบบ server event proof ของ card, title, PvP, guild war, party/EXP share และ rank score
- แยก Item Instance ledger จริงและ legacy import ที่มี provenance ชัดเจน
- ตรวจรายการ market, dungeon/raid claim concurrency พร้อมกันมากกว่า 1 player
- ตรวจ reward และ redemption/referral เชื่อมกับ source-of-truth

### P1 — ต้องแก้ไฟล์เว็บอีกแพตช์
- Auto Dungeon รวมเลือกห้อง/ต่อสู้/claim/ออก/วนรอบให้เป็น flow บน server
- ย้าย card/bonus UI ไปอ่านผลจาก server แทนการบวก stats จาก client
- ปรับการเก็บ/แสดง guild/party และ leaderboard ให้ตรง server หลังย้าย authority
- แก้ปุ่มที่ยังอ้าง local storage เช่น manual-reset ใน index V28.4 นี้ถูกปิดสำหรับผู้ใช้ Google แล้ว

## 5. การทดสอบและสิ่งที่ยังไม่ทดสอบ

**ทดสอบจริงด้วย transaction + ROLLBACK:**
- ผู้เล่นไม่มีสิทธิ์ UPDATE ตรงบนตัวละคร และ visual-save กับ RPC ซื้อยาทำงานภายใต้การปิดสิทธิ์
- RPC ขาย NPC สองรายการจ่าย Gold ที่ server คำนวณ, ไม่รับไอเทมปลอม, ไม่ให้ใส่สินค้าซ้ำ
- เมื่อชุดขายมีไอเทมผิดรายการที่สอง รายการแรกและ Gold ทั้งก้อนไม่เปลี่ยน
- ไม่มี anon EXECUTE บน RPC `amber_v284_bulk_sell`
- ฟังก์ชัน `amber_v277_attack`, `amber_v283_auto_attack`, `amber_v282_rebirth` เคยมี transaction tests ผ่านในขั้น V28.2–V28.3

**ทดสอบไฟล์:** `node --check` กับไฟล์ JS 33 ตัวจาก V28.3 ผ่าน, `node --check` สองไฟล์ที่แก้ V28.4 ผ่าน, บล็อก inline script ใน index.html ทั้ง 6 ผ่าน

**ไม่ได้ทดสอบ End-to-End:** การ login ผู้เล่นใหม่หลังเปลี่ยน grants, โอนเงินจริง 2 ผู้เล่นพร้อมกัน, บอสทุกแผนที่, party sharing, PvP, auto dungeon, สายอาชีพ/skill animation 120 ท่า, load test 50–100 คน ห้ามตีความจาก `node --check` ว่าระบบเล่นได้ทั้งหมด

## 6. ขั้นตอนติดตั้งแพตช์หน้าเว็บ (ไม่ต้องรัน SQL)

1. ดาวน์โหลด `55_AMBERLANDS_V28_4_SECURITY_AUDIT_PATCH.zip`
2. อัปโหลด ZIP ขึ้น GitHub `main` ผ่านปุ่ม `+` ใกล้ Code เข้ากลุ่มเดียวกับ index.html
3. เปิด Codespaces/Terminal และรันทีละบรรทัด:

```bash
git pull --ff-only origin main
unzip -o 55_AMBERLANDS_V28_4_SECURITY_AUDIT_PATCH.zip index.html v23_bulksell.js v20_itemshop_costumes.js
node --check v23_bulksell.js
node --check v20_itemshop_costumes.js
git add index.html v23_bulksell.js v20_itemshop_costumes.js
git commit -m "V28.4 Secure Server Bulk Sale and Item Shop"
git push origin main
```

4. รีเฟรชเกมและทดสอบ: ขายหลายชนิด 2 รายการ, Item Shop แสดงยอดคอยล์จริง, รีเฟรชแล้วของ/Gold ไม่กลับ, AutoBattle และ RPC buy/equip ยังทำงานได้
5. ถ้าเกิด Error ระหว่างขั้นตอน ต้องหยุดก่อน push / ไม่ใช้ `git add .`

## 7. บทสรุปเชิงความปลอดภัย

**V28.4 ปิดช่องเขียนเซฟตรงที่สำคัญที่สุดและแก้ทางขายหลายชนิด/ยอดคอยล์ปลอม แต่เกมยังไม่ Server-Authoritative ครบทั้งโปรเจกต์** จนกว่ากติกา spawn/location, boss/raid loot ทุกประเภท, inventory provenance, party, card/title bonus, PvP/Guild War จะถูกย้ายและทดสอบแบบหลายผู้เล่นจริง

**สถานะ Deploy:** SQL ติดตั้งจริงแล้ว; เว็บ V28.4 ยังต้องผู้สร้างอัปโหลด ZIP เพราะบัญชี GitHub Connector ไม่สามารถเขียน Repository ให้สำเร็จจากเครื่องมือที่มีอยู่; ห้ามบอกว่าผู้เล่นทุกคนใช้ V28.4 แล้วก่อน `git push` สำเร็จ
