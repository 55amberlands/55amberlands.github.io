55 AMBERLANDS V28.4 — FULL SYSTEM AUDIT + SUPABASE SECURITY PATCH
ตรวจจากสาขา main ของ 55amberlands/55amberlands.github.io รุ่น V28.3
วันที่ 26 ตุลาคม 2026 (เวลาไทย)

[ลง Supabase ให้แล้ว — ห้ามรันซ้ำ]
1. ยกเลิกสิทธิ์ INSERT/UPDATE/DELETE ตรงบน public.amber_characters สำหรับ anon และ authenticated
2. ปิด EXECUTE ของ public.amber_save_guarded(jsonb,bigint) รุ่นเซฟทั้งก้อน
3. ยกเลิกสิทธิ์ส่งคะแนนลง public.amber_scores ตรงจากมือถือ
4. เพิ่ม public.amber_v284_bulk_sell(jsonb) — ขาย NPC หลายชนิดแบบธุรกรรมเดียว ทั้งชุดสำเร็จหรือยกเลิกทั้งหมด
   ตรวจเจ้าของ, จำนวน, ราคา, อุปกรณ์ที่ใส่, Boss/drop รายการที่ห้ามขาย, ไอเทมซ้ำ, Gold cap
5. ทดสอบว่าเมื่อมีของไม่ถูกต้องเพียงรายการเดียว ไม่มีเงินหรือของถูกหัก/เพิ่มจริง (ทดสอบ ROLLBACK)

[จำเป็นต้องอัปเดต GitHub ด้วย ZIP นี้ — ยังไม่ได้เผยแพร่หน้าเว็บ]
- index.html
- v23_bulksell.js
- v20_itemshop_costumes.js

แก้ฝั่งเว็บ:
- ขายหลายรายการต้องให้ Supabase ตรวจและจ่าย Gold แบบยกชุด ไม่สร้าง Gold ใน JavaScript
- Item Shop ไม่ตั้งคอยล์ทดลอง 99,999 ในมือถืออีกต่อไป และเรียก RPC server ทั้งซื้อ/สวมปีก/ถอดปีก/ใช้ยารีเซ็ต
- ตัวละคร Google ไม่สามารถรีเซ็ตเลเวลหรือเซฟด้วยปุ่มลบข้อมูลออฟไลน์
- ไม่เปลี่ยน asset, หน้าตาเกม, สูตร EXP, drop, damage, บอส, ดันเจียน, ระบบอาชีพ หรือสกิล

วิธีอัปโหลดมือถือ: 
1) ดาวน์โหลดไฟล์ ZIP นี้
2) อัปโหลด ZIP เข้า GitHub ผ่านปุ่ม + ข้าง Code สีเขียว แล้วกด Commit ใน main
3) เปิด Codespaces > Terminal แล้วรันทีละบรรทัดตามนี้:

git pull --ff-only origin main
unzip -o 55_AMBERLANDS_V28_4_SECURITY_AUDIT_PATCH.zip index.html v23_bulksell.js v20_itemshop_costumes.js
node --check v23_bulksell.js
node --check v20_itemshop_costumes.js
git add index.html v23_bulksell.js v20_itemshop_costumes.js
git commit -m "V28.4 Server Bulk Sale and Secure Shop"
git push origin main

อย่าทำ git add . เพราะมีไฟล์หรือโฟลเดอร์เก่าที่อาจค้างอยู่
หาก git pull/unzip/node check มี Error ให้หยุดก่อน push

[ทดสอบหลังอัปโหลด]
- รีเฟรช Chrome แล้วเปิดกระเป๋า > ขายหลายชนิด 2 รายการ => Gold เพิ่มจริง ของลดจริง
- รีเฟรชอีกรอบ => จำนวน Gold และของต้องไม่เด้งกลับ
- เปิด Item Shop => เห็นยอดคอยล์ตาม Supabase ไม่ใช่ 99,999 ที่สร้างในหน้าเว็บ
- ลองรีเซ็ตเกมในบัญชี Google => ระบบต้องปฏิเสธการลบเซฟในมือถือ
- ระบบตีมอน, Auto Potion/Skill, Rebirth, บอส, ดันเจียนเดิมยังต้องใช้งานได้

หมายเหตุ: ยังมีงานเกมเซิร์ฟเวอร์ที่ต้องทำต่อ อ่านรายงาน AUDIT_TH.md
