#!/usr/bin/env python3
"""V27.2 safety-only installer. Does not touch Supabase or other game assets."""
from pathlib import Path
import hashlib, json, shutil, subprocess, sys, os
from datetime import datetime

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
MANIFEST=json.loads((HERE/'manifest.json').read_text())
FILES=MANIFEST['files']

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

stale=[]
for name, hashes in FILES.items():
    current=ROOT/name
    if not current.is_file():stale.append(name+' (missing)');continue
    h=sha(current)
    if h not in (hashes['from'],hashes['to']):
        stale.append(name+' (changed after source ZIP; do not overwrite)')
if stale:
    print('STOP: mismatch detected; nothing has been installed:')
    for x in stale:print(' -',x)
    sys.exit(2)
if all(sha(ROOT/name)==hashes['to'] for name,hashes in FILES.items()):
    print('V27.2 safety patch is already installed. Nothing changed.')
    sys.exit(0)

backroot=Path.home()/'amberlands_v27_2_backups'
backup=backroot/datetime.now().strftime('%Y%m%d_%H%M%S_%f')
backup.mkdir(parents=True,exist_ok=False)
for name in FILES: shutil.copy2(ROOT/name,backup/name)
print('Backup:',backup)
changed=[]
try:
    for name,hashes in FILES.items():
        if sha(ROOT/name)==hashes['to']:continue
        source=HERE/'files'/name
        if sha(source)!=hashes['to']:raise RuntimeError('Patch file hash mismatch: '+name)
        tmp=ROOT/(name+'.v27_2_tmp')
        shutil.copy2(source,tmp)
        os.replace(tmp,ROOT/name)
        changed.append(name)
    for name in FILES:
        if name.endswith('.js'):
            subprocess.run(['node','--check',str(ROOT/name)],check=True,capture_output=True,text=True)
except Exception as e:
    for name in FILES:
        shutil.copy2(backup/name,ROOT/name)
    print('ERROR: restored original files from backup:',e)
    sys.exit(1)
print('V27.2 safety patch installed. Files:',', '.join(changed))
print('NEXT: test in Codespaces Port 8000; DO NOT push yet. DO NOT enable Strict Mode.')
