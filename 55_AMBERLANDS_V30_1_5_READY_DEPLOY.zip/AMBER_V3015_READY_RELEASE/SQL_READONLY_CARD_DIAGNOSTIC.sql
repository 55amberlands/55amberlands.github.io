-- Diagnostic only. Does not modify character data or award free cards.
SELECT m.name AS monster_name, m.monster_id,
       COUNT(r.event_key)::integer AS server_verified_kills
FROM public.amber_characters c
JOIN private.amber_v276_reward_receipts r
  ON r.recipient=c.user_id AND r.source_kind='server_monster' AND r.xp_delta>0
JOIN private.amber_v276_monsters m
  ON m.monster_id=r.server_proof->>'monster_id'
WHERE c.character_name='Hareko'
GROUP BY m.name,m.monster_id
ORDER BY server_verified_kills DESC, m.name;
-- Mission claims today, verified by backend:
SELECT private.amber_v279_mission_status_impl(c.user_id) AS status
FROM public.amber_characters c WHERE c.character_name='Hareko';
