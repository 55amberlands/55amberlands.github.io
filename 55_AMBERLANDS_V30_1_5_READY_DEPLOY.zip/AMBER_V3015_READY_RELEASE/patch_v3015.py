#!/usr/bin/env python3
"""V30.1.5 targeted production-safe client patch, based on current V30.1.4. No SQL mutation."""
from pathlib import Path
import re, shutil, sys
ROOT=Path.cwd()
F=ROOT/'v25_systems.js'
H=ROOT/'index.html'
J=ROOT/'v3015_stable_skills.js'
KEY='AMBER_V3015_SERVER_CARDS_TITLES_MISSIONS'
assert F.is_file() and H.is_file(), 'STOP: main game files missing'
s=F.read_text(encoding='utf-8'); h=H.read_text(encoding='utf-8')
if KEY in s:
    print('PASS: V30.1.5 source already patched')
    sys.exit(0)
assert 'AMBER_V3012_SOURCE_FIXED_AURA' in s, 'STOP: require V30.1.2+ stable title aura'
assert 'v3014_two_boss_announcements.js' in h and 'v28_skill_vfx.js' in h, 'STOP: require V30.1.4 base'
assert 'v3015_stable_skills.js' not in h, 'STOP: unexpected previous v3015 script'

def swap(original, replacement, label):
    global s
    n=s.count(original)
    if n != 1: raise RuntimeError(f'STOP: {label}: need exactly 1 source anchor, got {n}')
    s=s.replace(original,replacement,1)

swap("const cardTier = (name, boss) => { const k = V().ck[name] | 0, T = boss ? BOSS_T : CARD_T; let t = 0; for (let i = 0; i < 4; i++) if (k >= T[i]) t = i + 1; return t; };", """// V30.1.5: online card counts come exclusively from Supabase V291 kill receipts.
// Never promote state.v25.ck (legacy local counter) into authoritative awards.
let verifiedCards = null;
let verifiedCardStamp = 0;
let verifiedCardsBusy = null;
const verifiedKillCount = (name) => {
  if (online()) return verifiedCards && Object.prototype.hasOwnProperty.call(verifiedCards, name)
    ? Math.max(0, Math.floor(Number(verifiedCards[name]) || 0)) : 0;
  return Math.max(0, V().ck[name] | 0); // offline preview ONLY; cannot claim server rewards
};
async function syncVerifiedCards(force = false) {
  if (!online()) { verifiedCards = null; verifiedCardStamp = 0; return; }
  if (!force && verifiedCards && Date.now() - verifiedCardStamp < 30000) return;
  if (verifiedCardsBusy) return verifiedCardsBusy;
  verifiedCardsBusy = (async () => {
    const {data, error} = await sb().rpc('amber_v291_verified_cards');
    if (error) throw error;
    if (!data?.ok || !data.cards || Array.isArray(data.cards) || typeof data.cards !== 'object')
      throw Error('V291_CARD_PROOF_INVALID');
    verifiedCards = Object.create(null);
    for (const [name, count] of Object.entries(data.cards)) {
      if (typeof name === 'string' && name.length <= 100)
        verifiedCards[name] = Math.max(0, Math.floor(Number(count) || 0));
    }
    verifiedCardStamp = Date.now();
    // Re-paint stats only if the card snapshot changed; do not save server counts in writable v25.ck.
    safe(() => renderTop());
  })();
  try { await verifiedCardsBusy; }
  finally { verifiedCardsBusy = null; }
}
const cardTier = (name, boss) => { const k = verifiedKillCount(name), T = boss ? BOSS_T : CARD_T; let t = 0; for (let i = 0; i < 4; i++) if (k >= T[i]) t = i + 1; return t; };""", 'server verified card counter')

# Make the UI distinguish authoritative progress from unverified old local cache.
swap('function tabCards() {\n  const mons = MON();', '''async function tabCards() {
  if (online()) {
    try { await syncVerifiedCards(); }
    catch (e) { console.error('[V3015 cards]', e); return '<p class="px25-warn">❌ อ่านหลักฐานการ์ดจาก Supabase ไม่ได้ จึงไม่แสดงจำนวนจากเครื่องแทน</p><button data-v25tab="cards">โหลดใหม่</button>'; }
  }
  const mons = MON();''', 'server cards tab')
swap('const t = cardTier(m.name, m.boss), k = V().ck[m.name] | 0, T = m.boss ? BOSS_T : CARD_T', 'const t = cardTier(m.name, m.boss), k = verifiedKillCount(m.name), T = m.boss ? BOSS_T : CARD_T', 'card progress display')
swap("return `<p class=\"px25-hint\">ฆ่ามอนครบจำนวนจะได้การ์ด", "return `<p class=\"px25-hint\">${online() ? '🛡️ จำนวนฆ่ามอนยืนยันจาก Supabase (ไม่ใช่เซฟในเครื่อง) · ' : '⚠️ โหมดออฟไลน์เป็นเพียงตัวอย่าง · '}ฆ่ามอนครบจำนวนจะได้การ์ด", 'verified album label')
swap("const before = cardTier(name, m.boss); v.ck[name] = (v.ck[name] | 0) + n; bump('kill', n); if (cardTier(name, m.boss) > before) onCardUp(m);", "const before = cardTier(name, m.boss); v.ck[name] = (v.ck[name] | 0) + n; bump('kill', n); if (online()) { void syncVerifiedCards(false).catch(e => console.warn('[V3015 card sync]', e)); } else if (cardTier(name, m.boss) > before) onCardUp(m);", 'local kill should not grant live cards')
# Reconcile local refreshes with RPC without altering local gear/EXP rules.
swap('function refreshTitles() {\n  const v = V(); let gain = [];', 'function refreshTitles() {\n  if (online()) return; // server owns title unlocks; never claim from editable local counters\n  const v = V(); let gain = [];', 'stop local online title claim')
marker='function activeTitleId() {'
assert s.count(marker)==1
s=s.replace(marker, '''// V30.1.5 server-authoritative title preferences and unlocks.
let serverTitles = null;
let serverTitlesStamp = 0;
let titleSyncBusy = null;
const ULT_NAMES = {ult_fist:'จ้าวกรงเล็บอสุนีบาต +10',ult_sword:'จักรพรรดิดาบสายฟ้า +10',
  ult_bow:'ราชันธนูวชิระ +10',ult_staff:'จอมเวทอัสนีพิภพ +10'};
for (const [id, name] of Object.entries(ULT_NAMES)) {
  if (!TITLES[id]) TITLES[id] = {name, cls:'rain', live:true,
    how:'สวมอาวุธตำนานบอสโลก +10 ของอาชีพตนเอง (ยืนยันโดย Supabase)'};
}
async function syncServerTitles(force = false) {
  if (!online()) { serverTitles = null; return null; }
  if (!force && serverTitles && Date.now()-serverTitlesStamp < 30000) return serverTitles;
  if (titleSyncBusy) return titleSyncBusy;
  titleSyncBusy = (async () => {
    const { data, error } = await sb().rpc('amber_v310_title', {p_action:'get',p_title:null});
    if (error) throw error;
    if (!data?.ok || !Array.isArray(data.owned)) throw Error('V310_TITLE_STATUS_INVALID');
    serverTitles = { active:String(data.active || ''), requested:String(data.requested || 'auto'),
      owned:new Set(data.owned.filter(x=>typeof x === 'string')) };
    serverTitlesStamp = Date.now();
    return serverTitles;
  })();
  try { return await titleSyncBusy; } finally { titleSyncBusy = null; }
}
async function chooseServerTitle(id) {
  if (!online()) { safe(()=>notify('🔒 ต้องออนไลน์เพื่อเปลี่ยนฉายา')); return; }
  try {
    const requested = ['set_fire','set_ice','set_prism'].includes(id) ? 'set_boss' : id;
    const {data,error} = await sb().rpc('amber_v310_title',{p_action:'set',p_title:requested});
    if (error) throw error;
    if (!data?.ok) {safe(()=>notify('🔒 ไม่สามารถเลือกฉายานี้ได้: '+String(data?.reason || 'locked')));return;}
    await syncServerTitles(true);
    const v=V(); v.titles.active = serverTitles?.requested || 'auto';
    // Display server-confirmed title; cloud autosave is NOT used to authorize it.
    safe(()=>decorateScene());
    safe(()=>notify('✅ เปลี่ยนฉายาแล้ว (ยืนยันจาก Supabase)'));
  } catch(e){console.error('[V3015 title change]',e);safe(()=>notify('เปลี่ยนฉายาไม่สำเร็จ: '+String(e.message||e).slice(0,100)));}
  finally {void openHub('titles');}
}
'''+marker,1)
start=s.index('function activeTitleId() {');end=s.index('\nfunction titleHTML(',start)
s=s[:start]+'''function activeTitleId() {
  if (online() && serverTitles) {
    const id = serverTitles.active;
    // Server stores one generic boss-set ID; existing V25 visuals retain specific
    // fire / ice / prism theme only when five actually equipped boss items permit it.
    if (id === 'set_boss') { const si=setInfo(); return si.full && si.id ? si.id : 'set_boss'; }
    return TITLES[id] ? id : '';
  }
  // While the first RPC is loading, retain the previously visible legacy title
  // rather than blanking the label and creating a visible flicker.
  const v = V(), si = setInfo();
  if (v.titles.active === 'auto' || !v.titles.active) { if (si.id) return si.id; const o = v.titles.owned; return o.length ? o[o.length - 1] : ''; }
  if (v.titles.active.startsWith('set_') || v.titles.active === 'boss3') return si.id === v.titles.active ? si.id : (si.id || '');
  return v.titles.owned.includes(v.titles.active) ? v.titles.active : '';
}'''+s[end:]
# Server proof always used for the title tab when online.
swap('function tabTitles() {\n  const v = V(), si = setInfo(), act = activeTitleId();', '''async function tabTitles() {
  if (online()) {
    try { await syncServerTitles(true); }
    catch (e) { console.error('[V3015 titles]',e); return '<p class="px25-warn">❌ ไม่สามารถโหลดฉายาที่เซิร์ฟเวอร์ปลดล็อกได้ กรุณาลองใหม่</p>'; }
  }
  const v = V(), si = setInfo(), act = activeTitleId();''', 'titles tab server read')
swap("const own = t.live ? si.id === id : v.titles.owned.includes(id);", "const own = online() ? !!serverTitles?.owned.has(['set_fire','set_ice','set_prism'].includes(id) ? 'set_boss' : id) && (!['set_fire','set_ice','set_prism'].includes(id) || si.id === id) : (t.live ? si.id === id : v.titles.owned.includes(id));", 'titles owned proof')
swap("${v.titles.active === 'auto' ? 'disabled' : ''}", "${(online() ? serverTitles?.requested : v.titles.active) === 'auto' ? 'disabled' : ''}", 'title auto button')
swap("else if (a === 'title') { V().titles.active = b.dataset.id; commit(); decorateScene(); openHub('titles'); } else if (a === 'titleauto') { V().titles.active = 'auto'; commit(); openHub('titles'); }", "else if (a === 'title') { void chooseServerTitle(b.dataset.id); } else if (a === 'titleauto') { void chooseServerTitle('auto'); }", 'authoritative title actions')
# Status is always checked with backend before claiming, not against stale disabled UI.
swap('''async function claimMission(i) {
  const m = V().daily?.m?.[i];
  if (!m || m.claimed || m.have < m.need) return;
  if (m.id === 'login' && online() && window.AMBER_V27) return window.AMBER_V27.loginMission(i);
  return missionClaimRpc(m.id);
}''','''async function claimMission(i) {
  if (!online()) { safe(()=>notify('ต้องเชื่อม Supabase ก่อนรับรางวัล')); return; }
  const originalId = V().daily?.m?.[i]?.id;
  if (!originalId) return;
  try { await missionRefresh(); } catch (e) { safe(()=>notify('ตรวจสถานะเควสต์จาก Supabase ไม่สำเร็จ')); return; }
  const m = V().daily?.m?.find(x=>x.id===originalId);
  if (!m || m.claimed) {safe(()=>notify('รับรางวัลนี้แล้วหรือเควสต์เปลี่ยนวัน'));return;}
  if (m.have < m.need) {safe(()=>notify(`หลักฐานเควสต์ยังไม่ครบ (${m.have}/${m.need})`));return;}
  if (m.id === 'login' && window.AMBER_V27) return window.AMBER_V27.loginMission(i);
  return missionClaimRpc(m.id);
}''','mission fresh status claim')
# All results from the server are displayed in the same modal; buttons do not use local reward credits.
swap('''  curTab = tab || curTab; ensureDaily(); refreshTitles();
  if (curTab === 'checkin' && window.AMBER_V27)''', '''  curTab = tab || curTab; ensureDaily(); refreshTitles();
  if (online() && !serverTitles) void syncServerTitles().then(()=>safe(decorateScene)).catch(e=>console.warn('[V3015 title hydrate]',e));
  if (curTab === 'checkin' && window.AMBER_V27)''', 'early title hydrate')
# Defuse client-sourced auto bonus while connected: cardTier is already receipt-backed.
# Make UI avoid label implying server damage now applies card bonus, pending separate combat rollout.
swap("(มีผลอัตโนมัติ)", "(ใช้แสดงผลอัลบั้ม; โบนัสการต่อสู้รอยืนยันสูตรเซิร์ฟเวอร์)", 'card bonus honest label')
# Make refresh availability upon normal start login on subsequent ticks.
swap('''  setInterval(() => { ensureDaily(); paintDot(); refreshTitles(); }, 15000);''','''  setInterval(() => { ensureDaily(); paintDot(); refreshTitles();
    if (online() && !serverTitles) void syncServerTitles().then(()=>safe(decorateScene)).catch(e=>console.warn('[V3015 title initial]',e));
    if (online() && Date.now()-verifiedCardStamp>60000 && !verifiedCardsBusy) void syncVerifiedCards().catch(e=>console.warn('[V3015 card initial]',e));
  }, 15000);''','login title hydration')
# prevent local faux killing from crediting set cards before server receipt settlement in live online.
swap("if (m) { const before = cardTier(m.name, true); v.ck[m.name] = (v.ck[m.name] | 0) + 1; if (cardTier(m.name, true) > before) onCardUp(m); }", "if (m && !online()) { const before = cardTier(m.name, true); v.ck[m.name] = (v.ck[m.name] | 0) + 1; if (cardTier(m.name, true) > before) onCardUp(m); }", 'raid local card guard')

assert KEY not in s
s=s.replace("/* ------------------------------------------------------------------ state */", f"/* {KEY} */\n/* ------------------------------------------------------------------ state */",1)
# Additional script added after ALL V28 bundles for stable skill DOM hydration.
assert h.count('</body></html>')==1
h=h.replace('</body></html>', '<script src="./v3015_stable_skills.js?v=3015_source_stable"></script></body></html>',1)
# Guarantee script link to V25 goes through cache bust to prevent stale V3014 mixing.
h,n=re.subn(r'(v25_systems\.js\?v=)[A-Za-z0-9_\-]+',r'\g<1>3015_server_cards_title_missions',h)
assert n==1, f'STOP: expected exactly one V25 script version; got {n}'
# v28 skill patch remains installed, plus stable slots loaded afterward.
assert h.count('v28_skill_vfx.js')==1
for f in (F,H):
    bak=ROOT/'.amber_v3015_backup'/f.name
    bak.parent.mkdir(exist_ok=True)
    if not bak.exists(): shutil.copy2(f,bak)
F.write_text(s,encoding='utf-8'); H.write_text(h,encoding='utf-8')
print('PASS: V30.1.5 patched server-verified cards, title switching, mission sync, stable skill loader')
