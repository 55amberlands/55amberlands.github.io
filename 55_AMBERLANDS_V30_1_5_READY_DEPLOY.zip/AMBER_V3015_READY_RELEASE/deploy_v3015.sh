#!/usr/bin/env bash
# V30.1.5 READY: Supports GitHub Add file -> Upload files auto-generated ZIP commits.
# Safeguards: exact V30.1.4 ancestor + ONLY whitelisted uploaded ZIP(s) since that baseline.
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
EXPECTED='f65a1622bcc669dd824aaea51b402c80424fcc82'
BACKUP_BRANCH='backup-v3014-before-v3015-20261027'
OLD_ZIP='55_AMBERLANDS_V30_1_5_SKILLS_TITLES_MISSIONS_CARDS.zip'
NEW_ZIP='55_AMBERLANDS_V30_1_5_READY_DEPLOY.zip'

# Switch safely; do not reset, stash or remove anything.
if [[ -n "$(git status --porcelain --untracked-files=no)" ]]; then
  echo 'STOP: มีไฟล์ที่แก้ไว้แต่ยังไม่ได้ Commit; ไม่แตะไฟล์เหล่านั้น'; exit 2
fi
git switch main
git fetch origin main
git pull --ff-only origin main
if [[ -n "$(git status --porcelain --untracked-files=no)" ]]; then
  echo 'STOP: local tracked changes on main'; exit 2
fi
BASE="$(git rev-parse HEAD)"
if grep -q 'AMBER_V3015_SERVER_CARDS_TITLES_MISSIONS' v25_systems.js; then
  if grep -q 'v3015_stable_skills.js' index.html && [[ -f v3015_stable_skills.js ]]; then
    echo "PASS: V30.1.5 already installed at ${BASE:0:12}"; exit 0
  fi
  echo 'STOP: partial V30.1.5 patch exists. Send terminal output.'; exit 4
fi
if ! git cat-file -e "${EXPECTED}^{commit}" 2>/dev/null || ! git merge-base --is-ancestor "$EXPECTED" "$BASE"; then
  echo 'STOP: current main is not a descendant of verified V30.1.4'; exit 4
fi
mapfile -t CHANGED < <(git diff --name-only "$EXPECTED" "$BASE")
for p in "${CHANGED[@]}"; do
  case "$p" in
    "$OLD_ZIP"|"$NEW_ZIP") ;;
    *) echo "STOP: game or other file has changed after V30.1.4: $p"; exit 4 ;;
  esac
done
if [[ ! -f "$NEW_ZIP" ]]; then
  echo "STOP: uploaded $NEW_ZIP missing from repository root"; exit 5
fi
if [[ -e v3015_stable_skills.js ]]; then
  echo 'STOP: v3015_stable_skills.js already exists without patch marker'; exit 5
fi
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
[[ -f "$HERE/patch_v3015.py" && -f "$HERE/v3015_stable_skills.js" ]] || {
  echo 'STOP: incomplete installer files'; exit 5;
}
# Snapshot exact historical version, without modifying the live main branch.
git push origin "${EXPECTED}:refs/heads/${BACKUP_BRANCH}"
cp -- "$HERE/v3015_stable_skills.js" ./v3015_stable_skills.js
python3 "$HERE/patch_v3015.py"
node --check v25_systems.js
node --check v3015_stable_skills.js
git diff --check -- index.html v25_systems.js
[[ "$(grep -c 'v3015_stable_skills.js' index.html)" == '1' ]] || { echo 'STOP: bad script injection'; exit 5; }
[[ "$(grep -c 'AMBER_V3015_SERVER_CARDS_TITLES_MISSIONS' v25_systems.js)" == '1' ]] || { echo 'STOP: source patch invalid'; exit 5; }
git add -- index.html v25_systems.js v3015_stable_skills.js
git commit -m 'V30.1.5 stable skills server titles missions verified cards (upload-safe)'
git push origin main
echo 'PASS: V30.1.5 uploaded and pushed to MAIN. V30.1.4 backup preserved.'
