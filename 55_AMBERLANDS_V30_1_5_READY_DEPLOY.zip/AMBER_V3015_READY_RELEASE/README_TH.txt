55 AMBERLANDS V30.1.5 READY DEPLOY — FIXED INSTALLER

เหตุผลที่รุ่นก่อนหยุด: GitHub ปุ่ม Add file > Upload files สร้าง Commit เพิ่มจาก V30.1.4 เสมอ
ตัวติดตั้งเดิมตรวจว่า main ต้องเท่ากับ SHA V30.1.4 ทุกตัว จึงหยุด ทั้งที่โค้ดเกมไม่ได้เปลี่ยน

รุ่นใหม่นี้ตรวจว่า:
- commit V30.1.4 เป็นบรรพบุรุษของ main จริง
- หลัง V30.1.4 อนุญาตให้เปลี่ยนได้เฉพาะไฟล์ ZIP สองชื่อ:
    55_AMBERLANDS_V30_1_5_SKILLS_TITLES_MISSIONS_CARDS.zip
    55_AMBERLANDS_V30_1_5_READY_DEPLOY.zip
- ถ้ามีการแก้ code หรือไฟล์อื่นหลัง V30.1.4 จะ STOP เพื่อป้องกันการเขียนทับ
- สร้างสาขาสำรอง backup-v3014-before-v3015-20261027 ก่อนแก้
- ไม่ใช้ git reset, stash, force-push และไม่แก้ Supabase

วิธีใช้:
1) ดาวน์โหลด 55_AMBERLANDS_V30_1_5_READY_DEPLOY.zip
2) อัปโหลดที่ GitHub Repository > Add file > Upload files > Commit changes
3) ไป Codespaces Terminal แล้ววาง:
cd "$(git rev-parse --show-toplevel)" && git pull --ff-only origin main && unzip -oq 55_AMBERLANDS_V30_1_5_READY_DEPLOY.zip -d .git/amber_v3015_ready && bash .git/amber_v3015_ready/AMBER_V3015_READY_RELEASE/deploy_v3015.sh
4) เมื่อขึ้น PASS ให้ตรวจ GitHub Actions และเปิดเกมใหม่

ส่วนที่แก้เหมือน ZIP เดิม:
1) ช่วยให้ UI สกิล V28 ไม่ถูกเขียนทับซ้ำขณะ Refresh
2) ยืนยันการเปลี่ยนฉายาผ่าน RPC amber_v310_title
3) กดรับรางวัลกิจกรรมผ่าน RPC server โดยดึงสถานะล่าสุด
4) แสดงการ์ดมอนสเตอร์จาก RPC amber_v291_verified_cards

ไม่รับประกันผลกดผ่านมือถือจนกว่าจะทดสอบหลัง Deploy จริง
