55 AMBERLANDS V27.9 — เควสต์รายวันรับรางวัลผ่าน Supabase เท่านั้น

- ติดตั้ง Supabase RPC แล้ว: amber_v279_mission_status, amber_v279_mission_claim
- เพิ่ม server evidence จาก amber_v277_attack และ amber_v277_economy (หากผู้เล่นเข้าสู่ Server Mode)
- ฝั่งเว็บแก้ v25_systems.js และ index.html (cache-bust) เพื่อดึงตัวนับจากเซิร์ฟเวอร์จริง
- ภารกิจที่จบในมือถือก่อนติดตั้ง server evidence ไม่สามารถนำมารับรางวัลย้อนหลังได้อย่างปลอดภัย
- กันรับซ้ำด้วย Primary Key (user_id,kind,period) บน public.amber_ac_claims
- หีบโบนัสจ่ายเมื่อเควสต์ทั้งสามได้รับรางวัลสำเร็จบน Supabase แล้วเท่านั้น
- อย่านำ client local kill/skill count ไปคิดรางวัล; ตรวจด้วย SQL read-only หากจำเป็น
- สำคัญ: เว็บ main อาจยังไม่ deploy ชุดนี้; GitHub connector ไม่มีสิทธิ์เขียน (403)
- ยังไม่ได้ยืนยันระบบเกมทุกจุดเป็น server-authoritative; ช่องเซฟของบัญชีที่ยังใช้ระบบเก่ายังคงมีความเสี่ยง
