55 AMBERLANDS V27.1.1 — CLIENT RPC PATCH (FOR CODESPACES)
วันที่: 2026-10-25

แพตช์นี้ใช้กับ Repository 55amberlands/55amberlands.github.io (V26 ที่ Commit แล้ว)
และ SQL V27.1.1 ซึ่งติดตั้งไว้ใน Supabase.

การติดตั้งบน GitHub Codespaces ผ่านมือถือ
1) อัปโหลดไฟล์ ZIP ชุดนี้ไปยังโฟลเดอร์หลักของ Repository
2) รัน: unzip 55_AMBERLANDS_V27_1_CLIENT_PATCH.zip
3) รัน: python3 v27_patch_assets/install_v27_patch.py
4) รัน: git diff --check
5) รัน: node --check v27_ac_client.js
6) เปิด Port 8000 จาก Codespaces แล้วทดสอบบัญชีทดสอบก่อน Commit/Push

สคริปต์ติดตั้งสำรองต้นฉบับ 4 ไฟล์ไว้ภายนอก Repo:
/workspaces/amber_v26_pre_v27_client  (ตำแหน่งอาจต่างตาม ROOT)
ไฟล์ที่แก้: index.html, online_bridge.js, v25_systems.js, v26_realtime.js
ไฟล์ใหม่: v27_ac_client.js
ระบบแมป ภาพ ตัวละคร สกิล UI หลัก Login ไม่ถูกเปลี่ยน

การทำงานที่เชื่อมในแพตช์
* เช็กอิน 7 วัน: public.amber_ac_checkin ใช้เวลาไทยที่ Supabase จ่ายของ/คอยล์จริง
* ภารกิจเข้าเกม: public.amber_ac_login_mission จ่ายของผ่าน RPC
* เชิญเพื่อน: public.amber_ac_referral_redeem ไม่ให้รับรางวัลทันที;
  public.amber_ac_referral_bonus ตรวจเพื่อนที่เซิร์ฟเวอร์ยืนยันว่า Lv.5+
* บอสโลก: ไม่จ่ายคอยล์จาก JS อีก; ใช้ public.amber_ac_world_claim
  เฉพาะเมื่อมีหลักฐาน public.amber_ac_world_proofs จากระบบที่เชื่อถือได้เท่านั้น
* ตารางคะแนน: ปิดการส่งคะแนนจากมือถืออัตโนมัติ จนกว่าจะสร้าง RPC คะแนนจากเหตุการณ์จริง
* ภารกิจฆ่ามอน/ใช้สกิล/ตีบวก/เรด, หีบโบนัสรายวัน: งดรับรางวัลชั่วคราว
  เพราะยังไม่มีหลักฐานเหตุการณ์เซิร์ฟเวอร์ที่เชื่อถือได้
* แสดงจำนวนคอยล์/Gold/แร่จาก DB หลัง RPC ด้วย mutex ระบบตลาดเดิม
* เพิ่ม cache-busting ของสคริปต์ที่เปลี่ยน เพื่อรองรับ Chrome/PWA

ข้อจำกัดสำคัญ
* SQL V27.1.1 ยังคง strict_saves/strict_scores/strict_referrals = false ตามข้อกำหนด
  ดังนั้นผู้เล่นที่ส่ง HTTP API ด้วยตัวเองยังอาจแก้ JSON เซฟ/คะแนนได้!
  แพตช์นี้ไม่ได้ปิดช่องโหว่ทั้งหมด ห้ามอ้างว่ากันโกง 100%.
* ต้องพัฒนา authoritative combat/economy, source-of-truth ของ Gold/Gems/EXP/gear,
  และออกแบบระบบออกหลักฐานบอสที่เชื่อถือได้ก่อนเปิดโหมด strict.
* ไม่มีการแก้ SQL หรือ Supabase อัตโนมัติจากชุดนี้
* ห้าม Push main ก่อนทดสอบซ้ำบน Codespaces เพื่อไม่กระทบผู้เล่นจริง

ทดสอบบน Codespaces (ใช้บัญชีทดสอบ ไม่ใช้ตัวละครหลัก)
1. Login Google และเดิน/เปลี่ยนแมป แล้วย้อนเข้ามาใหม่
2. เปิดเมนูเช็กอิน: กดรับหนึ่งครั้ง ตรวจว่าของเข้าเซิร์ฟเวอร์
3. กดรับซ้ำ: ต้องไม่ได้ของเพิ่ม
4. เมนูภารกิจเข้าเกม: รับได้ครั้งเดียวต่อวัน
5. บอสโลกที่ยังไม่มีหลักฐาน: ต้องไม่มีคอยล์เพิ่ม แม้ชนะบนหน้าจอ
6. ตรวจ Console ไม่มี JS error, และตรวจ Cloud Save

วิธีถอยกลับ (เฉพาะก่อน Commit หากเจอปัญหา)
จาก root Repo:
cp ../amber_v26_pre_v27_client/index.html .
cp ../amber_v26_pre_v27_client/online_bridge.js .
cp ../amber_v26_pre_v27_client/v25_systems.js .
cp ../amber_v26_pre_v27_client/v26_realtime.js .
rm v27_ac_client.js
(ยังเหลือโฟลเดอร์ v27_patch_assets และไฟล์ ZIP ซึ่งลบทีหลังได้)

แพตช์ต้องได้รับการทดสอบกับ Supabase ที่ใช้งานจริงก่อนปล่อยสู่สาธารณะ.
