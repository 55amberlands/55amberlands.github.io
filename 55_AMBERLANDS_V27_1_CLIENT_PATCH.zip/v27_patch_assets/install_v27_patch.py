#!/usr/bin/env python3
"""55 AMBERLANDS V27.1.1 mobile-friendly anti-cheat client patch.
No SQL edits, no file overwrites beyond anchored JS changes. Never touches live GitHub automatically.
"""
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path.cwd()
MARKER = 'V27.1.1_CLIENT_BRIDGE'
PATCH_FILES = ('v25_systems.js', 'v26_realtime.js', 'online_bridge.js', 'index.html')
CLIENT = Path(__file__).resolve().with_name('v27_ac_client.js')


def only(old, a, b, title):
    n = old.count(a)
    if n != 1:
        raise RuntimeError(f'{title}: expected one anchor, found {n}; files unchanged')
    return old.replace(a, b, 1)


def patch_v25(s):
    s = only(s,
    "function ckState() { const c = V().checkin, today = dkey(), yest = dkey(new Date(Date.now() - DAY)); return { c, can: c.last !== today, broken: c.last && c.last !== today && c.last !== yest, today }; }",
    """function ckState() {
  const c = V().checkin, info = window.AMBER_V27?.getState();
  if (online()) {
    if (!info?.today_th) return { c, can: false, broken: false, today: '' };
    const today = info.today_th, yest = new Date(Date.parse(today + 'T00:00:00Z') - DAY).toISOString().slice(0, 10);
    c.day = Number(info.checkin_day) || 0;
    c.last = info.checkin_last || '';
    return { c, can: c.last !== today, broken: !!(c.last && c.last !== today && c.last !== yest), today };
  }
  return { c, can: false, broken: false, today: '' };
}""",
    'server checkin state')
    start = s.index('function doCheckin() {')
    end = s.index('\n\n/* ------------------------------------------------------------------ 2 daily missions */', start)
    original = s[start:end]
    s = only(s,original,"""function doCheckin() {
  if (!online() || !window.AMBER_V27) { safe(() => notify('เช็กอินต้องเชื่อม Supabase V27 ก่อน')); return; }
  void window.AMBER_V27.checkin();
}""",'client checkin award')
    start = s.index('function claimMission(i) {')
    end = s.index('\n\n/* ------------------------------------------------------------------ hooks:', start)
    original = s[start:end]
    replacement = """function claimMission(i) {
  const m = V().daily.m[i];
  if (!m || m.claimed || m.have < m.need) return;
  if (m.id === 'login' && online() && window.AMBER_V27) return void window.AMBER_V27.loginMission(i);
  safe(() => notify('🛡️ ภารกิจนี้รอหลักฐานจากเซิร์ฟเวอร์ จึงยังจ่ายรางวัลไม่ได้'));
}
function claimDailyBonus() {
  safe(() => notify('🛡️ หีบรวมรายวันรอระบบยืนยันภารกิจจากเซิร์ฟเวอร์'));
}"""
    s = only(s,original,replacement,'daily mission awards')
    s = only(s,
      "  if (wbWindow().open) { v.wb.total = (v.wb.total | 0) + 1; const t = grant({ gw: 4, ga: 3, gems: 30, ore_prism: 2 }); safe(() => notify('👑 โบนัสบอสโลก! ' + t)); }",
      "  if (wbWindow().open) safe(() => notify('🛡️ โบนัสบอสโลกรอเซิร์ฟเวอร์ตรวจผลก่อนจ่ายจริง'));",
      'raid client world bonus')
    s = only(s, 'async function pushScore() {\n',
      'async function pushScore() {\n  // V27.1.1: stop client-submitted rank points until server combat events exist.\n  return;\n',
      'score upload blocker')
    a = s.index('async function refAct(a, btn) {')
    b = s.index("safe(() => { const m = location.search.match", a)
    original = s[a:b]
    replacement = """async function refAct(a, btn) {
  if (!online() || !window.AMBER_V27) return safe(() => notify('รางวัลชวนเพื่อนต้องยืนยันจาก Supabase'));
  if (a === 'refuse') {
    const code = ($('px25Ref')?.value || '').trim().toUpperCase();
    return void window.AMBER_V27.refRedeem(code);
  }
  if (a === 'refclaim') return void window.AMBER_V27.refBonus(Number(btn.dataset.n));
}
"""
    s=only(s,original,replacement,'referral client awards')
    s=only(s,'  curTab = tab || curTab; ensureDaily(); refreshTitles();',
      "  curTab = tab || curTab; ensureDaily(); refreshTitles();\n  if (curTab === 'checkin' && window.AMBER_V27) await window.AMBER_V27.syncState(true);",
      'checkin UI load')
    s=only(s,'<b>💠 50 คอยล์ + 💰 3,000 Gold</b>',
      '<b>รางวัลรอเซิร์ฟเวอร์ตรวจเลเวลก่อน</b>',
      'invite reward description')
    s=only(s,'(ตอนนี้ ${cnt} คน)', '(รหัสเชิญที่ใช้ ${cnt} คน · รางวัลนับเฉพาะเพื่อนที่เซิร์ฟเวอร์ยืนยัน Lv.5+)',
      'invite count label')
    return s


def patch_v26(s):
    a=s.index('  if (!ARENA.practice && v && v.wb.claimed !== ARENA.ev && myRank > 0) {')
    b=s.index('\n  const res = document.createElement',a)
    original=s[a:b]
    replacement="""  if (!ARENA.practice && v && v.wb.claimed !== ARENA.ev && myRank > 0) {
    // V27.1.1: NEVER grant browser-computed boss rewards. Live payout must
    // use a server-issued world proof and the amber_ac_world_claim RPC.
    v.wb.claimed = ARENA.ev;
    v.wb.total = (v.wb.total | 0) + (win ? 1 : 0);
    v.wb.dmg = (v.wb.dmg | 0) + ARENA.me.d;
    rewardTxt = '🛡️ รางวัลรอผลที่เซิร์ฟเวอร์รับรอง (ยังไม่เพิ่มคอยล์/Gold/แร่)';
    if (win && window.AMBER_V27) void window.AMBER_V27.worldClaim();
    safe(() => { V25().commit(); V25().refresh(); });
  }"""
    return only(s,original,replacement,'world boss client reward')


def patch_bridge(s):
    return only(s,"['gold','bag','gear','mats','potHP','potMP','eq']",
      "['gold','gems','bag','gear','mats','potHP','potMP','eq']",
      'sync server coils')


def patch_html(s):
    # V27 cache-busting is required for Android home-screen / PWA installs.
    for old, new in (
        ('./online_bridge.js?v=22', './online_bridge.js?v=27_1_1'),
        ('./v25_systems.js?v=26', './v25_systems.js?v=27_1_1'),
        ('./v26_realtime.js?v=26', './v26_realtime.js?v=27_1_1'),
    ):
        s = only(s, old, new, 'script cache version')
    mark = '<script src="./v26_realtime.js?v=27_1_1"></script>'
    add = '\n<script src="./v27_ac_client.js?v=27_1_1"></script><!-- ' + MARKER + ' -->'
    return only(s, mark, mark + add, 'index V27 script')


def main():
    if not CLIENT.is_file(): raise RuntimeError('v27_ac_client.js missing next to installer')
    if not all((ROOT/n).is_file() for n in PATCH_FILES): raise RuntimeError('Run from GitHub repository root with index.html')
    src={n:(ROOT/n).read_text(encoding='utf-8') for n in PATCH_FILES}
    if MARKER in src['index.html']:
        raise RuntimeError('Already patched; abort without changing files')
    if (ROOT/CLIENT.name).exists():
        raise RuntimeError('v27_ac_client.js already exists; abort without changing files')
    changed={
      'v25_systems.js':patch_v25(src['v25_systems.js']),
      'v26_realtime.js':patch_v26(src['v26_realtime.js']),
      'online_bridge.js':patch_bridge(src['online_bridge.js']),
      'index.html':patch_html(src['index.html']),
    }
    # Validate all outputs before touching user originals
    import tempfile
    with tempfile.TemporaryDirectory() as temp:
        for name in ('v25_systems.js','v26_realtime.js','online_bridge.js'):
            t=Path(temp)/name;t.write_text(changed[name],encoding='utf-8')
            result=subprocess.run(['node','--check',str(t)],text=True,capture_output=True)
            if result.returncode:raise RuntimeError(f'{name} syntax failed: '+result.stderr)
        result=subprocess.run(['node','--check',str(CLIENT)],text=True,capture_output=True)
        if result.returncode:raise RuntimeError('V27 bridge syntax failed: '+result.stderr)
    backup=ROOT.parent/'amber_v26_pre_v27_client'
    if backup.exists():raise RuntimeError(f'Backup folder exists: {backup}; stop and inspect')
    backup.mkdir()
    for name in PATCH_FILES: shutil.copy2(ROOT/name,backup/name)
    try:
        for name,updated in changed.items():
            (ROOT/name).write_text(updated,encoding='utf-8')
        shutil.copy2(CLIENT,ROOT/CLIENT.name)
    except Exception:
        for name in PATCH_FILES: shutil.copy2(backup/name,ROOT/name)
        (ROOT/CLIENT.name).unlink(missing_ok=True)
        raise
    print('PATCH INSTALLED: 5 files changed/added; originals backed up:',backup)
    print('Next: node --check v27_ac_client.js && git diff --check')
    print('DO NOT PUSH OR ENABLE STRICT until you test on Codespaces Port 8000.')

if __name__=='__main__':
    try:main()
    except Exception as exc:
        print('STOP:',exc,file=sys.stderr)
        sys.exit(1)
